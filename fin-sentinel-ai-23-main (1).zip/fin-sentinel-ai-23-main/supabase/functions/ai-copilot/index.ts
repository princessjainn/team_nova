import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  try {
    const { question, caseData } = await req.json();
    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    if (!LOVABLE_API_KEY) throw new Error("LOVABLE_API_KEY is not configured");

    const systemPrompt = `You are FinSentinel AI Copilot, an investigation assistant for fraud analysts.
You help officers understand flagged cases by answering questions in clear, concise language.
You have access to the case data provided. Answer factually based on the data.
Keep answers under 200 words. Use bullet points for clarity. Reference specific data points.
If you don't have enough data to answer, say so clearly.`;

    const userPrompt = `Case Context:
- Case ID: ${caseData.case_id}
- Risk Score: ${caseData.risk_score}/100
- Status: ${caseData.status}
- Customer: ${caseData.customer?.full_name || caseData.customer_uuid}
- Merchant: ${caseData.merchant?.merchant_name || caseData.merchant_uuid}
- Amount: ₹${caseData.transaction?.transaction_amount?.toLocaleString('en-IN') || 'N/A'}
- Anomalies: ${(caseData.anomalies || []).map((a: any) => `[${a.severity}] ${a.type}: ${a.description}`).join('; ')}
- Risk Breakdown: Amount=${caseData.amount_risk}, Device=${caseData.device_risk}, Location=${caseData.location_risk}, Merchant=${caseData.merchant_risk}, Behavioral=${caseData.behavioral_deviation}

Officer Question: ${question}`;

    const response = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${LOVABLE_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-3-flash-preview",
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user", content: userPrompt },
        ],
      }),
    });

    if (!response.ok) {
      if (response.status === 429) {
        return new Response(JSON.stringify({ error: "Rate limit exceeded. Please try again in a moment." }), {
          status: 429, headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      if (response.status === 402) {
        return new Response(JSON.stringify({ error: "AI credits exhausted." }), {
          status: 402, headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      throw new Error("AI gateway error");
    }

    const data = await response.json();
    const answer = data.choices?.[0]?.message?.content || "Unable to generate response.";

    return new Response(JSON.stringify({ answer }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (e) {
    console.error("copilot error:", e);
    return new Response(JSON.stringify({ error: e instanceof Error ? e.message : "Unknown error" }), {
      status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
