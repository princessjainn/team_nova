import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

const SYSTEM_PROMPT = `You are FinSentinel AI, an expert fraud investigation analyst for UPI and cheque transactions in Indian banking. You analyze flagged financial transactions and produce structured investigation reports.

When given case data, you MUST produce a comprehensive investigation report with the following sections:

## 1. EXECUTIVE SUMMARY
A brief 2-3 sentence summary of the case and your recommendation (ESCALATE / INVESTIGATE / MONITOR / CLEAR).

## 2. TRANSACTION ANALYSIS
Analyze the transaction details - amount, timing, location, device, IP address. Compare against customer behavioral baseline.

## 3. ANOMALY ASSESSMENT
For each detected anomaly, explain:
- Why it's suspicious
- The severity and confidence level
- How it deviates from the customer's behavioral DNA

## 4. BEHAVIORAL DEVIATION ANALYSIS
Compare the flagged transaction against the customer's Behavioral DNA Profile:
- Amount deviation (vs median/average)
- Time pattern deviation
- Device stability assessment
- Location variance analysis
- Merchant distribution analysis

## 5. CROSS-CASE LINKAGE
Identify any connections to other flagged cases, shared devices, IP clusters, or merchant patterns that suggest organized fraud.

## 6. CONTRADICTION DETECTION
Identify logical inconsistencies:
- Claimed location vs IP geolocation
- Registered device vs transaction device
- Account activity patterns vs current behavior

## 7. RISK ASSESSMENT
Provide a detailed breakdown:
- Amount Risk (weight: 25%)
- Device Risk (weight: 20%)
- Location Risk (weight: 20%)
- Merchant Risk (weight: 15%)
- Behavioral Deviation (weight: 20%)
- Overall weighted risk score

## 8. COUNTERFACTUAL ANALYSIS
Consider: "What if this transaction is legitimate?" Provide reasoning for and against.

## 9. RECOMMENDED ACTION
One of: BLOCK_ACCOUNT, ESCALATE, INVESTIGATE, MONITOR, CLEAR
Include specific next steps for the operations officer.

## 10. CONFIDENCE SCORE
Your confidence in the investigation outcome (0-100%) with justification.

Use precise financial terminology. Reference specific data points. Be thorough but concise. Format with markdown.`;

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { caseData } = await req.json();
    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    if (!LOVABLE_API_KEY) throw new Error("LOVABLE_API_KEY is not configured");

    const userPrompt = `Investigate the following flagged UPI transaction case:

**Case ID:** ${caseData.case_id}
**Status:** ${caseData.status}
**Risk Score:** ${caseData.risk_score}/100
**Flagged At:** ${caseData.flagged_at}

**Transaction Details:**
- Transaction ID: ${caseData.transaction?.transaction_uuid}
- Amount: ₹${caseData.transaction?.transaction_amount?.toLocaleString('en-IN')}
- Timestamp: ${caseData.transaction?.transaction_timestamp}
- Location: ${caseData.transaction?.transaction_location}
- Device Used: ${caseData.transaction?.customer_device_id}
- IP Address: ${caseData.transaction?.customer_ip_address}

**Customer Profile:**
- Name: ${caseData.customer?.full_name}
- Age: ${caseData.customer?.age}
- UPI ID: ${caseData.customer?.upi_id}
- Bank: ${caseData.customer?.bank_name}
- Branch: ${caseData.customer?.home_branch}
- Account Balance: ₹${caseData.customer?.account_balance?.toLocaleString('en-IN')}
- Total Transactions: ${caseData.customer?.total_transactions_count}
- Total Amount Transacted: ₹${caseData.customer?.total_transactions_amount?.toLocaleString('en-IN')}
- Registered Device: ${caseData.customer?.registered_device_id}
- Registered IP: ${caseData.customer?.registered_ip_address}
- Account Opened: ${caseData.customer?.account_open_date}

**Merchant Information:**
- Name: ${caseData.merchant?.merchant_name}
- UPI ID: ${caseData.merchant?.merchant_upi_id}
- Bank: ${caseData.merchant?.merchant_bank_name}
- Branch: ${caseData.merchant?.merchant_bank_branch}
- Address: ${caseData.merchant?.merchant_bank_address}

**Detected Anomalies:**
${caseData.anomalies?.map((a: any) => `- [${a.severity.toUpperCase()}] ${a.type}: ${a.description} (Value: ${a.value})`).join('\n')}

**Behavioral DNA Profile:**
- Amount Range Score: ${caseData.behavioral_dna?.amount_range_score}
- Time Window Pattern: ${caseData.behavioral_dna?.time_window_pattern}
- Device Stability Score: ${caseData.behavioral_dna?.device_stability_score}
- Location Variance: ${caseData.behavioral_dna?.location_variance}
- Merchant Distribution Entropy: ${caseData.behavioral_dna?.merchant_distribution_entropy}

**Risk Score Breakdown:**
- Amount Risk: ${caseData.amount_risk}/100 (weight: 25%)
- Device Risk: ${caseData.device_risk}/100 (weight: 20%)
- Location Risk: ${caseData.location_risk}/100 (weight: 20%)
- Merchant Risk: ${caseData.merchant_risk}/100 (weight: 15%)
- Behavioral Deviation: ${caseData.behavioral_deviation}/100 (weight: 20%)

Generate a comprehensive investigation report for this case.`;

    const response = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${LOVABLE_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-3-flash-preview",
        messages: [
          { role: "system", content: SYSTEM_PROMPT },
          { role: "user", content: userPrompt },
        ],
        stream: true,
      }),
    });

    if (!response.ok) {
      if (response.status === 429) {
        return new Response(JSON.stringify({ error: "Rate limit exceeded. Please try again in a moment." }), {
          status: 429, headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      if (response.status === 402) {
        return new Response(JSON.stringify({ error: "AI credits exhausted. Please add credits in Settings → Workspace → Usage." }), {
          status: 402, headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      const t = await response.text();
      console.error("AI gateway error:", response.status, t);
      return new Response(JSON.stringify({ error: "AI analysis failed" }), {
        status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    return new Response(response.body, {
      headers: { ...corsHeaders, "Content-Type": "text/event-stream" },
    });
  } catch (e) {
    console.error("investigate-case error:", e);
    return new Response(JSON.stringify({ error: e instanceof Error ? e.message : "Unknown error" }), {
      status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
