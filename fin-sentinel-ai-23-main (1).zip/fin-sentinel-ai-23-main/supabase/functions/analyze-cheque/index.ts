import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

const SYSTEM_PROMPT = `You are FinSentinel AI Cheque Analyzer, an expert in Indian banking cheque fraud detection. You analyze cheque images and extract structured data, then perform validation checks.

When given a cheque image, you MUST:

1. **EXTRACT** all visible data from the cheque:
   - Payee name
   - Amount (in words and figures)
   - Date on the cheque
   - Cheque number
   - IFSC code
   - Account number
   - Bank name and branch
   - Drawer/signatory name
   - MICR code (if visible)

2. **VALIDATE** the extracted data and check for:
   - **Signature anomalies**: Describe if signature appears forged, inconsistent, or suspicious
   - **Amount alteration**: Check if amount in words matches figures, look for overwriting or alterations
   - **Date inconsistency**: Check for post-dated, stale-dated (>3 months old), or altered dates
   - **Physical tampering**: Signs of chemical washing, scratching, overwriting, or cut marks
   - **Duplicate indicators**: Unusual cheque number patterns or sequential anomalies

3. **CROSS-REFERENCE** if customer data is provided:
   - Does the account number match?
   - Does the name match the account holder?
   - Is the bank/branch consistent?
   - Is the amount within normal transaction range for this customer?

Return your response as a JSON object with this exact structure (no markdown, just raw JSON):
{
  "extracted_data": {
    "payee_name": "",
    "amount_words": "",
    "amount_figures": "",
    "date": "",
    "cheque_number": "",
    "ifsc_code": "",
    "account_number": "",
    "bank_name": "",
    "branch": "",
    "drawer_name": "",
    "micr_code": ""
  },
  "validation_results": [
    {
      "check": "Signature Analysis",
      "status": "pass|fail|warning",
      "severity": "high|medium|low",
      "details": "explanation"
    }
  ],
  "risk_score": 0,
  "summary": "Brief overall assessment",
  "recommendation": "CLEAR|INVESTIGATE|ESCALATE|BLOCK"
}`;

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { imageBase64, mimeType, customerData } = await req.json();

    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    if (!LOVABLE_API_KEY) throw new Error("LOVABLE_API_KEY is not configured");

    let userPrompt = "Analyze this cheque image. Extract all data and perform validation checks.";
    
    if (customerData) {
      userPrompt += `\n\nCross-reference against this customer's account data:
- Name: ${customerData.full_name}
- Account Number: ${customerData.account_number}
- Bank: ${customerData.bank_name}
- Branch: ${customerData.home_branch}
- IFSC: ${customerData.ifsc_code}
- Account Balance: ₹${customerData.account_balance}
- Average Transaction: ₹${Math.round(customerData.total_transactions_amount / Math.max(customerData.total_transactions_count, 1))}`;
    }

    const messages: any[] = [
      { role: "system", content: SYSTEM_PROMPT },
      {
        role: "user",
        content: [
          { type: "text", text: userPrompt },
          {
            type: "image_url",
            image_url: {
              url: `data:${mimeType || "image/png"};base64,${imageBase64}`,
            },
          },
        ],
      },
    ];

    const response = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${LOVABLE_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-2.5-flash",
        messages,
        temperature: 0.1,
      }),
    });

    if (!response.ok) {
      if (response.status === 429) {
        return new Response(JSON.stringify({ error: "Rate limit exceeded. Please try again in a moment." }), {
          status: 429, headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      if (response.status === 402) {
        return new Response(JSON.stringify({ error: "AI credits exhausted. Please add credits." }), {
          status: 402, headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      const t = await response.text();
      console.error("AI gateway error:", response.status, t);
      return new Response(JSON.stringify({ error: "AI analysis failed" }), {
        status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const result = await response.json();
    let content = result.choices?.[0]?.message?.content || "";
    
    // Strip markdown code fences if present
    content = content.replace(/```json\n?/g, "").replace(/```\n?/g, "").trim();

    let parsed;
    try {
      parsed = JSON.parse(content);
    } catch {
      parsed = {
        extracted_data: {},
        validation_results: [{ check: "Parse Error", status: "warning", severity: "medium", details: "Could not parse AI response. Raw: " + content.slice(0, 200) }],
        risk_score: 50,
        summary: content.slice(0, 500),
        recommendation: "INVESTIGATE",
      };
    }

    return new Response(JSON.stringify(parsed), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (e) {
    console.error("analyze-cheque error:", e);
    return new Response(JSON.stringify({ error: e instanceof Error ? e.message : "Unknown error" }), {
      status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
