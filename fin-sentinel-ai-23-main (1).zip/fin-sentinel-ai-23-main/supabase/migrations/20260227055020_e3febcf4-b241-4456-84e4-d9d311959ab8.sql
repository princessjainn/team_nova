
-- UPI Customers table
CREATE TABLE public.upi_customers (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_uuid TEXT NOT NULL UNIQUE,
  full_name TEXT NOT NULL,
  age INTEGER NOT NULL,
  upi_id TEXT NOT NULL,
  bank_name TEXT NOT NULL,
  account_number TEXT NOT NULL,
  ifsc_code TEXT NOT NULL,
  home_branch TEXT NOT NULL,
  registered_phone_number TEXT NOT NULL,
  registered_device_id TEXT NOT NULL,
  registered_ip_address TEXT NOT NULL,
  account_balance NUMERIC NOT NULL DEFAULT 0,
  last_transaction_amount NUMERIC NOT NULL DEFAULT 0,
  total_transactions_count INTEGER NOT NULL DEFAULT 0,
  total_transactions_amount NUMERIC NOT NULL DEFAULT 0,
  account_open_date DATE NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.upi_customers ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Authenticated users can read customers"
  ON public.upi_customers FOR SELECT
  TO authenticated USING (true);

-- UPI Merchants table
CREATE TABLE public.upi_merchants (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  merchant_uuid TEXT NOT NULL UNIQUE,
  merchant_name TEXT NOT NULL,
  merchant_upi_id TEXT NOT NULL,
  merchant_bank_name TEXT NOT NULL,
  merchant_account_number TEXT NOT NULL,
  merchant_ifsc_code TEXT NOT NULL,
  merchant_bank_branch TEXT NOT NULL,
  merchant_bank_address TEXT NOT NULL,
  merchant_account_open_date DATE NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.upi_merchants ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Authenticated users can read merchants"
  ON public.upi_merchants FOR SELECT
  TO authenticated USING (true);

-- UPI Transactions table
CREATE TABLE public.upi_transactions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  transaction_uuid TEXT NOT NULL UNIQUE,
  customer_uuid TEXT NOT NULL REFERENCES public.upi_customers(customer_uuid),
  merchant_uuid TEXT NOT NULL REFERENCES public.upi_merchants(merchant_uuid),
  transaction_amount NUMERIC NOT NULL,
  transaction_timestamp TIMESTAMPTZ NOT NULL,
  transaction_location TEXT NOT NULL,
  customer_device_id TEXT NOT NULL,
  customer_ip_address TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.upi_transactions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Authenticated users can read transactions"
  ON public.upi_transactions FOR SELECT
  TO authenticated USING (true);

-- Flagged Cases table
CREATE TABLE public.flagged_cases (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  case_id TEXT NOT NULL UNIQUE,
  transaction_uuid TEXT NOT NULL REFERENCES public.upi_transactions(transaction_uuid),
  customer_uuid TEXT NOT NULL REFERENCES public.upi_customers(customer_uuid),
  merchant_uuid TEXT NOT NULL REFERENCES public.upi_merchants(merchant_uuid),
  risk_score INTEGER NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'open' CHECK (status IN ('open', 'investigating', 'resolved', 'escalated')),
  flagged_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  anomalies JSONB NOT NULL DEFAULT '[]',
  behavioral_dna JSONB NOT NULL DEFAULT '{}',
  amount_risk INTEGER NOT NULL DEFAULT 0,
  device_risk INTEGER NOT NULL DEFAULT 0,
  location_risk INTEGER NOT NULL DEFAULT 0,
  merchant_risk INTEGER NOT NULL DEFAULT 0,
  behavioral_deviation INTEGER NOT NULL DEFAULT 0,
  investigation_outcome TEXT,
  ai_reasoning TEXT,
  investigated_by UUID REFERENCES auth.users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.flagged_cases ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Authenticated users can read flagged cases"
  ON public.flagged_cases FOR SELECT
  TO authenticated USING (true);

CREATE POLICY "Authenticated users can update flagged cases"
  ON public.flagged_cases FOR UPDATE
  TO authenticated USING (true);

-- Trigger for updated_at
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SET search_path = public;

CREATE TRIGGER update_flagged_cases_updated_at
  BEFORE UPDATE ON public.flagged_cases
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- Indexes for performance
CREATE INDEX idx_transactions_customer ON public.upi_transactions(customer_uuid);
CREATE INDEX idx_transactions_merchant ON public.upi_transactions(merchant_uuid);
CREATE INDEX idx_flagged_cases_status ON public.flagged_cases(status);
CREATE INDEX idx_flagged_cases_risk ON public.flagged_cases(risk_score DESC);
