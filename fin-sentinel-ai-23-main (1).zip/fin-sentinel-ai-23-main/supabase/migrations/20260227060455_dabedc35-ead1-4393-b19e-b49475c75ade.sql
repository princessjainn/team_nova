
-- Create cheque investigations table
CREATE TABLE public.cheque_investigations (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  investigation_id TEXT NOT NULL UNIQUE,
  image_path TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending',
  extracted_data JSONB NOT NULL DEFAULT '{}'::jsonb,
  validation_results JSONB NOT NULL DEFAULT '[]'::jsonb,
  risk_score INTEGER NOT NULL DEFAULT 0,
  matched_customer_uuid TEXT,
  investigated_by UUID REFERENCES auth.users(id),
  ai_analysis TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.cheque_investigations ENABLE ROW LEVEL SECURITY;

-- Policies
CREATE POLICY "Authenticated users can read cheque investigations"
  ON public.cheque_investigations FOR SELECT TO authenticated
  USING (true);

CREATE POLICY "Authenticated users can insert cheque investigations"
  ON public.cheque_investigations FOR INSERT TO authenticated
  WITH CHECK (true);

CREATE POLICY "Authenticated users can update cheque investigations"
  ON public.cheque_investigations FOR UPDATE TO authenticated
  USING (true) WITH CHECK (true);

-- Trigger for updated_at
CREATE TRIGGER update_cheque_investigations_updated_at
  BEFORE UPDATE ON public.cheque_investigations
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- Storage bucket for cheque images
INSERT INTO storage.buckets (id, name, public) VALUES ('cheque-images', 'cheque-images', false);

-- Storage policies
CREATE POLICY "Authenticated users can upload cheque images"
  ON storage.objects FOR INSERT TO authenticated
  WITH CHECK (bucket_id = 'cheque-images');

CREATE POLICY "Authenticated users can view cheque images"
  ON storage.objects FOR SELECT TO authenticated
  USING (bucket_id = 'cheque-images');
