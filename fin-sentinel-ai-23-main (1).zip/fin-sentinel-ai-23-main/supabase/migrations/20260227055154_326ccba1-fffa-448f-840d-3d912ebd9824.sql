
-- Tighten the update policy to only allow setting investigation fields
DROP POLICY "Authenticated users can update flagged cases" ON public.flagged_cases;

CREATE POLICY "Authenticated users can update flagged cases"
  ON public.flagged_cases FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);
