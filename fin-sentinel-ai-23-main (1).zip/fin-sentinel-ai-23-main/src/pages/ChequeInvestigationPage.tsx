import { useState, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Upload, FileImage, Loader2, AlertTriangle, CheckCircle2, XCircle, Search, Shield, Brain } from 'lucide-react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { fetchCustomers } from '@/data/api';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';
import { Badge } from '@/components/ui/badge';
import { getRiskLevel, getRiskColor } from '@/data/types';
import RiskMeter from '@/components/RiskMeter';

const ANALYZE_URL = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/analyze-cheque`;

interface ValidationResult {
  check: string;
  status: 'pass' | 'fail' | 'warning';
  severity: 'high' | 'medium' | 'low';
  details: string;
}

interface ChequeAnalysis {
  extracted_data: Record<string, string>;
  validation_results: ValidationResult[];
  risk_score: number;
  summary: string;
  recommendation: string;
}

export default function ChequeInvestigationPage() {
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [preview, setPreview] = useState<string | null>(null);
  const [analysis, setAnalysis] = useState<ChequeAnalysis | null>(null);
  const [analyzing, setAnalyzing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [selectedCustomer, setSelectedCustomer] = useState<string>('');
  const [dragOver, setDragOver] = useState(false);

  const { data: customers = [] } = useQuery({ queryKey: ['customers'], queryFn: fetchCustomers });

  const handleFileSelect = useCallback((file: File) => {
    if (!file.type.startsWith('image/')) {
      setError('Please upload an image file (JPG, PNG, etc.)');
      return;
    }
    if (file.size > 10 * 1024 * 1024) {
      setError('File size must be under 10MB');
      return;
    }
    setSelectedFile(file);
    setError(null);
    setAnalysis(null);
    const reader = new FileReader();
    reader.onload = (e) => setPreview(e.target?.result as string);
    reader.readAsDataURL(file);
  }, []);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(false);
    const file = e.dataTransfer.files[0];
    if (file) handleFileSelect(file);
  }, [handleFileSelect]);

  const handleAnalyze = async () => {
    if (!selectedFile || !preview) return;
    setAnalyzing(true);
    setError(null);

    try {
      const base64 = preview.split(',')[1];
      const customerData = selectedCustomer
        ? customers.find((c: any) => c.customer_uuid === selectedCustomer)
        : undefined;

      const resp = await fetch(ANALYZE_URL, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY}`,
        },
        body: JSON.stringify({
          imageBase64: base64,
          mimeType: selectedFile.type,
          customerData,
        }),
      });

      if (!resp.ok) {
        const errBody = await resp.json().catch(() => ({ error: 'Analysis failed' }));
        throw new Error(errBody.error || `Request failed (${resp.status})`);
      }

      const result: ChequeAnalysis = await resp.json();
      setAnalysis(result);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Unknown error');
    } finally {
      setAnalyzing(false);
    }
  };

  const statusIcon = (status: string) => {
    switch (status) {
      case 'pass': return <CheckCircle2 className="w-4 h-4 text-success" />;
      case 'fail': return <XCircle className="w-4 h-4 text-destructive" />;
      default: return <AlertTriangle className="w-4 h-4 text-warning" />;
    }
  };

  const recColors: Record<string, string> = {
    CLEAR: 'bg-success/10 text-success border-success/30',
    INVESTIGATE: 'bg-warning/10 text-warning border-warning/30',
    ESCALATE: 'bg-destructive/10 text-destructive border-destructive/30',
    BLOCK: 'bg-destructive/10 text-destructive border-destructive/30',
  };

  return (
    <div className="p-6 max-w-[1400px] mx-auto space-y-6">
      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
        <h1 className="text-2xl font-bold text-foreground">Cheque Investigation</h1>
        <p className="text-sm text-muted-foreground mt-1">Upload a cheque image for AI-powered fraud analysis and OCR extraction</p>
      </motion.div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Upload area */}
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="space-y-4">
          <div
            onDragOver={(e) => { e.preventDefault(); setDragOver(true); }}
            onDragLeave={() => setDragOver(false)}
            onDrop={handleDrop}
            className={cn(
              "glass-card p-8 border-2 border-dashed transition-all duration-300 cursor-pointer flex flex-col items-center justify-center min-h-[300px]",
              dragOver ? "border-primary bg-primary/5" : "border-border/50 hover:border-primary/30",
              preview && "p-4 min-h-0"
            )}
            onClick={() => {
              if (!preview) {
                const input = document.createElement('input');
                input.type = 'file';
                input.accept = 'image/*';
                input.onchange = (e) => {
                  const file = (e.target as HTMLInputElement).files?.[0];
                  if (file) handleFileSelect(file);
                };
                input.click();
              }
            }}
          >
            {preview ? (
              <div className="w-full space-y-3">
                <div className="relative rounded-lg overflow-hidden border border-border/30">
                  <img src={preview} alt="Cheque preview" className="w-full object-contain max-h-[400px]" />
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <FileImage className="w-4 h-4 text-primary" />
                    <span className="text-xs text-muted-foreground truncate max-w-[200px]">{selectedFile?.name}</span>
                  </div>
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      setSelectedFile(null);
                      setPreview(null);
                      setAnalysis(null);
                    }}
                    className="text-xs text-muted-foreground hover:text-destructive transition-colors"
                  >
                    Remove
                  </button>
                </div>
              </div>
            ) : (
              <>
                <Upload className="w-10 h-10 text-muted-foreground mb-3" />
                <p className="text-sm font-medium text-foreground">Drop cheque image here</p>
                <p className="text-xs text-muted-foreground mt-1">or click to browse • JPG, PNG up to 10MB</p>
              </>
            )}
          </div>

          {/* Customer cross-reference */}
          <div className="glass-card p-4 space-y-3">
            <div className="flex items-center gap-2">
              <Search className="w-4 h-4 text-primary" />
              <span className="text-xs font-medium text-muted-foreground uppercase tracking-wider">Cross-Reference Customer (Optional)</span>
            </div>
            <select
              value={selectedCustomer}
              onChange={(e) => setSelectedCustomer(e.target.value)}
              className="w-full bg-secondary border border-border rounded-lg px-3 py-2 text-sm text-foreground focus:outline-none focus:ring-1 focus:ring-primary"
            >
              <option value="">— Select customer to verify against —</option>
              {customers.map((c: any) => (
                <option key={c.customer_uuid} value={c.customer_uuid}>
                  {c.full_name} • {c.account_number} • {c.bank_name}
                </option>
              ))}
            </select>
          </div>

          <Button
            onClick={handleAnalyze}
            disabled={!selectedFile || analyzing}
            className="w-full gap-2 bg-primary text-primary-foreground hover:bg-primary/90"
          >
            {analyzing ? (
              <><Loader2 className="w-4 h-4 animate-spin" />Analyzing Cheque...</>
            ) : (
              <><Brain className="w-4 h-4" />Run AI Cheque Analysis</>
            )}
          </Button>

          {error && (
            <div className="p-3 rounded-lg bg-destructive/10 border border-destructive/20 text-xs text-destructive flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 flex-shrink-0" />
              {error}
            </div>
          )}
        </motion.div>

        {/* Results */}
        <AnimatePresence mode="wait">
          {analyzing && !analysis && (
            <motion.div key="loading" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
              className="glass-card p-8 flex flex-col items-center justify-center gap-4">
              <Loader2 className="w-8 h-8 text-primary animate-spin" />
              <div className="text-center">
                <p className="text-sm font-medium text-foreground">Analyzing cheque image...</p>
                <p className="text-xs text-muted-foreground mt-1">Extracting data, checking for alterations, and validating signatures</p>
              </div>
            </motion.div>
          )}

          {analysis && (
            <motion.div key="results" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="space-y-4">
              {/* Summary header */}
              <div className="glass-card p-4 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <Shield className="w-5 h-5 text-primary" />
                  <div>
                    <p className="text-xs text-muted-foreground uppercase tracking-wider">Recommendation</p>
                    <Badge variant="outline" className={cn('text-xs border mt-1', recColors[analysis.recommendation] || recColors.INVESTIGATE)}>
                      {analysis.recommendation}
                    </Badge>
                  </div>
                </div>
                <RiskMeter score={analysis.risk_score} size="md" />
              </div>

              {/* Summary */}
              <div className="glass-card p-4">
                <p className="text-xs text-muted-foreground uppercase tracking-wider mb-2">AI Summary</p>
                <p className="text-sm text-foreground/90 leading-relaxed">{analysis.summary}</p>
              </div>

              {/* Extracted data */}
              <div className="glass-card p-4">
                <p className="text-xs text-muted-foreground uppercase tracking-wider mb-3">Extracted Data</p>
                <div className="space-y-2 text-xs">
                  {Object.entries(analysis.extracted_data).filter(([, v]) => v).map(([k, v]) => (
                    <div key={k} className="flex justify-between">
                      <span className="text-muted-foreground capitalize">{k.replace(/_/g, ' ')}</span>
                      <span className="font-mono text-foreground text-right max-w-[60%]">{v}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Validation checks */}
              <div className="glass-card p-4">
                <p className="text-xs text-muted-foreground uppercase tracking-wider mb-3">Validation Checks</p>
                <div className="space-y-3">
                  {analysis.validation_results.map((v, i) => (
                    <div key={i} className={cn(
                      "p-3 rounded-lg border",
                      v.status === 'pass' ? 'bg-success/5 border-success/20' :
                      v.status === 'fail' ? 'bg-destructive/5 border-destructive/20' :
                      'bg-warning/5 border-warning/20'
                    )}>
                      <div className="flex items-center gap-2 mb-1">
                        {statusIcon(v.status)}
                        <span className="text-xs font-medium text-foreground">{v.check}</span>
                        <Badge variant="outline" className={cn('text-[10px] ml-auto border',
                          v.severity === 'high' ? 'border-destructive/30 text-destructive' :
                          v.severity === 'medium' ? 'border-warning/30 text-warning' :
                          'border-success/30 text-success'
                        )}>
                          {v.severity.toUpperCase()}
                        </Badge>
                      </div>
                      <p className="text-xs text-muted-foreground pl-6">{v.details}</p>
                    </div>
                  ))}
                </div>
              </div>
            </motion.div>
          )}

          {!analysis && !analyzing && (
            <motion.div key="empty" initial={{ opacity: 0 }} animate={{ opacity: 1 }}
              className="glass-card p-8 flex flex-col items-center justify-center gap-3 text-center">
              <FileImage className="w-12 h-12 text-muted-foreground/30" />
              <p className="text-sm text-muted-foreground">Upload a cheque image to begin analysis</p>
              <p className="text-xs text-muted-foreground/70">The AI will extract data, detect alterations, and validate against customer records</p>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
