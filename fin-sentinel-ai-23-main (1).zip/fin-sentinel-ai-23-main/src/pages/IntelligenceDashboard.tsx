import { motion } from 'framer-motion';
import { useQuery } from '@tanstack/react-query';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, RadarChart, PolarGrid, PolarAngleAxis, Radar } from 'recharts';
import { Loader2, MapPin, Smartphone, Shield, TrendingUp, ShieldAlert } from 'lucide-react';
import { fetchFlaggedCases, fetchTransactions, fetchCustomers, fetchMerchants } from '@/data/api';
import StatCard from '@/components/StatCard';
import EfficiencyMetrics from '@/components/EfficiencyMetrics';
import IndiaFraudMap from '@/components/IndiaFraudMap';
import FraudResponseSimulation from '@/components/FraudResponseSimulation';
import { cn } from '@/lib/utils';

const CustomTooltip = ({ active, payload, label }: any) => {
  if (!active || !payload) return null;
  return (
    <div className="glass-card p-3 text-xs">
      <p className="text-foreground font-medium mb-1">{label}</p>
      {payload.map((p: any, i: number) => (
        <p key={i} className="text-muted-foreground">
          {p.name}: <span className="text-foreground font-mono">{p.value}</span>
        </p>
      ))}
    </div>
  );
};

export default function IntelligenceDashboard() {
  const { data: cases = [], isLoading: cl } = useQuery({ queryKey: ['flaggedCases'], queryFn: fetchFlaggedCases });
  const { data: txns = [], isLoading: tl } = useQuery({ queryKey: ['transactions'], queryFn: fetchTransactions });
  const { data: customers = [] } = useQuery({ queryKey: ['customers'], queryFn: fetchCustomers });
  const { data: merchants = [] } = useQuery({ queryKey: ['merchants'], queryFn: fetchMerchants });

  if (cl || tl) return <div className="flex items-center justify-center h-96"><Loader2 className="w-6 h-6 text-primary animate-spin" /></div>;

  // Fraud type distribution
  const fraudTypes: Record<string, number> = {};
  cases.forEach((c: any) => {
    (c.anomalies || []).forEach((a: any) => {
      fraudTypes[a.type] = (fraudTypes[a.type] || 0) + 1;
    });
  });
  const fraudTypeData = Object.entries(fraudTypes).map(([name, count]) => ({ name, count })).sort((a, b) => b.count - a.count);

  // Device-based fraud %
  const deviceCases = cases.filter((c: any) => (c.anomalies || []).some((a: any) => a.type.includes('Device'))).length;
  const devicePct = cases.length ? Math.round((deviceCases / cases.length) * 100) : 0;

  // City-wise fraud heatmap (from transactions)
  const cityMap: Record<string, number> = {};
  const flaggedTxnIds = new Set(cases.map((c: any) => c.transaction_uuid));
  txns.forEach((t: any) => {
    if (flaggedTxnIds.has(t.transaction_uuid)) {
      const city = t.transaction_location || 'Unknown';
      cityMap[city] = (cityMap[city] || 0) + 1;
    }
  });
  const cityData = Object.entries(cityMap).map(([city, count]) => ({ city, count })).sort((a, b) => b.count - a.count);

  // Merchant risk ranking
  const merchantFlags: Record<string, number> = {};
  cases.forEach((c: any) => { merchantFlags[c.merchant_uuid] = (merchantFlags[c.merchant_uuid] || 0) + 1; });
  const merchantRiskData = Object.entries(merchantFlags)
    .map(([id, count]) => {
      const m = merchants.find((me: any) => me.merchant_uuid === id);
      return { name: m?.merchant_name || id, flags: count };
    })
    .sort((a, b) => b.flags - a.flags);

  // Location risk distribution (group by risk level per city)
  const cityRiskDetails: Record<string, { total: number; highRisk: number; avgRisk: number; totalAmount: number }> = {};
  cases.forEach((c: any) => {
    const txn = txns.find((t: any) => t.transaction_uuid === c.transaction_uuid);
    const city = txn?.transaction_location || 'Unknown';
    if (!cityRiskDetails[city]) cityRiskDetails[city] = { total: 0, highRisk: 0, avgRisk: 0, totalAmount: 0 };
    cityRiskDetails[city].total++;
    if (c.risk_score >= 75) cityRiskDetails[city].highRisk++;
    cityRiskDetails[city].avgRisk += c.risk_score;
    cityRiskDetails[city].totalAmount += Number(txn?.transaction_amount || 0);
  });
  Object.values(cityRiskDetails).forEach(d => { d.avgRisk = Math.round(d.avgRisk / d.total); });

  const locationRiskData = Object.entries(cityRiskDetails)
    .map(([city, d]) => ({ city, ...d }))
    .sort((a, b) => b.avgRisk - a.avgRisk);

  // Location-based fraud % (cases with location_risk >= 60)
  const locationFraudCases = cases.filter((c: any) => c.location_risk >= 60).length;
  const locationFraudPct = cases.length ? Math.round((locationFraudCases / cases.length) * 100) : 0;

  // Risk radar
  const avgRisks = cases.length ? {
    amount: Math.round(cases.reduce((a: number, c: any) => a + c.amount_risk, 0) / cases.length),
    device: Math.round(cases.reduce((a: number, c: any) => a + c.device_risk, 0) / cases.length),
    location: Math.round(cases.reduce((a: number, c: any) => a + c.location_risk, 0) / cases.length),
    merchant: Math.round(cases.reduce((a: number, c: any) => a + c.merchant_risk, 0) / cases.length),
    behavioral: Math.round(cases.reduce((a: number, c: any) => a + c.behavioral_deviation, 0) / cases.length),
  } : { amount: 0, device: 0, location: 0, merchant: 0, behavioral: 0 };

  const radarData = [
    { subject: 'Amount', A: avgRisks.amount },
    { subject: 'Device', A: avgRisks.device },
    { subject: 'Location', A: avgRisks.location },
    { subject: 'Merchant', A: avgRisks.merchant },
    { subject: 'Behavioral', A: avgRisks.behavioral },
  ];

  return (
    <div className="p-6 max-w-[1400px] mx-auto space-y-6">
      <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }}>
        <h1 className="text-2xl font-bold text-foreground tracking-tight">Intelligence Dashboard</h1>
        <p className="text-sm text-muted-foreground mt-1">Organizational fraud intelligence & analytics</p>
      </motion.div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
        <StatCard title="Device Fraud" value={`${devicePct}%`} icon={Smartphone} variant="warning" subtitle={`${deviceCases} of ${cases.length} cases`} />
        <StatCard title="Location Fraud" value={`${locationFraudPct}%`} icon={MapPin} variant="danger" subtitle={`${locationFraudCases} location-risk cases`} />
        <StatCard title="Cities Affected" value={Object.keys(cityMap).length} icon={MapPin} subtitle="Unique locations" />
        <StatCard title="High Risk Merchants" value={merchantRiskData.filter(m => m.flags >= 2).length} icon={Shield} variant="danger" />
        <StatCard title="Avg Risk Score" value={cases.length ? Math.round(cases.reduce((a: number, c: any) => a + c.risk_score, 0) / cases.length) : 0} icon={TrendingUp} variant="warning" />
      </div>

      <EfficiencyMetrics />

      {/* Location Intelligence Section */}
      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.15 }} className="glass-card p-5">
        <h3 className="text-xs font-medium text-muted-foreground uppercase tracking-wider mb-4 flex items-center gap-2">
          <MapPin className="w-4 h-4 text-destructive" />Location Intelligence & Risk Mapping
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {locationRiskData.map((loc, i) => (
            <div key={loc.city} className={cn(
              'p-4 rounded-lg border space-y-3',
              loc.avgRisk >= 75 ? 'bg-destructive/5 border-destructive/20' : loc.avgRisk >= 50 ? 'bg-warning/5 border-warning/20' : 'bg-secondary/50 border-border/50'
            )}>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <MapPin className={cn('w-4 h-4', loc.avgRisk >= 75 ? 'text-destructive' : loc.avgRisk >= 50 ? 'text-warning' : 'text-primary')} />
                  <span className="text-sm font-medium text-foreground">{loc.city}</span>
                </div>
                <span className={cn(
                  'text-[10px] font-mono font-bold px-2 py-0.5 rounded',
                  loc.avgRisk >= 75 ? 'bg-destructive/10 text-destructive' : loc.avgRisk >= 50 ? 'bg-warning/10 text-warning' : 'bg-primary/10 text-primary'
                )}>
                  Risk: {loc.avgRisk}
                </span>
              </div>
              <div className="grid grid-cols-3 gap-2 text-center">
                <div>
                  <p className="text-[10px] text-muted-foreground uppercase">Cases</p>
                  <p className="text-sm font-mono text-foreground">{loc.total}</p>
                </div>
                <div>
                  <p className="text-[10px] text-muted-foreground uppercase">High Risk</p>
                  <p className="text-sm font-mono text-destructive">{loc.highRisk}</p>
                </div>
                <div>
                  <p className="text-[10px] text-muted-foreground uppercase">Amount</p>
                  <p className="text-sm font-mono text-foreground">₹{(loc.totalAmount / 1000).toFixed(0)}K</p>
                </div>
              </div>
              <div className="h-1.5 rounded-full bg-secondary overflow-hidden">
                <motion.div
                  className="h-full rounded-full"
                  style={{ backgroundColor: loc.avgRisk >= 75 ? 'hsl(0, 72%, 55%)' : loc.avgRisk >= 50 ? 'hsl(38, 92%, 55%)' : 'hsl(175, 80%, 50%)' }}
                  initial={{ width: 0 }}
                  animate={{ width: `${loc.avgRisk}%` }}
                  transition={{ duration: 0.8, delay: i * 0.1 }}
                />
              </div>
            </div>
          ))}
        </div>
      </motion.div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Fraud Type Distribution */}
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.2 }} className="glass-card p-5">
          <h3 className="text-xs font-medium text-muted-foreground uppercase tracking-wider mb-4">Fraud Type Distribution</h3>
          <ResponsiveContainer width="100%" height={200}>
            <BarChart data={fraudTypeData}>
              <XAxis dataKey="name" tick={{ fontSize: 9, fill: 'hsl(215, 14%, 50%)' }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 10, fill: 'hsl(215, 14%, 50%)' }} axisLine={false} tickLine={false} />
              <Tooltip content={<CustomTooltip />} />
              <Bar dataKey="count" fill="hsl(175, 80%, 50%)" radius={[4, 4, 0, 0]} barSize={24} />
            </BarChart>
          </ResponsiveContainer>
        </motion.div>

        {/* City Map */}
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.3 }} className="glass-card p-5">
          <h3 className="text-xs font-medium text-muted-foreground uppercase tracking-wider mb-4 flex items-center gap-2">
            <MapPin className="w-4 h-4 text-destructive" />City-wise Fraud Map
          </h3>
          <IndiaFraudMap data={locationRiskData} />
        </motion.div>

        {/* Risk Radar */}
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.4 }} className="glass-card p-5">
          <h3 className="text-xs font-medium text-muted-foreground uppercase tracking-wider mb-4">Risk Category Radar</h3>
          <ResponsiveContainer width="100%" height={220}>
            <RadarChart data={radarData}>
              <PolarGrid stroke="hsl(220, 14%, 16%)" />
              <PolarAngleAxis dataKey="subject" tick={{ fontSize: 10, fill: 'hsl(215, 14%, 50%)' }} />
              <Radar name="Avg Risk" dataKey="A" stroke="hsl(175, 80%, 50%)" fill="hsl(175, 80%, 50%)" fillOpacity={0.2} />
            </RadarChart>
          </ResponsiveContainer>
        </motion.div>
      </div>

      {/* Merchant Risk Ranking */}
      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.5 }} className="glass-card p-5">
        <h3 className="text-xs font-medium text-muted-foreground uppercase tracking-wider mb-4">Merchant Risk Ranking</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
          {merchantRiskData.map((m, i) => (
            <div key={m.name} className={cn(
              'p-3 rounded-lg border flex items-center justify-between',
              m.flags >= 3 ? 'bg-destructive/5 border-destructive/20' : m.flags >= 2 ? 'bg-warning/5 border-warning/20' : 'bg-secondary/50 border-border/50'
            )}>
              <div>
                <p className="text-xs font-medium text-foreground">{m.name}</p>
                <p className="text-[10px] text-muted-foreground">{m.flags} flagged cases</p>
              </div>
              <span className={cn(
                'text-[10px] font-mono font-bold px-2 py-0.5 rounded',
                m.flags >= 3 ? 'bg-destructive/10 text-destructive' : m.flags >= 2 ? 'bg-warning/10 text-warning' : 'bg-info/10 text-info'
              )}>
                #{i + 1}
              </span>
            </div>
          ))}
        </div>
      </motion.div>

      {/* Fraud Response & Escalation Simulation */}
      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.6 }} className="glass-card p-5">
        <h3 className="text-xs font-medium text-muted-foreground uppercase tracking-wider mb-4 flex items-center gap-2">
          <ShieldAlert className="w-4 h-4 text-destructive" />Fraud Response & Escalation Simulation — RakshakAI
        </h3>
        <FraudResponseSimulation />
      </motion.div>
    </div>
  );
}
