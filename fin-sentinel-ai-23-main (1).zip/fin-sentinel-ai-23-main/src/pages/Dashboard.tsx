import { motion } from 'framer-motion';
import { AlertTriangle, TrendingUp, FileSearch, Activity, Zap, Loader2 } from 'lucide-react';
import { useQuery } from '@tanstack/react-query';
import StatCard from '@/components/StatCard';
import CaseCard from '@/components/CaseCard';
import { RiskDistributionChart, AnomalyTypesChart, CaseTimelineChart } from '@/components/DashboardCharts';
import { fetchFlaggedCases, fetchTransactions } from '@/data/api';

export default function Dashboard() {
  const { data: cases = [], isLoading: casesLoading } = useQuery({ queryKey: ['flaggedCases'], queryFn: fetchFlaggedCases });
  const { data: txns = [], isLoading: txnsLoading } = useQuery({ queryKey: ['transactions'], queryFn: fetchTransactions });

  const loading = casesLoading || txnsLoading;

  const stats = {
    totalCases: cases.length,
    openCases: cases.filter((c: any) => c.status === 'open').length,
    highRiskCount: cases.filter((c: any) => c.risk_score >= 70).length,
    avgRiskScore: cases.length ? Math.round(cases.reduce((a: number, c: any) => a + c.risk_score, 0) / cases.length) : 0,
    totalFlaggedAmount: txns.filter((t: any) => cases.some((c: any) => c.transaction_uuid === t.transaction_uuid)).reduce((a: number, t: any) => a + Number(t.transaction_amount), 0),
  };

  if (loading) return (
    <div className="flex items-center justify-center h-96">
      <Loader2 className="w-6 h-6 text-primary animate-spin" />
    </div>
  );

  return (
    <div className="p-6 space-y-6 max-w-[1400px] mx-auto">
      <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground tracking-tight">Investigation Dashboard</h1>
          <p className="text-sm text-muted-foreground mt-1">Real-time UPI & cheque fraud monitoring</p>
        </div>
        <div className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-primary/10 border border-primary/20">
          <div className="w-2 h-2 rounded-full bg-primary animate-pulse" />
          <span className="text-xs font-mono text-primary">LIVE</span>
        </div>
      </motion.div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard title="Total Cases" value={stats.totalCases} icon={FileSearch} subtitle={`${stats.openCases} open`} />
        <StatCard title="High Risk" value={stats.highRiskCount} icon={AlertTriangle} variant="danger" subtitle="Score ≥ 70" />
        <StatCard title="Avg Risk Score" value={stats.avgRiskScore} icon={TrendingUp} variant="warning" />
        <StatCard title="Flagged Volume" value={`₹${(stats.totalFlaggedAmount / 100000).toFixed(1)}L`} icon={Activity} variant="success" subtitle={`${cases.length} transactions`} />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <RiskDistributionChart />
        <AnomalyTypesChart />
        <CaseTimelineChart />
      </div>

      <div>
        <div className="flex items-center gap-2 mb-4">
          <Zap className="w-4 h-4 text-primary" />
          <h2 className="text-sm font-medium text-muted-foreground uppercase tracking-wider">Flagged Cases</h2>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
          {cases.map((c: any, i: number) => (
            <CaseCard key={c.case_id} flaggedCase={c} index={i} />
          ))}
        </div>
      </div>
    </div>
  );
}
