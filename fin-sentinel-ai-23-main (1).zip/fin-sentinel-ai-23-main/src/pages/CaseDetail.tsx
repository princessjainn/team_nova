import { useParams, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ArrowLeft, AlertTriangle, User, Store, Cpu, Shield, Brain, FileText, Sparkles, Loader2, Download, Zap, Target, Network, FlaskConical, ClipboardList, MessageCircle, TrendingUp } from 'lucide-react';
import { useQuery } from '@tanstack/react-query';
import { fetchCaseById, fetchCustomerByUuid, fetchMerchantByUuid, fetchTransactionByUuid } from '@/data/api';
import { getRiskLevel, getRiskColor } from '@/data/types';
import { cn } from '@/lib/utils';
import RiskMeter from '@/components/RiskMeter';
import { InvestigationSection, AnomalyList, RiskBreakdownBar } from '@/components/InvestigationPanels';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { useAIInvestigation } from '@/hooks/useAIInvestigation';
import ReactMarkdown from 'react-markdown';
import { exportCasePdf } from '@/lib/exportPdf';
import ActionRecommendation from '@/components/ActionRecommendation';
import TrustScorePanel from '@/components/TrustScorePanel';
import FraudNetworkGraph from '@/components/FraudNetworkGraph';
import CounterActionSimulation from '@/components/CounterActionSimulation';
import FuturePrediction from '@/components/FuturePrediction';
import ConfidenceMeter from '@/components/ConfidenceMeter';
import CaseMemory from '@/components/CaseMemory';
import AuditTrail from '@/components/AuditTrail';
import AICopilot from '@/components/AICopilot';

export default function CaseDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { report, isAnalyzing, error: aiError, analyze } = useAIInvestigation();

  const { data: caseData, isLoading: caseLoading } = useQuery({
    queryKey: ['case', id], queryFn: () => fetchCaseById(id!), enabled: !!id,
  });
  const { data: customer } = useQuery({
    queryKey: ['customer', caseData?.customer_uuid],
    queryFn: () => fetchCustomerByUuid(caseData!.customer_uuid),
    enabled: !!caseData?.customer_uuid,
  });
  const { data: merchant } = useQuery({
    queryKey: ['merchant', caseData?.merchant_uuid],
    queryFn: () => fetchMerchantByUuid(caseData!.merchant_uuid),
    enabled: !!caseData?.merchant_uuid,
  });
  const { data: txn } = useQuery({
    queryKey: ['transaction', caseData?.transaction_uuid],
    queryFn: () => fetchTransactionByUuid(caseData!.transaction_uuid),
    enabled: !!caseData?.transaction_uuid,
  });

  if (caseLoading) return (
    <div className="flex items-center justify-center h-96"><Loader2 className="w-6 h-6 text-primary animate-spin" /></div>
  );
  if (!caseData) return (
    <div className="flex items-center justify-center h-screen"><p className="text-muted-foreground">Case not found</p></div>
  );

  const riskLevel = getRiskLevel(caseData.risk_score);
  const statusColors: Record<string, string> = {
    open: 'bg-info/10 text-info border-info/30',
    investigating: 'bg-warning/10 text-warning border-warning/30',
    escalated: 'bg-destructive/10 text-destructive border-destructive/30',
    resolved: 'bg-success/10 text-success border-success/30',
  };

  const handleAnalyze = () => {
    analyze({ ...caseData, customer, merchant, transaction: txn });
  };

  const hasRepeatFlagging = (caseData.anomalies || []).some((a: any) => a.type === 'Repeat Flagging');

  return (
    <div className="p-6 max-w-[1400px] mx-auto space-y-6">
      {/* Header */}
      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="flex items-center gap-4">
        <button onClick={() => navigate(-1)} className="w-9 h-9 rounded-lg bg-secondary flex items-center justify-center hover:bg-secondary/80 transition-colors">
          <ArrowLeft className="w-4 h-4 text-foreground" />
        </button>
        <div className="flex-1">
          <div className="flex items-center gap-3">
            <h1 className="text-xl font-bold text-foreground">{caseData.case_id}</h1>
            <Badge variant="outline" className={cn('text-[10px] border', statusColors[caseData.status])}>
              {caseData.status.toUpperCase()}
            </Badge>
          </div>
          <p className="text-xs text-muted-foreground mt-0.5">
            Flagged {new Date(caseData.flagged_at).toLocaleString('en-IN')} • {txn?.transaction_uuid}
          </p>
        </div>
        <Button onClick={handleAnalyze} disabled={isAnalyzing} className="gap-2 bg-primary text-primary-foreground hover:bg-primary/90">
          {isAnalyzing ? <><Loader2 className="w-4 h-4 animate-spin" />Analyzing...</> : <><Sparkles className="w-4 h-4" />Run AI Analysis</>}
        </Button>
        <Button
          variant="outline"
          onClick={() => exportCasePdf({ caseData, customer, merchant, transaction: txn, aiReport: report || undefined })}
          className="gap-2 border-border text-muted-foreground hover:text-foreground"
        >
          <Download className="w-4 h-4" />Export PDF
        </Button>
        <RiskMeter score={caseData.risk_score} size="md" />
      </motion.div>

      {/* AI Report */}
      {(report || isAnalyzing || aiError) && (
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="glass-card p-6 border-primary/30" style={{ boxShadow: '0 0 30px hsl(175 80% 50% / 0.1)' }}>
          <div className="flex items-center gap-2 mb-4">
            <Brain className="w-5 h-5 text-primary" />
            <h2 className="text-sm font-medium text-primary uppercase tracking-wider">GenAI Investigation Report</h2>
            {isAnalyzing && <div className="flex items-center gap-1.5 ml-auto"><div className="w-2 h-2 rounded-full bg-primary animate-pulse" /><span className="text-xs font-mono text-primary">STREAMING</span></div>}
          </div>
          {aiError && <div className="p-3 rounded-lg bg-destructive/10 border border-destructive/20 text-sm text-destructive">{aiError}</div>}
          {report && (
            <div className="prose prose-sm prose-invert max-w-none text-xs leading-relaxed [&_h2]:text-sm [&_h2]:font-semibold [&_h2]:text-primary [&_h2]:mt-5 [&_h2]:mb-2 [&_h1]:text-base [&_h1]:text-primary [&_strong]:text-foreground [&_li]:text-foreground/80 [&_p]:text-foreground/80 [&_ul]:my-1 [&_ol]:my-1">
              <ReactMarkdown>{report}</ReactMarkdown>
            </div>
          )}
          {isAnalyzing && !report && (
            <div className="flex items-center gap-3 py-8 justify-center text-muted-foreground">
              <Loader2 className="w-5 h-5 animate-spin text-primary" />
              <span className="text-sm">Analyzing transaction data and generating investigation report...</span>
            </div>
          )}
        </motion.div>
      )}

      {/* Action Recommendation */}
      <InvestigationSection title="Recommended Action" icon={<Zap className="w-4 h-4 text-warning" />} delay={0.05}>
        <ActionRecommendation
          riskScore={caseData.risk_score}
          anomalies={caseData.anomalies}
          customerName={customer?.full_name}
          transactionAmount={txn ? Number(txn.transaction_amount) : undefined}
          transactionLocation={txn?.transaction_location}
          transactionTime={txn?.transaction_timestamp}
        />
      </InvestigationSection>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Left Column */}
        <div className="lg:col-span-2 space-y-4">
          <InvestigationSection title="Transaction Summary" icon={<FileText className="w-4 h-4 text-primary" />} delay={0.1}>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {[
                { label: 'Amount', value: txn ? `₹${Number(txn.transaction_amount).toLocaleString('en-IN')}` : '-' },
                { label: 'Time', value: txn ? new Date(txn.transaction_timestamp).toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' }) : '-' },
                { label: 'Location', value: txn?.transaction_location || '-' },
                { label: 'Device', value: txn?.customer_device_id || '-' },
              ].map((item, i) => (
                <div key={i}>
                  <p className="text-[10px] text-muted-foreground uppercase tracking-wider">{item.label}</p>
                  <p className="text-sm font-mono text-foreground mt-0.5">{item.value}</p>
                </div>
              ))}
            </div>
          </InvestigationSection>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <InvestigationSection title="Customer Profile" icon={<User className="w-4 h-4 text-primary" />} delay={0.15}>
              <div className="space-y-2 text-xs">
                {customer && [
                  ['Name', customer.full_name],
                  ['UPI ID', customer.upi_id],
                  ['Bank', customer.bank_name],
                  ['Branch', customer.home_branch],
                  ['Balance', `₹${Number(customer.account_balance).toLocaleString('en-IN')}`],
                  ['Reg. Device', customer.registered_device_id],
                  ['Reg. IP', customer.registered_ip_address],
                ].map(([k, v], i) => (
                  <div key={i} className="flex justify-between">
                    <span className="text-muted-foreground">{k}</span>
                    <span className="font-mono text-foreground">{v}</span>
                  </div>
                ))}
              </div>
            </InvestigationSection>

            <InvestigationSection title="Merchant Info" icon={<Store className="w-4 h-4 text-primary" />} delay={0.2}>
              <div className="space-y-2 text-xs">
                {merchant && [
                  ['Name', merchant.merchant_name],
                  ['UPI ID', merchant.merchant_upi_id],
                  ['Bank', merchant.merchant_bank_name],
                  ['Branch', merchant.merchant_bank_branch],
                  ['Address', merchant.merchant_bank_address],
                ].map(([k, v], i) => (
                  <div key={i} className="flex justify-between">
                    <span className="text-muted-foreground">{k}</span>
                    <span className="font-mono text-foreground text-right max-w-[60%] truncate">{v}</span>
                  </div>
                ))}
              </div>
            </InvestigationSection>
          </div>

          <InvestigationSection title="Detected Anomalies" icon={<AlertTriangle className="w-4 h-4 text-destructive" />} delay={0.25}>
            <AnomalyList anomalies={caseData.anomalies} />
          </InvestigationSection>

          <InvestigationSection title="Behavioral DNA Profile" icon={<Cpu className="w-4 h-4 text-primary" />} delay={0.3}>
            <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
              {[
                { label: 'Amount Range', value: caseData.behavioral_dna.amount_range_score },
                { label: 'Time Pattern', value: caseData.behavioral_dna.time_window_pattern },
                { label: 'Device Stability', value: caseData.behavioral_dna.device_stability_score },
                { label: 'Location Var.', value: caseData.behavioral_dna.location_variance },
                { label: 'Merchant Entropy', value: caseData.behavioral_dna.merchant_distribution_entropy },
              ].map((item, i) => (
                <div key={i} className="text-center p-3 rounded-lg bg-secondary/50">
                  <p className="text-[10px] text-muted-foreground uppercase">{item.label}</p>
                  <p className="text-sm font-mono text-foreground mt-1">{item.value}</p>
                </div>
              ))}
            </div>
          </InvestigationSection>

          {/* Counter-Action Simulation */}
          <InvestigationSection title="Counter-Action Simulation" icon={<FlaskConical className="w-4 h-4 text-warning" />} delay={0.35}>
            <CounterActionSimulation
              riskScore={caseData.risk_score}
              transactionAmount={txn ? Number(txn.transaction_amount) : 0}
              anomalyCount={caseData.anomalies?.length || 0}
            />
          </InvestigationSection>

          {/* Fraud Network */}
          <InvestigationSection title="Fraud Network Analysis" icon={<Network className="w-4 h-4 text-destructive" />} delay={0.4}>
            <FraudNetworkGraph
              caseId={caseData.case_id}
              customerUuid={caseData.customer_uuid}
              deviceId={txn?.customer_device_id}
              ipAddress={txn?.customer_ip_address}
              merchantUuid={caseData.merchant_uuid}
            />
          </InvestigationSection>
        </div>

        {/* Right Column */}
        <div className="space-y-4">
          <InvestigationSection title="Risk Score Breakdown" icon={<Shield className="w-4 h-4 text-warning" />} delay={0.15}>
            <div className="space-y-3">
              <RiskBreakdownBar label="Amount Risk (25%)" value={caseData.amount_risk} color="hsl(0, 72%, 55%)" />
              <RiskBreakdownBar label="Device Risk (20%)" value={caseData.device_risk} color="hsl(38, 92%, 55%)" />
              <RiskBreakdownBar label="Location Risk (20%)" value={caseData.location_risk} color="hsl(210, 80%, 55%)" />
              <RiskBreakdownBar label="Merchant Risk (15%)" value={caseData.merchant_risk} color="hsl(280, 60%, 55%)" />
              <RiskBreakdownBar label="Behavioral Dev. (20%)" value={caseData.behavioral_deviation} color="hsl(175, 80%, 50%)" />
            </div>
            <div className="mt-4 pt-3 border-t border-border/50 flex justify-between text-xs">
              <span className="text-muted-foreground">Weighted Score</span>
              <span className={cn("font-mono font-bold", getRiskColor(riskLevel))}>{caseData.risk_score}/100</span>
            </div>
          </InvestigationSection>

          {/* Confidence Meter */}
          <InvestigationSection title="Investigation Confidence" icon={<Target className="w-4 h-4 text-primary" />} delay={0.2}>
            <ConfidenceMeter riskScore={caseData.risk_score} anomalyCount={caseData.anomalies?.length || 0} />
          </InvestigationSection>

          {/* Future Prediction */}
          <InvestigationSection title="Future Risk Prediction" icon={<TrendingUp className="w-4 h-4 text-warning" />} delay={0.25}>
            <FuturePrediction
              riskScore={caseData.risk_score}
              anomalyCount={caseData.anomalies?.length || 0}
              repeatFlagging={hasRepeatFlagging}
            />
          </InvestigationSection>

          {/* Trust Score Evolution */}
          <InvestigationSection title="Trust Score Evolution" icon={<Shield className="w-4 h-4 text-primary" />} delay={0.3}>
            <TrustScorePanel
              riskScore={caseData.risk_score}
              deviceRisk={caseData.device_risk}
              merchantRisk={caseData.merchant_risk}
              customerName={customer?.full_name}
              merchantName={merchant?.merchant_name}
            />
          </InvestigationSection>

          {/* Case Memory */}
          <InvestigationSection title="AI Case Memory" icon={<Brain className="w-4 h-4 text-primary" />} delay={0.35}>
            <CaseMemory caseId={caseData.case_id} customerUuid={caseData.customer_uuid} anomalies={caseData.anomalies} />
          </InvestigationSection>

          {/* AI Copilot */}
          <InvestigationSection title="AI Investigation Copilot" icon={<MessageCircle className="w-4 h-4 text-primary" />} delay={0.4}>
            <AICopilot caseData={{ ...caseData, customer, merchant, transaction: txn }} />
          </InvestigationSection>

          {/* Audit Trail */}
          <InvestigationSection title="Explainability Audit Trail" icon={<ClipboardList className="w-4 h-4 text-info" />} delay={0.45}>
            <AuditTrail
              caseId={caseData.case_id}
              flaggedAt={caseData.flagged_at}
              riskScore={caseData.risk_score}
              anomalies={caseData.anomalies}
              status={caseData.status}
            />
          </InvestigationSection>

          {!report && !isAnalyzing && caseData.ai_reasoning && (
            <InvestigationSection title="Saved AI Reasoning" icon={<Brain className="w-4 h-4 text-primary" />} delay={0.5}>
              <p className="text-xs leading-relaxed text-foreground/90 whitespace-pre-wrap">{caseData.ai_reasoning}</p>
            </InvestigationSection>
          )}
        </div>
      </div>
    </div>
  );
}
