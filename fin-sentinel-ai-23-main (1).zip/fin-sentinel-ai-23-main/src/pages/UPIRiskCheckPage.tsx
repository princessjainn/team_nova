import { useState } from 'react';
import { motion } from 'framer-motion';
import { Search, AlertTriangle, CheckCircle, XCircle, Shield, Users, Clock, Fingerprint, ArrowRightLeft, MapPin, Store, Activity } from 'lucide-react';
import { useQuery } from '@tanstack/react-query';
import { fetchFlaggedCases, fetchCustomers, fetchTransactions, fetchMerchants } from '@/data/api';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';
import { InvestigationSection } from '@/components/InvestigationPanels';

interface UPICheckResult {
  upiId: string;
  formatValid: boolean;
  formatIssues: string[];
  nameMismatch: boolean;
  registeredName: string;
  beneficiaryName: string;
  riskHistory: { flagCount: number; linkedAccounts: number; riskLevel: string };
  patternFlags: string[];
  overallRisk: 'HIGH' | 'MEDIUM' | 'LOW';
  overallScore: number;
}

function validateUPI(upiId: string, customers: any[], cases: any[], txns: any[]): UPICheckResult {
  const formatIssues: string[] = [];
  const patternFlags: string[] = [];

  const formatValid = /^[a-zA-Z0-9._-]+@[a-zA-Z]+$/.test(upiId);
  if (!upiId.includes('@')) formatIssues.push('Missing @ symbol — invalid UPI format');
  if (upiId.length < 5) formatIssues.push('UPI ID too short');
  if (/[^a-zA-Z0-9._@-]/.test(upiId)) formatIssues.push('Contains invalid special characters');
  if (upiId.length > 50) formatIssues.push('UPI ID exceeds maximum length');

  const matchedCustomer = customers.find((c: any) => c.upi_id === upiId);
  const registeredName = matchedCustomer ? matchedCustomer.full_name : 'Unknown — UPI not in system';
  const beneficiaryNames: Record<string, string> = {
    'rahul@okaxis': 'Rahul Sharma',
    'priya@oksbi': 'Sunil Traders',
    'arjun@okicici': 'Arjun Reddy',
    'sneha@okhdfc': 'Sneha Gupta',
    'vikram@okpnb': 'XYZ Electronics',
    'ananya@okkotak': 'Ananya Iyer',
    'rizwan@okaxis': 'Mohammed Rizwan',
    'kavita@oksbi': 'Kavita Deshmukh',
  };
  const beneficiaryName = beneficiaryNames[upiId] || 'Not Found';
  const nameMismatch = matchedCustomer ? beneficiaryName !== matchedCustomer.full_name : false;

  const relatedCases = cases.filter((c: any) => {
    const cust = customers.find((cu: any) => cu.upi_id === upiId);
    return cust && c.customer_uuid === cust.customer_uuid;
  });
  const flagCount = relatedCases.length;
  const linkedAccounts = Math.min(flagCount + 1, 5);
  const riskLevel = flagCount >= 3 ? 'HIGH' : flagCount >= 1 ? 'MEDIUM' : 'LOW';

  if (matchedCustomer) {
    const custTxns = txns.filter((t: any) => t.customer_uuid === matchedCustomer.customer_uuid);
    const recentTxns = custTxns.slice(0, 5);
    if (recentTxns.length >= 2) {
      const amounts = recentTxns.map((t: any) => Number(t.transaction_amount));
      if (amounts.some((a: number) => a > 50000)) patternFlags.push('Large amount transactions detected');
      if (amounts.every((a: number) => a < 2000) && amounts.length > 3) patternFlags.push('Repeated small transactions — possible structuring');
    }
    const uniqueMerchants = new Set(custTxns.map((t: any) => t.merchant_uuid));
    if (custTxns.length > 3 && uniqueMerchants.size === 1) patternFlags.push('All transactions to single merchant — suspicious');
  }
  if (nameMismatch) patternFlags.push('Beneficiary name mismatch detected');
  if (!formatValid) patternFlags.push('Invalid UPI format');

  let score = 0;
  if (!formatValid) score += 20;
  if (nameMismatch) score += 30;
  score += flagCount * 15;
  score += patternFlags.length * 5;
  score = Math.min(100, score);

  return {
    upiId,
    formatValid: formatIssues.length === 0,
    formatIssues,
    nameMismatch,
    registeredName,
    beneficiaryName,
    riskHistory: { flagCount, linkedAccounts, riskLevel },
    patternFlags,
    overallRisk: score >= 60 ? 'HIGH' : score >= 30 ? 'MEDIUM' : 'LOW',
    overallScore: score,
  };
}

export default function UPIRiskCheckPage() {
  const [upiInput, setUpiInput] = useState('');
  const [result, setResult] = useState<UPICheckResult | null>(null);

  const { data: customers = [] } = useQuery({ queryKey: ['customers'], queryFn: fetchCustomers });
  const { data: cases = [] } = useQuery({ queryKey: ['flaggedCases'], queryFn: fetchFlaggedCases });
  const { data: txns = [] } = useQuery({ queryKey: ['transactions'], queryFn: fetchTransactions });
  const { data: merchants = [] } = useQuery({ queryKey: ['merchants'], queryFn: fetchMerchants });

  const handleCheck = () => {
    if (!upiInput.trim()) return;
    setResult(validateUPI(upiInput.trim(), customers, cases, txns));
  };

  const matchedCustomer = customers.find((c: any) => c.upi_id === result?.upiId);
  const customerTxns = matchedCustomer
    ? txns.filter((t: any) => t.customer_uuid === matchedCustomer.customer_uuid)
    : [];
  const customerCases = matchedCustomer
    ? cases.filter((c: any) => c.customer_uuid === matchedCustomer.customer_uuid)
    : [];

  const merchantIds = [...new Set(customerTxns.map((t: any) => t.merchant_uuid))];
  const correlatedMerchants = merchantIds.map(mid => {
    const m = merchants.find((me: any) => me.merchant_uuid === mid);
    const mTxns = customerTxns.filter((t: any) => t.merchant_uuid === mid);
    const mCases = customerCases.filter((c: any) => c.merchant_uuid === mid);
    const totalAmt = mTxns.reduce((sum: number, t: any) => sum + Number(t.transaction_amount), 0);
    return {
      id: mid,
      name: m?.merchant_name || mid,
      bank: m?.merchant_bank_name || 'Unknown',
      txnCount: mTxns.length,
      totalAmount: totalAmt,
      flagCount: mCases.length,
      riskLevel: mCases.length >= 2 ? 'HIGH' : mCases.length >= 1 ? 'MEDIUM' : 'LOW',
    };
  }).sort((a, b) => b.flagCount - a.flagCount);

  const locationMap: Record<string, { count: number; totalAmt: number; flagged: number }> = {};
  customerTxns.forEach((t: any) => {
    const loc = t.transaction_location || 'Unknown';
    if (!locationMap[loc]) locationMap[loc] = { count: 0, totalAmt: 0, flagged: 0 };
    locationMap[loc].count++;
    locationMap[loc].totalAmt += Number(t.transaction_amount);
  });
  customerCases.forEach((c: any) => {
    const txn = txns.find((t: any) => t.transaction_uuid === c.transaction_uuid);
    if (txn) {
      const loc = txn.transaction_location || 'Unknown';
      if (locationMap[loc]) locationMap[loc].flagged++;
    }
  });
  const locationData = Object.entries(locationMap)
    .map(([city, d]) => ({ city, ...d }))
    .sort((a, b) => b.flagged - a.flagged || b.count - a.count);

  const hourBuckets = new Array(24).fill(0);
  customerTxns.forEach((t: any) => {
    const h = new Date(t.transaction_timestamp).getHours();
    hourBuckets[h]++;
  });
  const peakHour = hourBuckets.indexOf(Math.max(...hourBuckets));
  const lateNightTxns = hourBuckets.slice(0, 6).reduce((a: number, b: number) => a + b, 0);

  const deviceIds = [...new Set(customerTxns.map((t: any) => t.customer_device_id))];
  const registeredDevice = matchedCustomer?.registered_device_id;
  const unregisteredDevices = deviceIds.filter(d => d !== registeredDevice);

  const sampleUPIs = ['rahul@okaxis', 'priya@oksbi', 'vikram@okpnb', 'arjun@okicici', 'invalid_upi'];

  return (
    <div className="p-6 max-w-[1400px] mx-auto space-y-6">
      <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }}>
        <h1 className="text-2xl font-bold text-foreground tracking-tight">UPI Transaction Investigation</h1>
        <p className="text-sm text-muted-foreground mt-1">Cross-dataset correlation — Validate UPI IDs, trace transaction flows, and map risk networks</p>
      </motion.div>

      <div className="glass-card p-5">
        <div className="flex gap-3">
          <Input
            placeholder="Enter UPI ID (e.g., rahul@okaxis)"
            value={upiInput}
            onChange={(e) => setUpiInput(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleCheck()}
            className="font-mono bg-secondary border-border"
          />
          <Button onClick={handleCheck} className="gap-2 bg-primary text-primary-foreground hover:bg-primary/90">
            <Search className="w-4 h-4" />Investigate
          </Button>
        </div>
        <div className="flex gap-2 mt-3 flex-wrap">
          <span className="text-[10px] text-muted-foreground">Quick check:</span>
          {sampleUPIs.map(upi => (
            <button
              key={upi}
              onClick={() => { setUpiInput(upi); setResult(validateUPI(upi, customers, cases, txns)); }}
              className="text-[10px] font-mono px-2 py-0.5 rounded bg-secondary text-muted-foreground hover:text-primary hover:bg-primary/10 transition-colors"
            >
              {upi}
            </button>
          ))}
        </div>
      </div>

      {result && (
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="space-y-4">
          {/* Overall Risk Banner */}
          <div className={cn(
            'glass-card p-5 flex items-center justify-between',
            result.overallRisk === 'HIGH' ? 'border-destructive/30' : result.overallRisk === 'MEDIUM' ? 'border-warning/30' : 'border-success/30'
          )}>
            <div className="flex items-center gap-3">
              <div className={cn(
                'w-12 h-12 rounded-xl flex items-center justify-center',
                result.overallRisk === 'HIGH' ? 'bg-destructive/10' : result.overallRisk === 'MEDIUM' ? 'bg-warning/10' : 'bg-success/10'
              )}>
                {result.overallRisk === 'HIGH' ? <XCircle className="w-6 h-6 text-destructive" /> :
                 result.overallRisk === 'MEDIUM' ? <AlertTriangle className="w-6 h-6 text-warning" /> :
                 <CheckCircle className="w-6 h-6 text-success" />}
              </div>
              <div>
                <p className="font-mono text-sm text-foreground">{result.upiId}</p>
                <p className={cn('text-xs font-bold', result.overallRisk === 'HIGH' ? 'text-destructive' : result.overallRisk === 'MEDIUM' ? 'text-warning' : 'text-success')}>
                  {result.overallRisk} RISK — Score: {result.overallScore}/100
                </p>
              </div>
            </div>
            {matchedCustomer && (
              <div className="text-right text-xs space-y-0.5">
                <p className="text-muted-foreground">Account: <span className="font-mono text-foreground">{matchedCustomer.bank_name}</span></p>
                <p className="text-muted-foreground">Balance: <span className="font-mono text-foreground">₹{Number(matchedCustomer.account_balance).toLocaleString()}</span></p>
                <p className="text-muted-foreground">Total Txns: <span className="font-mono text-foreground">{matchedCustomer.total_transactions_count}</span></p>
              </div>
            )}
          </div>

          {/* Core Validation Row */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <InvestigationSection title="Format Validation" icon={<Shield className="w-4 h-4 text-primary" />}>
              <div className="flex items-center gap-2 mb-2">
                {result.formatValid ? <CheckCircle className="w-4 h-4 text-success" /> : <XCircle className="w-4 h-4 text-destructive" />}
                <span className={cn('text-sm font-medium', result.formatValid ? 'text-success' : 'text-destructive')}>
                  {result.formatValid ? 'Valid UPI Format' : 'Invalid UPI Format'}
                </span>
              </div>
              {result.formatIssues.map((issue, i) => (
                <p key={i} className="text-xs text-destructive/80 ml-6">• {issue}</p>
              ))}
            </InvestigationSection>

            <InvestigationSection title="Beneficiary Name Check" icon={<Users className="w-4 h-4 text-primary" />}>
              <div className="space-y-2 text-xs">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Registered Name</span>
                  <span className="font-mono text-foreground">{result.registeredName}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Beneficiary Name</span>
                  <span className="font-mono text-foreground">{result.beneficiaryName}</span>
                </div>
                <div className={cn('p-2 rounded-lg mt-2', result.nameMismatch ? 'bg-destructive/10' : 'bg-success/10')}>
                  {result.nameMismatch ? (
                    <p className="text-destructive text-xs font-medium">🚨 NAME MISMATCH — Suspicious</p>
                  ) : (
                    <p className="text-success text-xs font-medium">✓ Names match</p>
                  )}
                </div>
              </div>
            </InvestigationSection>
          </div>

          {/* Transaction Correlation */}
          {matchedCustomer && (
            <>
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.1 }} className="glass-card p-5">
                <h3 className="text-xs font-medium text-muted-foreground uppercase tracking-wider mb-4 flex items-center gap-2">
                  <ArrowRightLeft className="w-4 h-4 text-primary" />Transaction Flow — Cross-Dataset Correlation
                </h3>
                <div className="overflow-x-auto">
                  <table className="w-full text-xs">
                    <thead>
                      <tr className="text-muted-foreground border-b border-border/50">
                        <th className="text-left py-2 pr-3">TXN ID</th>
                        <th className="text-left py-2 pr-3">Timestamp</th>
                        <th className="text-right py-2 pr-3">Amount</th>
                        <th className="text-left py-2 pr-3">Merchant</th>
                        <th className="text-left py-2 pr-3">Location</th>
                        <th className="text-left py-2 pr-3">Device</th>
                        <th className="text-center py-2">Flagged</th>
                      </tr>
                    </thead>
                    <tbody>
                      {customerTxns.map((t: any) => {
                        const isFlagged = customerCases.some((c: any) => c.transaction_uuid === t.transaction_uuid);
                        const flaggedCase = customerCases.find((c: any) => c.transaction_uuid === t.transaction_uuid);
                        const merchant = merchants.find((m: any) => m.merchant_uuid === t.merchant_uuid);
                        const isUnregisteredDevice = t.customer_device_id !== registeredDevice;
                        return (
                          <tr key={t.transaction_uuid} className={cn(
                            'border-b border-border/20 transition-colors',
                            isFlagged ? 'bg-destructive/5' : 'hover:bg-secondary/50'
                          )}>
                            <td className="py-2 pr-3 font-mono text-foreground">{t.transaction_uuid}</td>
                            <td className="py-2 pr-3 text-muted-foreground">{new Date(t.transaction_timestamp).toLocaleString('en-IN', { dateStyle: 'short', timeStyle: 'short' })}</td>
                            <td className="py-2 pr-3 text-right font-mono text-foreground">₹{Number(t.transaction_amount).toLocaleString()}</td>
                            <td className="py-2 pr-3 text-foreground">{merchant?.merchant_name || t.merchant_uuid}</td>
                            <td className="py-2 pr-3">
                              <span className="flex items-center gap-1 text-muted-foreground">
                                <MapPin className="w-3 h-3" />{t.transaction_location}
                              </span>
                            </td>
                            <td className="py-2 pr-3">
                              <span className={cn('font-mono', isUnregisteredDevice ? 'text-destructive' : 'text-muted-foreground')}>
                                {t.customer_device_id}
                                {isUnregisteredDevice && <span className="text-[9px] ml-1">⚠</span>}
                              </span>
                            </td>
                            <td className="py-2 text-center">
                              {isFlagged ? (
                                <Badge variant="outline" className="text-[9px] border-destructive/30 text-destructive">
                                  Risk {flaggedCase?.risk_score}
                                </Badge>
                              ) : (
                                <span className="text-success text-[10px]">✓</span>
                              )}
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </motion.div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {/* Merchant Network */}
                <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.15 }}>
                  <InvestigationSection title="Merchant Network" icon={<Store className="w-4 h-4 text-primary" />}>
                    <div className="space-y-2">
                      {correlatedMerchants.map(m => (
                        <div key={m.id} className={cn(
                          'p-2.5 rounded-lg border',
                          m.riskLevel === 'HIGH' ? 'bg-destructive/5 border-destructive/20' :
                          m.riskLevel === 'MEDIUM' ? 'bg-warning/5 border-warning/20' : 'bg-secondary/50 border-border/50'
                        )}>
                          <div className="flex justify-between items-start">
                            <div>
                              <p className="text-xs font-medium text-foreground">{m.name}</p>
                              <p className="text-[10px] text-muted-foreground">{m.bank} • {m.txnCount} txns</p>
                            </div>
                            <div className="text-right">
                              <p className="text-xs font-mono text-foreground">₹{(m.totalAmount / 1000).toFixed(0)}K</p>
                              {m.flagCount > 0 && (
                                <p className="text-[10px] text-destructive font-medium">{m.flagCount} flags</p>
                              )}
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </InvestigationSection>
                </motion.div>

                {/* Location Trail */}
                <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.2 }}>
                  <InvestigationSection title="Location Trail" icon={<MapPin className="w-4 h-4 text-primary" />}>
                    <div className="space-y-2">
                      {locationData.map(loc => (
                        <div key={loc.city} className="flex items-center justify-between p-2 rounded-lg bg-secondary/50">
                          <div className="flex items-center gap-2">
                            <MapPin className={cn('w-3 h-3', loc.flagged > 0 ? 'text-destructive' : 'text-muted-foreground')} />
                            <span className="text-xs text-foreground">{loc.city}</span>
                          </div>
                          <div className="flex items-center gap-3 text-[10px]">
                            <span className="text-muted-foreground">{loc.count} txns</span>
                            <span className="font-mono text-foreground">₹{(loc.totalAmt / 1000).toFixed(0)}K</span>
                            {loc.flagged > 0 && (
                              <Badge variant="outline" className="text-[9px] border-destructive/30 text-destructive">{loc.flagged} flagged</Badge>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  </InvestigationSection>
                </motion.div>

                {/* Behavioral Analysis */}
                <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.25 }}>
                  <InvestigationSection title="Behavioral Correlation" icon={<Activity className="w-4 h-4 text-primary" />}>
                    <div className="space-y-3 text-xs">
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Peak Activity Hour</span>
                        <span className="font-mono text-foreground">{peakHour}:00 - {peakHour + 1}:00</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Late Night Txns (12AM-6AM)</span>
                        <span className={cn('font-mono font-bold', lateNightTxns > 0 ? 'text-warning' : 'text-success')}>
                          {lateNightTxns}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Unique Devices Used</span>
                        <span className={cn('font-mono font-bold', deviceIds.length > 1 ? 'text-warning' : 'text-success')}>
                          {deviceIds.length}
                        </span>
                      </div>
                      {unregisteredDevices.length > 0 && (
                        <div className="p-2 rounded-lg bg-destructive/10 space-y-1">
                          <p className="text-destructive font-medium text-[10px]">⚠ UNREGISTERED DEVICES DETECTED</p>
                          {unregisteredDevices.map(d => (
                            <p key={d} className="font-mono text-[10px] text-destructive/80">{d}</p>
                          ))}
                        </div>
                      )}
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Unique Merchants</span>
                        <span className="font-mono text-foreground">{merchantIds.length}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Unique Locations</span>
                        <span className="font-mono text-foreground">{locationData.length}</span>
                      </div>
                    </div>
                  </InvestigationSection>
                </motion.div>
              </div>

              {/* Linked Flagged Cases */}
              {customerCases.length > 0 && (
                <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.3 }} className="glass-card p-5">
                  <h3 className="text-xs font-medium text-muted-foreground uppercase tracking-wider mb-4 flex items-center gap-2">
                    <AlertTriangle className="w-4 h-4 text-destructive" />Linked Flagged Cases — Risk Correlation
                  </h3>
                  <div className="space-y-3">
                    {customerCases.map((c: any) => {
                      const txn = txns.find((t: any) => t.transaction_uuid === c.transaction_uuid);
                      const merchant = merchants.find((m: any) => m.merchant_uuid === c.merchant_uuid);
                      return (
                        <div key={c.case_id} className="p-4 rounded-lg border border-destructive/20 bg-destructive/5 space-y-2">
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-2">
                              <span className="text-sm font-mono font-bold text-foreground">{c.case_id}</span>
                              <Badge variant="outline" className={cn('text-[9px]',
                                c.status === 'escalated' ? 'border-destructive/30 text-destructive' :
                                c.status === 'investigating' ? 'border-warning/30 text-warning' : 'border-primary/30 text-primary'
                              )}>
                                {c.status}
                              </Badge>
                            </div>
                            <span className="text-xs font-mono font-bold text-destructive">Risk: {c.risk_score}/100</span>
                          </div>
                          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-[10px]">
                            <div>
                              <p className="text-muted-foreground uppercase">Transaction</p>
                              <p className="font-mono text-foreground">{c.transaction_uuid}</p>
                            </div>
                            <div>
                              <p className="text-muted-foreground uppercase">Merchant</p>
                              <p className="text-foreground">{merchant?.merchant_name || c.merchant_uuid}</p>
                            </div>
                            <div>
                              <p className="text-muted-foreground uppercase">Amount</p>
                              <p className="font-mono text-foreground">₹{txn ? Number(txn.transaction_amount).toLocaleString() : '—'}</p>
                            </div>
                            <div>
                              <p className="text-muted-foreground uppercase">Location</p>
                              <p className="text-foreground flex items-center gap-1"><MapPin className="w-3 h-3" />{txn?.transaction_location || '—'}</p>
                            </div>
                          </div>
                          <div className="flex flex-wrap gap-1.5 mt-1">
                            {(c.anomalies || []).map((a: any, i: number) => (
                              <Badge key={i} variant="outline" className={cn('text-[9px]',
                                a.severity === 'high' ? 'border-destructive/30 text-destructive' : 'border-warning/30 text-warning'
                              )}>
                                {a.type}: {a.value}
                              </Badge>
                            ))}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </motion.div>
              )}
            </>
          )}

          {/* Risk History & Pattern */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <InvestigationSection title="UPI Risk History" icon={<Clock className="w-4 h-4 text-primary" />}>
              <div className="space-y-2 text-xs">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Previous Flag Count</span>
                  <span className={cn('font-mono font-bold', result.riskHistory.flagCount > 0 ? 'text-destructive' : 'text-success')}>
                    {result.riskHistory.flagCount}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Linked Accounts</span>
                  <span className="font-mono text-foreground">{result.riskHistory.linkedAccounts}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Risk Level</span>
                  <Badge variant="outline" className={cn('text-[10px]',
                    result.riskHistory.riskLevel === 'HIGH' ? 'border-destructive/30 text-destructive' :
                    result.riskHistory.riskLevel === 'MEDIUM' ? 'border-warning/30 text-warning' : 'border-success/30 text-success'
                  )}>
                    {result.riskHistory.riskLevel}
                  </Badge>
                </div>
              </div>
            </InvestigationSection>

            <InvestigationSection title="Transaction Pattern Analysis" icon={<Fingerprint className="w-4 h-4 text-primary" />}>
              {result.patternFlags.length > 0 ? (
                <div className="space-y-1.5">
                  {result.patternFlags.map((flag, i) => (
                    <div key={i} className="flex items-start gap-2 text-xs">
                      <AlertTriangle className="w-3 h-3 text-warning mt-0.5 flex-shrink-0" />
                      <span className="text-foreground/80">{flag}</span>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-xs text-success">✓ No suspicious patterns detected</p>
              )}
            </InvestigationSection>
          </div>
        </motion.div>
      )}
    </div>
  );
}
