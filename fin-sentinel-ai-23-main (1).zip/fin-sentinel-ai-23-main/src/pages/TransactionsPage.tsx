import { motion } from 'framer-motion';
import { useQuery } from '@tanstack/react-query';
import { Loader2 } from 'lucide-react';
import { fetchTransactions, fetchCustomers, fetchMerchants, fetchFlaggedCases } from '@/data/api';
import { cn } from '@/lib/utils';

export default function TransactionsPage() {
  const { data: transactions = [], isLoading: txnLoading } = useQuery({ queryKey: ['transactions'], queryFn: fetchTransactions });
  const { data: customers = [] } = useQuery({ queryKey: ['customers'], queryFn: fetchCustomers });
  const { data: merchants = [] } = useQuery({ queryKey: ['merchants'], queryFn: fetchMerchants });
  const { data: cases = [] } = useQuery({ queryKey: ['flaggedCases'], queryFn: fetchFlaggedCases });

  const flaggedTxnIds = new Set(cases.map((c: any) => c.transaction_uuid));
  const customerMap = Object.fromEntries(customers.map((c: any) => [c.customer_uuid, c]));
  const merchantMap = Object.fromEntries(merchants.map((m: any) => [m.merchant_uuid, m]));

  if (txnLoading) return <div className="flex items-center justify-center h-96"><Loader2 className="w-6 h-6 text-primary animate-spin" /></div>;

  return (
    <div className="p-6 max-w-[1400px] mx-auto space-y-6">
      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
        <h1 className="text-2xl font-bold text-foreground">UPI Transactions</h1>
        <p className="text-sm text-muted-foreground mt-1">{transactions.length} total transactions</p>
      </motion.div>
      <div className="glass-card overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-xs">
            <thead>
              <tr className="border-b border-border/50">
                {['TXN ID', 'Customer', 'Merchant', 'Amount', 'Time', 'Location', 'Device', 'Status'].map(h => (
                  <th key={h} className="text-left px-4 py-3 text-[10px] text-muted-foreground uppercase tracking-wider font-medium">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {transactions.map((t: any, i: number) => {
                const flagged = flaggedTxnIds.has(t.transaction_uuid);
                return (
                  <motion.tr key={t.transaction_uuid} initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: i * 0.02 }}
                    className={cn("border-b border-border/30 transition-colors", flagged ? "bg-destructive/5 hover:bg-destructive/10" : "hover:bg-secondary/30")}>
                    <td className="px-4 py-3 font-mono text-primary">{t.transaction_uuid}</td>
                    <td className="px-4 py-3 text-foreground">{customerMap[t.customer_uuid]?.full_name || t.customer_uuid}</td>
                    <td className="px-4 py-3 text-muted-foreground">{merchantMap[t.merchant_uuid]?.merchant_name || t.merchant_uuid}</td>
                    <td className="px-4 py-3 font-mono text-foreground">₹{Number(t.transaction_amount).toLocaleString('en-IN')}</td>
                    <td className="px-4 py-3 text-muted-foreground">{new Date(t.transaction_timestamp).toLocaleString('en-IN', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })}</td>
                    <td className="px-4 py-3 text-muted-foreground">{t.transaction_location}</td>
                    <td className="px-4 py-3 font-mono text-muted-foreground text-[10px]">{t.customer_device_id}</td>
                    <td className="px-4 py-3">
                      {flagged ? (
                        <span className="px-2 py-0.5 rounded-full text-[10px] bg-destructive/10 text-destructive border border-destructive/20">FLAGGED</span>
                      ) : (
                        <span className="px-2 py-0.5 rounded-full text-[10px] bg-success/10 text-success border border-success/20">CLEAR</span>
                      )}
                    </td>
                  </motion.tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
