import { motion } from 'framer-motion';
import { useQuery } from '@tanstack/react-query';
import { Loader2 } from 'lucide-react';
import CaseCard from '@/components/CaseCard';
import { fetchFlaggedCases } from '@/data/api';
import { useState } from 'react';
import { cn } from '@/lib/utils';

const filters = ['all', 'open', 'investigating', 'escalated', 'resolved'] as const;

export default function CasesPage() {
  const [filter, setFilter] = useState<string>('all');
  const { data: cases = [], isLoading } = useQuery({ queryKey: ['flaggedCases'], queryFn: fetchFlaggedCases });
  const filtered = filter === 'all' ? cases : cases.filter((c: any) => c.status === filter);

  if (isLoading) return (
    <div className="flex items-center justify-center h-96"><Loader2 className="w-6 h-6 text-primary animate-spin" /></div>
  );

  return (
    <div className="p-6 max-w-[1400px] mx-auto space-y-6">
      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
        <h1 className="text-2xl font-bold text-foreground">Flagged Cases</h1>
        <p className="text-sm text-muted-foreground mt-1">All flagged UPI transactions requiring investigation</p>
      </motion.div>
      <div className="flex gap-2">
        {filters.map(f => (
          <button key={f} onClick={() => setFilter(f)}
            className={cn("px-3 py-1.5 rounded-lg text-xs font-medium transition-all",
              filter === f ? "bg-primary/10 text-primary border border-primary/30" : "bg-secondary text-muted-foreground hover:text-foreground"
            )}>{f.charAt(0).toUpperCase() + f.slice(1)}</button>
        ))}
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
        {filtered.map((c: any, i: number) => <CaseCard key={c.case_id} flaggedCase={c} index={i} />)}
      </div>
      {filtered.length === 0 && <div className="text-center py-12 text-muted-foreground text-sm">No cases match this filter.</div>}
    </div>
  );
}
