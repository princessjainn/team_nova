import { motion } from 'framer-motion';
import { useQuery } from '@tanstack/react-query';
import { Loader2 } from 'lucide-react';
import { fetchCustomers } from '@/data/api';

export default function CustomersPage() {
  const { data: customers = [], isLoading } = useQuery({ queryKey: ['customers'], queryFn: fetchCustomers });

  if (isLoading) return <div className="flex items-center justify-center h-96"><Loader2 className="w-6 h-6 text-primary animate-spin" /></div>;

  return (
    <div className="p-6 max-w-[1400px] mx-auto space-y-6">
      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
        <h1 className="text-2xl font-bold text-foreground">UPI Customers</h1>
        <p className="text-sm text-muted-foreground mt-1">{customers.length} registered customers</p>
      </motion.div>
      <div className="glass-card overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-xs">
            <thead>
              <tr className="border-b border-border/50">
                {['ID', 'Name', 'Age', 'UPI ID', 'Bank', 'Balance', 'Txns', 'Device', 'Opened'].map(h => (
                  <th key={h} className="text-left px-4 py-3 text-[10px] text-muted-foreground uppercase tracking-wider font-medium">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {customers.map((c: any, i: number) => (
                <motion.tr key={c.customer_uuid} initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: i * 0.03 }}
                  className="border-b border-border/30 hover:bg-secondary/30 transition-colors">
                  <td className="px-4 py-3 font-mono text-primary">{c.customer_uuid}</td>
                  <td className="px-4 py-3 text-foreground font-medium">{c.full_name}</td>
                  <td className="px-4 py-3 text-muted-foreground">{c.age}</td>
                  <td className="px-4 py-3 font-mono text-muted-foreground">{c.upi_id}</td>
                  <td className="px-4 py-3 text-muted-foreground">{c.bank_name}</td>
                  <td className="px-4 py-3 font-mono text-foreground">₹{Number(c.account_balance).toLocaleString('en-IN')}</td>
                  <td className="px-4 py-3 font-mono text-muted-foreground">{c.total_transactions_count}</td>
                  <td className="px-4 py-3 font-mono text-muted-foreground text-[10px]">{c.registered_device_id}</td>
                  <td className="px-4 py-3 text-muted-foreground">{c.account_open_date}</td>
                </motion.tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
