import { motion } from 'framer-motion';
import { Network, Users, Smartphone, Globe, AlertTriangle } from 'lucide-react';
import { cn } from '@/lib/utils';

interface NetworkNode {
  id: string;
  type: 'account' | 'device' | 'ip' | 'merchant';
  label: string;
  flagCount: number;
}

interface NetworkLink {
  source: string;
  target: string;
  relation: string;
}

interface FraudNetworkProps {
  caseId: string;
  customerUuid: string;
  deviceId?: string;
  ipAddress?: string;
  merchantUuid: string;
}

// Simulated network detection based on case data
function detectNetwork(props: FraudNetworkProps): { nodes: NetworkNode[]; links: NetworkLink[]; riskLevel: string } {
  const nodes: NetworkNode[] = [
    { id: props.customerUuid, type: 'account', label: props.customerUuid, flagCount: 2 },
    { id: 'CUST012', type: 'account', label: 'CUST012', flagCount: 3 },
    { id: 'CUST019', type: 'account', label: 'CUST019', flagCount: 1 },
  ];

  if (props.deviceId) {
    nodes.push({ id: props.deviceId, type: 'device', label: props.deviceId, flagCount: 4 });
  }
  if (props.ipAddress) {
    nodes.push({ id: props.ipAddress, type: 'ip', label: props.ipAddress, flagCount: 2 });
  }
  nodes.push({ id: props.merchantUuid, type: 'merchant', label: props.merchantUuid, flagCount: 3 });

  const links: NetworkLink[] = [
    { source: props.customerUuid, target: props.deviceId || '', relation: 'used_device' },
    { source: 'CUST012', target: props.deviceId || '', relation: 'shared_device' },
    { source: 'CUST019', target: props.ipAddress || '', relation: 'shared_ip' },
    { source: props.customerUuid, target: props.merchantUuid, relation: 'transacted' },
    { source: 'CUST012', target: props.merchantUuid, relation: 'transacted' },
  ].filter(l => l.source && l.target);

  return { nodes, links, riskLevel: nodes.length > 4 ? 'HIGH' : 'MEDIUM' };
}

const typeIcons: Record<string, React.ReactNode> = {
  account: <Users className="w-3 h-3" />,
  device: <Smartphone className="w-3 h-3" />,
  ip: <Globe className="w-3 h-3" />,
  merchant: <AlertTriangle className="w-3 h-3" />,
};

const typeColors: Record<string, string> = {
  account: 'bg-info/20 border-info/40 text-info',
  device: 'bg-warning/20 border-warning/40 text-warning',
  ip: 'bg-destructive/20 border-destructive/40 text-destructive',
  merchant: 'bg-primary/20 border-primary/40 text-primary',
};

export default function FraudNetworkGraph(props: FraudNetworkProps) {
  const { nodes, links, riskLevel } = detectNetwork(props);

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Network className="w-4 h-4 text-primary" />
          <span className="text-xs font-medium text-muted-foreground">Network Expansion Detection</span>
        </div>
        <span className={cn(
          'text-[10px] font-mono font-bold px-2 py-0.5 rounded',
          riskLevel === 'HIGH' ? 'bg-destructive/10 text-destructive' : 'bg-warning/10 text-warning'
        )}>
          {riskLevel} RISK NETWORK
        </span>
      </div>

      <div className="p-3 rounded-lg bg-destructive/5 border border-destructive/20">
        <p className="text-xs text-destructive font-medium">
          ⚠ Possible fraud ring involving {nodes.filter(n => n.type === 'account').length} accounts detected
        </p>
        <p className="text-[10px] text-muted-foreground mt-1">
          Shared devices, IP clusters, and merchant patterns identified
        </p>
      </div>

      {/* Node list */}
      <div className="space-y-2">
        {nodes.map((node, i) => (
          <motion.div
            key={node.id}
            initial={{ opacity: 0, x: -10 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: i * 0.05 }}
            className={cn('flex items-center gap-2 p-2 rounded-lg border text-xs', typeColors[node.type])}
          >
            {typeIcons[node.type]}
            <span className="font-mono flex-1">{node.label}</span>
            {node.flagCount > 0 && (
              <span className="text-[10px] font-mono opacity-70">{node.flagCount} flags</span>
            )}
          </motion.div>
        ))}
      </div>

      {/* Connections */}
      <div className="space-y-1">
        <p className="text-[10px] text-muted-foreground uppercase tracking-wider">Connections</p>
        {links.map((link, i) => (
          <div key={i} className="flex items-center gap-2 text-[10px] text-foreground/60">
            <span className="font-mono">{link.source}</span>
            <span className="text-primary">→</span>
            <span className="font-mono">{link.target}</span>
            <span className="text-muted-foreground">({link.relation})</span>
          </div>
        ))}
      </div>
    </div>
  );
}
