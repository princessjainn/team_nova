import { motion } from 'framer-motion';
import { TrendingDown, TrendingUp, User, Smartphone, Store } from 'lucide-react';
import { cn } from '@/lib/utils';

interface TrustScoreProps {
  riskScore: number;
  deviceRisk: number;
  merchantRisk: number;
  customerName?: string;
  merchantName?: string;
}

function calculateTrustScore(risk: number): { before: number; after: number; delta: number } {
  const before = Math.max(20, 100 - Math.round(risk * 0.4));
  const after = Math.max(5, before - Math.round(risk * 0.35));
  return { before, after, delta: after - before };
}

function TrustBar({ label, icon, before, after }: { label: string; icon: React.ReactNode; before: number; after: number }) {
  const delta = after - before;
  const color = after >= 70 ? 'text-success' : after >= 40 ? 'text-warning' : 'text-destructive';
  const barColor = after >= 70 ? 'bg-success' : after >= 40 ? 'bg-warning' : 'bg-destructive';

  return (
    <div className="space-y-1.5">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2 text-xs text-muted-foreground">
          {icon}
          <span>{label}</span>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-xs text-muted-foreground font-mono">{before}</span>
          <span className="text-[10px] text-muted-foreground">→</span>
          <span className={cn('text-xs font-mono font-bold', color)}>{after}</span>
          <div className={cn('flex items-center gap-0.5 text-[10px] font-mono', delta < 0 ? 'text-destructive' : 'text-success')}>
            {delta < 0 ? <TrendingDown className="w-3 h-3" /> : <TrendingUp className="w-3 h-3" />}
            {delta > 0 ? '+' : ''}{delta}
          </div>
        </div>
      </div>
      <div className="h-1.5 rounded-full bg-secondary overflow-hidden">
        <motion.div
          className={cn('h-full rounded-full', barColor)}
          initial={{ width: `${before}%` }}
          animate={{ width: `${after}%` }}
          transition={{ duration: 1, ease: 'easeOut' }}
        />
      </div>
    </div>
  );
}

export default function TrustScorePanel({ riskScore, deviceRisk, merchantRisk, customerName, merchantName }: TrustScoreProps) {
  const customerTrust = calculateTrustScore(riskScore);
  const deviceTrust = calculateTrustScore(deviceRisk);
  const merchantTrust = calculateTrustScore(merchantRisk);

  return (
    <div className="space-y-4">
      <TrustBar
        label={customerName || 'Customer Trust'}
        icon={<User className="w-3.5 h-3.5" />}
        before={customerTrust.before}
        after={customerTrust.after}
      />
      <TrustBar
        label="Device Trust"
        icon={<Smartphone className="w-3.5 h-3.5" />}
        before={deviceTrust.before}
        after={deviceTrust.after}
      />
      <TrustBar
        label={merchantName || 'Merchant Trust'}
        icon={<Store className="w-3.5 h-3.5" />}
        before={merchantTrust.before}
        after={merchantTrust.after}
      />
      <p className="text-[10px] text-muted-foreground mt-2">Trust indices update dynamically with each investigation</p>
    </div>
  );
}
