import { motion } from 'framer-motion';
import { FlaskConical, TrendingUp, AlertTriangle, DollarSign } from 'lucide-react';
import { cn } from '@/lib/utils';

interface CounterActionProps {
  riskScore: number;
  transactionAmount?: number;
  anomalyCount: number;
}

export default function CounterActionSimulation({ riskScore, transactionAmount = 0, anomalyCount }: CounterActionProps) {
  const estimatedLoss = Math.round(transactionAmount * (riskScore / 100) * 1.5);
  const followUpTxns = Math.max(0, Math.round((riskScore / 30) - 0.5));
  const escalationRisk = riskScore >= 70 ? 'HIGH' : riskScore >= 40 ? 'MEDIUM' : 'LOW';
  const cascadeAccounts = Math.max(0, Math.round(anomalyCount * 0.7));

  const scenarios = [
    {
      label: 'Estimated Loss if Allowed',
      value: `₹${estimatedLoss.toLocaleString('en-IN')}`,
      icon: <DollarSign className="w-3.5 h-3.5" />,
      severity: riskScore >= 70 ? 'high' : riskScore >= 40 ? 'medium' : 'low',
    },
    {
      label: 'Likely Follow-up Transactions',
      value: `${followUpTxns} transactions`,
      icon: <TrendingUp className="w-3.5 h-3.5" />,
      severity: followUpTxns >= 3 ? 'high' : followUpTxns >= 1 ? 'medium' : 'low',
    },
    {
      label: 'Risk Escalation',
      value: escalationRisk,
      icon: <AlertTriangle className="w-3.5 h-3.5" />,
      severity: escalationRisk === 'HIGH' ? 'high' : escalationRisk === 'MEDIUM' ? 'medium' : 'low',
    },
    {
      label: 'Cascade to Other Accounts',
      value: `${cascadeAccounts} accounts`,
      icon: <FlaskConical className="w-3.5 h-3.5" />,
      severity: cascadeAccounts >= 3 ? 'high' : cascadeAccounts >= 1 ? 'medium' : 'low',
    },
  ];

  const severityColors: Record<string, string> = {
    high: 'text-destructive bg-destructive/10',
    medium: 'text-warning bg-warning/10',
    low: 'text-success bg-success/10',
  };

  return (
    <div className="space-y-3">
      <div className="p-3 rounded-lg bg-warning/5 border border-warning/20">
        <p className="text-xs text-warning font-medium flex items-center gap-1.5">
          <FlaskConical className="w-3.5 h-3.5" />
          "What if this transaction is allowed?"
        </p>
      </div>
      <div className="grid grid-cols-2 gap-2">
        {scenarios.map((s, i) => (
          <motion.div
            key={i}
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: i * 0.1 }}
            className="p-3 rounded-lg bg-secondary/50 space-y-1"
          >
            <div className="flex items-center gap-1.5 text-muted-foreground">
              {s.icon}
              <span className="text-[10px]">{s.label}</span>
            </div>
            <p className={cn('text-sm font-mono font-bold', severityColors[s.severity].split(' ')[0])}>
              {s.value}
            </p>
          </motion.div>
        ))}
      </div>
    </div>
  );
}
