import { motion } from 'framer-motion';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, AreaChart, Area } from 'recharts';

const riskDistribution = [
  { name: 'High (70-100)', value: 3, color: 'hsl(0, 72%, 55%)' },
  { name: 'Medium (40-69)', value: 2, color: 'hsl(38, 92%, 55%)' },
  { name: 'Low (0-39)', value: 1, color: 'hsl(142, 70%, 45%)' },
];

const anomalyTypes = [
  { name: 'Device', count: 4 },
  { name: 'Amount', count: 5 },
  { name: 'Location', count: 3 },
  { name: 'Time', count: 4 },
  { name: 'Burst', count: 1 },
  { name: 'IP', count: 1 },
];

const timelineData = [
  { date: 'Feb 10', cases: 0, volume: 46200 },
  { date: 'Feb 11', cases: 0, volume: 850 },
  { date: 'Feb 12', cases: 2, volume: 203000 },
  { date: 'Feb 13', cases: 1, volume: 180000 },
  { date: 'Feb 14', cases: 1, volume: 67000 },
  { date: 'Feb 15', cases: 2, volume: 184000 },
];

const CustomTooltip = ({ active, payload, label }: any) => {
  if (!active || !payload) return null;
  return (
    <div className="glass-card p-3 text-xs">
      <p className="text-foreground font-medium mb-1">{label}</p>
      {payload.map((p: any, i: number) => (
        <p key={i} className="text-muted-foreground">
          {p.name}: <span className="text-foreground font-mono">{typeof p.value === 'number' && p.value > 1000 ? `₹${p.value.toLocaleString('en-IN')}` : p.value}</span>
        </p>
      ))}
    </div>
  );
};

export function RiskDistributionChart() {
  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.3 }} className="glass-card p-5">
      <h3 className="text-xs font-medium text-muted-foreground uppercase tracking-wider mb-4">Risk Distribution</h3>
      <ResponsiveContainer width="100%" height={180}>
        <PieChart>
          <Pie data={riskDistribution} cx="50%" cy="50%" innerRadius={45} outerRadius={70} paddingAngle={4} dataKey="value">
            {riskDistribution.map((entry, i) => (
              <Cell key={i} fill={entry.color} stroke="none" />
            ))}
          </Pie>
          <Tooltip content={<CustomTooltip />} />
        </PieChart>
      </ResponsiveContainer>
      <div className="flex justify-center gap-4 mt-2">
        {riskDistribution.map((r, i) => (
          <div key={i} className="flex items-center gap-1.5 text-[10px] text-muted-foreground">
            <div className="w-2 h-2 rounded-full" style={{ background: r.color }} />
            {r.name}
          </div>
        ))}
      </div>
    </motion.div>
  );
}

export function AnomalyTypesChart() {
  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.4 }} className="glass-card p-5">
      <h3 className="text-xs font-medium text-muted-foreground uppercase tracking-wider mb-4">Anomaly Types</h3>
      <ResponsiveContainer width="100%" height={200}>
        <BarChart data={anomalyTypes}>
          <XAxis dataKey="name" tick={{ fontSize: 10, fill: 'hsl(215, 14%, 50%)' }} axisLine={false} tickLine={false} />
          <YAxis tick={{ fontSize: 10, fill: 'hsl(215, 14%, 50%)' }} axisLine={false} tickLine={false} />
          <Tooltip content={<CustomTooltip />} />
          <Bar dataKey="count" fill="hsl(175, 80%, 50%)" radius={[4, 4, 0, 0]} barSize={28} />
        </BarChart>
      </ResponsiveContainer>
    </motion.div>
  );
}

export function CaseTimelineChart() {
  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.5 }} className="glass-card p-5">
      <h3 className="text-xs font-medium text-muted-foreground uppercase tracking-wider mb-4">Case Timeline & Volume</h3>
      <ResponsiveContainer width="100%" height={200}>
        <AreaChart data={timelineData}>
          <defs>
            <linearGradient id="colorVolume" x1="0" y1="0" x2="0" y2="1">
              <stop offset="5%" stopColor="hsl(175, 80%, 50%)" stopOpacity={0.3} />
              <stop offset="95%" stopColor="hsl(175, 80%, 50%)" stopOpacity={0} />
            </linearGradient>
          </defs>
          <XAxis dataKey="date" tick={{ fontSize: 10, fill: 'hsl(215, 14%, 50%)' }} axisLine={false} tickLine={false} />
          <YAxis tick={{ fontSize: 10, fill: 'hsl(215, 14%, 50%)' }} axisLine={false} tickLine={false} />
          <Tooltip content={<CustomTooltip />} />
          <Area type="monotone" dataKey="volume" name="Volume" stroke="hsl(175, 80%, 50%)" fill="url(#colorVolume)" strokeWidth={2} />
        </AreaChart>
      </ResponsiveContainer>
    </motion.div>
  );
}
