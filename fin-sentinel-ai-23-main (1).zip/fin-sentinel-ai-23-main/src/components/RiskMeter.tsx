import { motion } from 'framer-motion';
import { cn } from '@/lib/utils';

interface RiskMeterProps {
  score: number;
  size?: 'sm' | 'md' | 'lg';
  showLabel?: boolean;
}

export default function RiskMeter({ score, size = 'md', showLabel = true }: RiskMeterProps) {
  const radius = size === 'sm' ? 30 : size === 'md' ? 45 : 60;
  const stroke = size === 'sm' ? 5 : size === 'md' ? 7 : 9;
  const circumference = 2 * Math.PI * radius;
  const progress = (score / 100) * circumference;
  const svgSize = (radius + stroke) * 2;

  const color = score >= 70 ? 'hsl(0, 72%, 55%)' : score >= 40 ? 'hsl(38, 92%, 55%)' : 'hsl(142, 70%, 45%)';
  const label = score >= 70 ? 'HIGH' : score >= 40 ? 'MEDIUM' : 'LOW';
  const textClass = score >= 70 ? 'text-destructive' : score >= 40 ? 'text-warning' : 'text-success';

  return (
    <div className="flex flex-col items-center gap-1">
      <svg width={svgSize} height={svgSize} className="transform -rotate-90">
        <circle cx={radius + stroke} cy={radius + stroke} r={radius} fill="none" stroke="hsl(220, 14%, 16%)" strokeWidth={stroke} />
        <motion.circle
          cx={radius + stroke} cy={radius + stroke} r={radius}
          fill="none" stroke={color} strokeWidth={stroke}
          strokeLinecap="round"
          strokeDasharray={circumference}
          initial={{ strokeDashoffset: circumference }}
          animate={{ strokeDashoffset: circumference - progress }}
          transition={{ duration: 1.2, ease: 'easeOut' }}
        />
      </svg>
      <div className="absolute flex flex-col items-center" style={{ position: 'relative', marginTop: -(svgSize / 2 + (size === 'sm' ? 8 : 12)) }}>
        <span className={cn("font-mono font-bold", textClass, size === 'sm' ? 'text-sm' : size === 'md' ? 'text-xl' : 'text-3xl')}>{score}</span>
      </div>
      {showLabel && <span className={cn("text-[10px] font-mono font-semibold uppercase tracking-widest", textClass)}>{label}</span>}
    </div>
  );
}
