import { motion } from 'framer-motion';
import { LucideIcon } from 'lucide-react';
import { cn } from '@/lib/utils';

interface StatCardProps {
  title: string;
  value: string | number;
  icon: LucideIcon;
  variant?: 'default' | 'danger' | 'warning' | 'success';
  subtitle?: string;
  trend?: string;
}

const variantMap = {
  default: 'glass-card',
  danger: 'glass-card-danger',
  warning: 'glass-card-warning',
  success: 'glass-card-success',
};

const iconColorMap = {
  default: 'text-primary',
  danger: 'text-destructive',
  warning: 'text-warning',
  success: 'text-success',
};

export default function StatCard({ title, value, icon: Icon, variant = 'default', subtitle, trend }: StatCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4 }}
      className={cn(variantMap[variant], 'p-5')}
    >
      <div className="flex items-start justify-between">
        <div>
          <p className="text-xs font-medium text-muted-foreground uppercase tracking-wider">{title}</p>
          <p className="stat-value mt-1">{value}</p>
          {subtitle && <p className="text-xs text-muted-foreground mt-1">{subtitle}</p>}
        </div>
        <div className={cn("w-10 h-10 rounded-lg flex items-center justify-center bg-secondary", iconColorMap[variant])}>
          <Icon className="w-5 h-5" />
        </div>
      </div>
      {trend && <p className="text-xs text-primary font-mono mt-3">{trend}</p>}
    </motion.div>
  );
}
