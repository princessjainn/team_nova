import { motion } from 'framer-motion';
import { Shield, Phone, Lock, Eye, AlertTriangle, CheckCircle, XCircle, Clock } from 'lucide-react';
import { cn } from '@/lib/utils';

interface ActionRecommendationProps {
  riskScore: number;
  anomalies: any[];
  customerName?: string;
  transactionAmount?: number;
  transactionLocation?: string;
  transactionTime?: string;
}

type ActionLevel = 'clear' | 'monitor' | 'verify' | 'freeze' | 'block';

interface RecommendedAction {
  level: ActionLevel;
  title: string;
  description: string;
  icon: React.ReactNode;
  color: string;
  bgColor: string;
  borderColor: string;
  steps: string[];
  urgency: string;
}

function getRecommendation(riskScore: number, anomalies: any[]): RecommendedAction {
  const highCount = anomalies.filter((a: any) => a.severity === 'high').length;

  if (riskScore >= 85 || highCount >= 4) {
    return {
      level: 'block',
      title: 'BLOCK ACCOUNT + DEVICE',
      description: 'Critical risk detected. Immediate account freeze and device blacklisting recommended.',
      icon: <XCircle className="w-5 h-5" />,
      color: 'text-destructive',
      bgColor: 'bg-destructive/10',
      borderColor: 'border-destructive/30',
      steps: [
        'Freeze account immediately',
        'Block device fingerprint across system',
        'Reverse pending transactions',
        'Notify customer via registered phone',
        'File SAR (Suspicious Activity Report)',
        'Escalate to fraud operations head',
      ],
      urgency: 'IMMEDIATE',
    };
  }
  if (riskScore >= 70 || highCount >= 2) {
    return {
      level: 'freeze',
      title: 'TEMPORARY FREEZE',
      description: 'High risk indicators. Freeze account for 2 hours and initiate customer verification.',
      icon: <Lock className="w-5 h-5" />,
      color: 'text-destructive',
      bgColor: 'bg-destructive/5',
      borderColor: 'border-destructive/20',
      steps: [
        'Freeze account for 2 hours',
        'Send OTP verification to registered phone',
        'Hold pending transactions',
        'Initiate automated customer callback',
        'Prepare escalation report',
      ],
      urgency: 'WITHIN 15 MINUTES',
    };
  }
  if (riskScore >= 40) {
    return {
      level: 'verify',
      title: 'CUSTOMER OTP RE-VERIFICATION',
      description: 'Moderate risk. Request additional verification before allowing future transactions.',
      icon: <Phone className="w-5 h-5" />,
      color: 'text-warning',
      bgColor: 'bg-warning/5',
      borderColor: 'border-warning/20',
      steps: [
        'Send verification SMS to registered number',
        'Request OTP confirmation for next transaction',
        'Add 24-hour enhanced monitoring',
        'Flag for analyst review within 4 hours',
      ],
      urgency: 'WITHIN 1 HOUR',
    };
  }
  if (riskScore >= 20) {
    return {
      level: 'monitor',
      title: 'ENHANCED MONITORING',
      description: 'Low-moderate risk. Continue with enhanced monitoring for 48 hours.',
      icon: <Eye className="w-5 h-5" />,
      color: 'text-info',
      bgColor: 'bg-info/5',
      borderColor: 'border-info/20',
      steps: [
        'Enable 48-hour enhanced monitoring',
        'Log anomaly for pattern analysis',
        'No customer contact needed',
      ],
      urgency: 'STANDARD',
    };
  }
  return {
    level: 'clear',
    title: 'ALLOW TRANSACTION',
    description: 'Low risk. Transaction appears legitimate based on behavioral analysis.',
    icon: <CheckCircle className="w-5 h-5" />,
    color: 'text-success',
    bgColor: 'bg-success/5',
    borderColor: 'border-success/20',
    steps: [
      'No action required',
      'Continue standard monitoring',
    ],
    urgency: 'NONE',
  };
}

function generateVerificationQuestions(customerName?: string, amount?: number, location?: string, time?: string): string[] {
  const questions: string[] = [];
  if (customerName && amount && location) {
    questions.push(`"Did you initiate a ₹${amount?.toLocaleString('en-IN')} payment from ${location}?"`);
  }
  if (time) {
    const date = new Date(time);
    const timeStr = date.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' });
    questions.push(`"Were you using your UPI account at ${timeStr} on ${date.toLocaleDateString('en-IN')}?"`);
  }
  questions.push(`"Can you confirm the last 4 digits of your registered phone number?"`);
  questions.push(`"Have you shared your UPI PIN or device with anyone recently?"`);
  return questions;
}

export default function ActionRecommendation({ riskScore, anomalies, customerName, transactionAmount, transactionLocation, transactionTime }: ActionRecommendationProps) {
  const rec = getRecommendation(riskScore, anomalies);
  const questions = generateVerificationQuestions(customerName, transactionAmount, transactionLocation, transactionTime);

  return (
    <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="space-y-4">
      {/* Main Recommendation */}
      <div className={cn('p-4 rounded-xl border', rec.bgColor, rec.borderColor)}>
        <div className="flex items-center gap-3 mb-3">
          <div className={cn('p-2 rounded-lg', rec.bgColor, rec.color)}>{rec.icon}</div>
          <div className="flex-1">
            <h3 className={cn('text-sm font-bold font-mono', rec.color)}>{rec.title}</h3>
            <p className="text-xs text-muted-foreground mt-0.5">{rec.description}</p>
          </div>
          <div className={cn('px-2 py-1 rounded text-[10px] font-mono font-bold', rec.bgColor, rec.color)}>
            {rec.urgency}
          </div>
        </div>
        <div className="space-y-1.5 mt-3">
          {rec.steps.map((step, i) => (
            <div key={i} className="flex items-start gap-2 text-xs">
              <span className={cn('font-mono text-[10px] mt-0.5', rec.color)}>{String(i + 1).padStart(2, '0')}</span>
              <span className="text-foreground/80">{step}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Smart Verification Questions */}
      {rec.level !== 'clear' && rec.level !== 'monitor' && (
        <div className="p-4 rounded-xl border border-info/20 bg-info/5">
          <div className="flex items-center gap-2 mb-3">
            <Phone className="w-4 h-4 text-info" />
            <h4 className="text-xs font-medium text-info uppercase tracking-wider">Smart Verification Questions</h4>
          </div>
          <div className="space-y-2">
            {questions.map((q, i) => (
              <div key={i} className="flex items-start gap-2 text-xs">
                <AlertTriangle className="w-3 h-3 text-info mt-0.5 flex-shrink-0" />
                <span className="text-foreground/80 italic">{q}</span>
              </div>
            ))}
          </div>
          <p className="text-[10px] text-muted-foreground mt-3">AI-generated verification questions for officer use</p>
        </div>
      )}
    </motion.div>
  );
}
