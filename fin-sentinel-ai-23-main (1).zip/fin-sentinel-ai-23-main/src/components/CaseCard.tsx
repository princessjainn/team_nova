import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Clock, ArrowRight } from 'lucide-react';
import { getRiskLevel, getRiskColor } from '@/data/types';
import { cn } from '@/lib/utils';
import { Badge } from '@/components/ui/badge';

const statusColors: Record<string, string> = {
  open: 'bg-info/10 text-info border-info/30',
  investigating: 'bg-warning/10 text-warning border-warning/30',
  escalated: 'bg-destructive/10 text-destructive border-destructive/30',
  resolved: 'bg-success/10 text-success border-success/30',
};

export default function CaseCard({ flaggedCase, index }: { flaggedCase: any; index: number }) {
  const navigate = useNavigate();
  const riskLevel = getRiskLevel(flaggedCase.risk_score);
  const anomalies = (flaggedCase.anomalies || []) as any[];

  return (
    <motion.div
      initial={{ opacity: 0, x: -20 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ duration: 0.3, delay: index * 0.05 }}
      onClick={() => navigate(`/cases/${flaggedCase.case_id}`)}
      className="glass-card p-4 cursor-pointer hover:border-primary/30 transition-all duration-300 group"
    >
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          <span className="font-mono text-xs text-muted-foreground">{flaggedCase.case_id}</span>
          <Badge variant="outline" className={cn('text-[10px] border', statusColors[flaggedCase.status])}>
            {flaggedCase.status.toUpperCase()}
          </Badge>
        </div>
        <div className={cn('font-mono text-lg font-bold', getRiskColor(riskLevel))}>
          {flaggedCase.risk_score}
        </div>
      </div>

      <div className="space-y-1.5">
        <p className="text-sm font-medium text-foreground">{flaggedCase.customer_uuid}</p>
        <p className="text-xs text-muted-foreground">{flaggedCase.merchant_uuid}</p>
      </div>

      <div className="flex items-center gap-2 mt-3 flex-wrap">
        {anomalies.slice(0, 3).map((a: any, i: number) => (
          <span key={i} className={cn(
            "text-[10px] px-2 py-0.5 rounded-full font-medium border",
            a.severity === 'high' ? 'bg-destructive/10 text-destructive border-destructive/20' :
            a.severity === 'medium' ? 'bg-warning/10 text-warning border-warning/20' :
            'bg-success/10 text-success border-success/20'
          )}>
            {a.type}
          </span>
        ))}
        {anomalies.length > 3 && (
          <span className="text-[10px] text-muted-foreground">+{anomalies.length - 3}</span>
        )}
      </div>

      <div className="flex items-center justify-between mt-3 pt-3 border-t border-border/50">
        <div className="flex items-center gap-1 text-[10px] text-muted-foreground">
          <Clock className="w-3 h-3" />
          {new Date(flaggedCase.flagged_at).toLocaleString('en-IN', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })}
        </div>
        <ArrowRight className="w-4 h-4 text-muted-foreground group-hover:text-primary transition-colors" />
      </div>
    </motion.div>
  );
}
