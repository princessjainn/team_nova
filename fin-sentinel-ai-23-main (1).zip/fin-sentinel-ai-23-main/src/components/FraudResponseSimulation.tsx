import { useState, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Phone, MessageSquare, Bell, ShieldAlert, Clock, CheckCircle, XCircle, AlertTriangle, Brain, FileText, Lock, Smartphone, MapPin, Activity, Scale, Timer, Volume2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { cn } from '@/lib/utils';

type SimStage = 'idle' | 'notification' | 'sms' | 'voice_call' | 'final_call' | 'awaiting_response' | 'response_received' | 'escalation' | 'legal' | 'evidence_locker';
type CustomerResponse = 'confirmed' | 'denied' | 'no_response' | 'text_response';

interface SimulationState {
  stage: SimStage;
  attempt: number;
  customerResponse: CustomerResponse | null;
  textResponse: string;
  aiClassification: string;
  countdown: number;
  actionsTriggered: string[];
  legalStatus: string;
}

const ATTEMPT_SEQUENCE = [
  { attempt: 1, action: 'App Notification', icon: Bell, color: 'text-primary', delay: 1500 },
  { attempt: 2, action: 'SMS Alert', icon: MessageSquare, color: 'text-warning', delay: 2000 },
  { attempt: 3, action: 'Automated Voice Call', icon: Phone, color: 'text-accent', delay: 2500 },
  { attempt: 4, action: 'Final Verification Call', icon: Volume2, color: 'text-destructive', delay: 3000 },
];

const TEXT_RESPONSES = [
  { text: "Yes I did it", classification: "AUTHORIZED", confidence: 94, intent: "confirmation" },
  { text: "I lost my phone yesterday", classification: "FRAUD_SUSPECTED", confidence: 88, intent: "device_compromise" },
  { text: "I didn't make this payment", classification: "UNAUTHORIZED", confidence: 96, intent: "denial" },
  { text: "What transaction? I was sleeping", classification: "UNAUTHORIZED", confidence: 91, intent: "denial_with_alibi" },
  { text: "My son might have done it", classification: "NEEDS_VERIFICATION", confidence: 72, intent: "uncertain_third_party" },
];

const MOCK_TXN = {
  id: 'TXN-SIM-7842',
  amount: 48500,
  merchant: 'Sharma Electronics',
  location: 'Delhi',
  device: 'DEV77777',
  time: new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' }),
  customer: 'Vikram Singh',
  upi: 'vikram@okpnb',
  riskScore: 91,
};

export default function FraudResponseSimulation() {
  const [sim, setSim] = useState<SimulationState>({
    stage: 'idle',
    attempt: 0,
    customerResponse: null,
    textResponse: '',
    aiClassification: '',
    countdown: 1800,
    actionsTriggered: [],
    legalStatus: '',
  });
  const [isRunning, setIsRunning] = useState(false);
  const [selectedResponse, setSelectedResponse] = useState<number | null>(null);
  const [countdownActive, setCountdownActive] = useState(false);

  // Countdown timer
  useEffect(() => {
    if (!countdownActive || sim.countdown <= 0) return;
    const interval = setInterval(() => {
      setSim(prev => {
        if (prev.countdown <= 1) {
          setCountdownActive(false);
          return { ...prev, countdown: 0, customerResponse: 'no_response' };
        }
        return { ...prev, countdown: prev.countdown - 1 };
      });
    }, 50); // Fast for demo
    return () => clearInterval(interval);
  }, [countdownActive, sim.countdown]);

  const startSimulation = useCallback(() => {
    setIsRunning(true);
    setSelectedResponse(null);
    setSim({
      stage: 'notification',
      attempt: 1,
      customerResponse: null,
      textResponse: '',
      aiClassification: '',
      countdown: 1800,
      actionsTriggered: [],
      legalStatus: '',
    });

    // Auto-advance through attempts
    let currentAttempt = 1;
    const advanceAttempt = () => {
      if (currentAttempt < 4) {
        currentAttempt++;
        setSim(prev => ({
          ...prev,
          stage: currentAttempt === 2 ? 'sms' : currentAttempt === 3 ? 'voice_call' : 'final_call',
          attempt: currentAttempt,
        }));
        setTimeout(advanceAttempt, ATTEMPT_SEQUENCE[currentAttempt - 1].delay);
      } else {
        setSim(prev => ({ ...prev, stage: 'awaiting_response' }));
        setCountdownActive(true);
      }
    };
    setTimeout(advanceAttempt, ATTEMPT_SEQUENCE[0].delay);
  }, []);

  const handleCustomerResponse = (type: CustomerResponse, textIdx?: number) => {
    setCountdownActive(false);

    if (type === 'text_response' && textIdx !== undefined) {
      const resp = TEXT_RESPONSES[textIdx];
      setSelectedResponse(textIdx);
      setSim(prev => ({
        ...prev,
        stage: 'response_received',
        customerResponse: type,
        textResponse: resp.text,
        aiClassification: resp.classification,
      }));

      // Auto-advance based on classification
      setTimeout(() => {
        if (resp.classification === 'AUTHORIZED') {
          setSim(prev => ({ ...prev, stage: 'response_received', actionsTriggered: ['Transaction marked safe', 'Case auto-closed'] }));
        } else {
          setSim(prev => ({ ...prev, stage: 'escalation' }));
          setTimeout(() => {
            setSim(prev => ({
              ...prev,
              actionsTriggered: ['Temporary account freeze', 'Device blacklist initiated', 'Merchant alert sent', 'Fraud escalation flag set'],
              stage: 'legal',
              legalStatus: 'INITIATED',
            }));
            setTimeout(() => {
              setSim(prev => ({ ...prev, stage: 'evidence_locker' }));
            }, 2000);
          }, 2000);
        }
      }, 1500);
    } else if (type === 'confirmed') {
      setSim(prev => ({
        ...prev,
        stage: 'response_received',
        customerResponse: 'confirmed',
        aiClassification: 'AUTHORIZED',
        actionsTriggered: ['Transaction marked safe', 'Case auto-closed'],
      }));
    } else if (type === 'denied') {
      setSim(prev => ({
        ...prev,
        stage: 'response_received',
        customerResponse: 'denied',
        aiClassification: 'UNAUTHORIZED',
      }));
      setTimeout(() => {
        setSim(prev => ({ ...prev, stage: 'escalation' }));
        setTimeout(() => {
          setSim(prev => ({
            ...prev,
            actionsTriggered: ['Temporary account freeze', 'Device blacklist initiated', 'Merchant alert sent', 'Fraud escalation flag set'],
            stage: 'legal',
            legalStatus: 'INITIATED',
          }));
          setTimeout(() => {
            setSim(prev => ({ ...prev, stage: 'evidence_locker' }));
          }, 2000);
        }, 2000);
      }, 1500);
    } else if (type === 'no_response') {
      setSim(prev => ({
        ...prev,
        stage: 'escalation',
        customerResponse: 'no_response',
        aiClassification: 'NO_RESPONSE_ESCALATION',
      }));
      setTimeout(() => {
        setSim(prev => ({
          ...prev,
          actionsTriggered: ['Temporary account freeze', 'Device blacklist initiated', 'Merchant alert sent', 'Fraud escalation flag set'],
          stage: 'legal',
          legalStatus: 'INITIATED',
        }));
        setTimeout(() => {
          setSim(prev => ({ ...prev, stage: 'evidence_locker' }));
        }, 2000);
      }, 2000);
    }
  };

  const formatCountdown = (seconds: number) => {
    const m = Math.floor(seconds / 60);
    const s = seconds % 60;
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  const stageIndex = ['idle', 'notification', 'sms', 'voice_call', 'final_call', 'awaiting_response', 'response_received', 'escalation', 'legal', 'evidence_locker'].indexOf(sim.stage);

  return (
    <div className="space-y-4">
      {/* Header + Transaction Card */}
      <div className="flex items-start justify-between flex-wrap gap-3">
        <div className="glass-card p-4 flex-1 min-w-[280px]">
          <p className="text-[10px] text-muted-foreground uppercase tracking-wider mb-2">Simulated Flagged Transaction</p>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
            <div><span className="text-muted-foreground">TXN:</span> <span className="font-mono text-foreground">{MOCK_TXN.id}</span></div>
            <div><span className="text-muted-foreground">Amount:</span> <span className="font-mono text-destructive font-bold">₹{MOCK_TXN.amount.toLocaleString()}</span></div>
            <div><span className="text-muted-foreground">Merchant:</span> <span className="text-foreground">{MOCK_TXN.merchant}</span></div>
            <div><span className="text-muted-foreground">Risk:</span> <span className="font-mono text-destructive font-bold">{MOCK_TXN.riskScore}/100</span></div>
            <div><span className="text-muted-foreground">Customer:</span> <span className="text-foreground">{MOCK_TXN.customer}</span></div>
            <div><span className="text-muted-foreground">UPI:</span> <span className="font-mono text-foreground">{MOCK_TXN.upi}</span></div>
            <div><span className="text-muted-foreground">Location:</span> <span className="text-foreground">{MOCK_TXN.location}</span></div>
            <div><span className="text-muted-foreground">Device:</span> <span className="font-mono text-warning">{MOCK_TXN.device}</span></div>
          </div>
        </div>

        {!isRunning ? (
          <Button onClick={startSimulation} className="gap-2 bg-destructive text-destructive-foreground hover:bg-destructive/90 h-auto py-3">
            <ShieldAlert className="w-4 h-4" />
            <div className="text-left">
              <p className="text-xs font-bold">Start Response Simulation</p>
              <p className="text-[10px] opacity-80">Trigger verification flow</p>
            </div>
          </Button>
        ) : (
          <div className="glass-card p-3 min-w-[180px]">
            <p className="text-[10px] text-muted-foreground uppercase">Simulation Active</p>
            <p className="text-xs font-mono text-primary">Stage {Math.min(stageIndex, 6)} / 6</p>
          </div>
        )}
      </div>

      {/* Escalation Countdown Timer */}
      {isRunning && sim.stage !== 'idle' && (
        <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} className={cn(
          'glass-card p-4 flex items-center justify-between',
          sim.countdown < 600 ? 'border-destructive/40' : sim.countdown < 1200 ? 'border-warning/40' : 'border-primary/40'
        )}>
          <div className="flex items-center gap-3">
            <div className={cn(
              'w-10 h-10 rounded-lg flex items-center justify-center',
              sim.countdown < 600 ? 'bg-destructive/10' : 'bg-warning/10'
            )}>
              <Timer className={cn('w-5 h-5', sim.countdown < 600 ? 'text-destructive animate-pulse' : 'text-warning')} />
            </div>
            <div>
              <p className="text-[10px] text-muted-foreground uppercase tracking-wider">Verification Window Remaining</p>
              <p className={cn('text-2xl font-mono font-bold', sim.countdown < 600 ? 'text-destructive' : 'text-warning')}>
                {sim.countdown > 0 ? formatCountdown(sim.countdown) : 'EXPIRED'}
              </p>
            </div>
          </div>
          <div className="text-right text-xs">
            <p className="text-muted-foreground">Next Action:</p>
            <p className={cn('font-medium', sim.countdown < 600 ? 'text-destructive' : 'text-warning')}>
              {sim.countdown > 1200 ? 'SMS Reminder' : sim.countdown > 600 ? 'Voice Call Retry' : sim.countdown > 0 ? 'Account Freeze' : 'Escalated'}
            </p>
          </div>
        </motion.div>
      )}

      {/* Step 1 — Verification Attempts */}
      {isRunning && (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="glass-card p-4">
          <h4 className="text-[10px] text-muted-foreground uppercase tracking-wider mb-3 flex items-center gap-2">
            <Phone className="w-3.5 h-3.5 text-primary" />Step 1 — Automated Verification Sequence
          </h4>
          <div className="space-y-2">
            {ATTEMPT_SEQUENCE.map((a, i) => {
              const Icon = a.icon;
              const isActive = sim.attempt === a.attempt && ['notification', 'sms', 'voice_call', 'final_call'].includes(sim.stage);
              const isComplete = sim.attempt > a.attempt || !['notification', 'sms', 'voice_call', 'final_call', 'idle'].includes(sim.stage);
              return (
                <motion.div
                  key={a.attempt}
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: sim.attempt >= a.attempt ? 1 : 0.3, x: 0 }}
                  transition={{ delay: i * 0.1 }}
                  className={cn(
                    'flex items-center gap-3 p-2.5 rounded-lg border transition-all',
                    isActive ? 'bg-primary/5 border-primary/30 ring-1 ring-primary/20' :
                    isComplete ? 'bg-success/5 border-success/20' : 'bg-secondary/30 border-border/30'
                  )}
                >
                  <div className={cn('w-7 h-7 rounded-full flex items-center justify-center text-xs font-mono font-bold',
                    isActive ? 'bg-primary/10 text-primary' : isComplete ? 'bg-success/10 text-success' : 'bg-secondary text-muted-foreground'
                  )}>
                    {isComplete ? <CheckCircle className="w-4 h-4" /> : a.attempt}
                  </div>
                  <Icon className={cn('w-4 h-4', isActive ? a.color : isComplete ? 'text-success' : 'text-muted-foreground')} />
                  <span className={cn('text-xs font-medium', isActive ? 'text-foreground' : isComplete ? 'text-success' : 'text-muted-foreground')}>
                    {a.action}
                  </span>
                  {isActive && (
                    <motion.span animate={{ opacity: [1, 0.3, 1] }} transition={{ repeat: Infinity, duration: 1.2 }}
                      className="text-[9px] font-mono text-primary ml-auto">SENDING...</motion.span>
                  )}
                  {isComplete && <span className="text-[9px] text-success ml-auto font-mono">SENT</span>}
                </motion.div>
              );
            })}
          </div>
          {sim.stage === 'awaiting_response' && (
            <div className="mt-3 p-3 rounded-lg bg-secondary/50 border border-border/50">
              <p className="text-[10px] text-muted-foreground italic mb-1">Message sent to customer:</p>
              <p className="text-xs text-foreground font-medium">
                "A transaction of ₹{MOCK_TXN.amount.toLocaleString()} was detected from your account at {MOCK_TXN.merchant}. 
                Press 1 if authorized, 2 if unauthorized."
              </p>
            </div>
          )}
        </motion.div>
      )}

      {/* Step 2 — Response Monitoring */}
      {sim.stage === 'awaiting_response' && (
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="glass-card p-4">
          <h4 className="text-[10px] text-muted-foreground uppercase tracking-wider mb-3 flex items-center gap-2">
            <Clock className="w-3.5 h-3.5 text-warning" />Step 2 — Response Monitoring — Choose Customer Response
          </h4>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 mb-4">
            <Button variant="outline" onClick={() => handleCustomerResponse('confirmed')}
              className="gap-2 border-success/30 text-success hover:bg-success/10 h-auto py-3">
              <CheckCircle className="w-4 h-4" />
              <div className="text-left"><p className="text-xs">✅ Customer Confirms</p><p className="text-[10px] opacity-70">Transaction authorized</p></div>
            </Button>
            <Button variant="outline" onClick={() => handleCustomerResponse('denied')}
              className="gap-2 border-destructive/30 text-destructive hover:bg-destructive/10 h-auto py-3">
              <XCircle className="w-4 h-4" />
              <div className="text-left"><p className="text-xs">❌ Customer Denies</p><p className="text-[10px] opacity-70">Fraud suspected</p></div>
            </Button>
            <Button variant="outline" onClick={() => handleCustomerResponse('no_response')}
              className="gap-2 border-warning/30 text-warning hover:bg-warning/10 h-auto py-3">
              <AlertTriangle className="w-4 h-4" />
              <div className="text-left"><p className="text-xs">⚠️ No Response</p><p className="text-[10px] opacity-70">Escalation triggered</p></div>
            </Button>
          </div>

          {/* Step 3 — AI Text Response Analysis */}
          <div className="border-t border-border/30 pt-3">
            <h4 className="text-[10px] text-muted-foreground uppercase tracking-wider mb-2 flex items-center gap-2">
              <Brain className="w-3.5 h-3.5 text-primary" />Step 3 — AI Text Response Analysis (NLP)
            </h4>
            <p className="text-[10px] text-muted-foreground mb-2">Simulate a customer text/chat response for AI classification:</p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {TEXT_RESPONSES.map((resp, i) => (
                <button key={i} onClick={() => handleCustomerResponse('text_response', i)}
                  className={cn(
                    'text-left p-2.5 rounded-lg border transition-all text-xs',
                    selectedResponse === i ? 'bg-primary/10 border-primary/30' : 'bg-secondary/30 border-border/30 hover:border-primary/20'
                  )}>
                  <p className="text-foreground font-medium">"{resp.text}"</p>
                  <div className="flex items-center gap-2 mt-1">
                    <Badge variant="outline" className={cn('text-[9px]',
                      resp.classification === 'AUTHORIZED' ? 'border-success/30 text-success' :
                      resp.classification === 'NEEDS_VERIFICATION' ? 'border-warning/30 text-warning' : 'border-destructive/30 text-destructive'
                    )}>
                      {resp.classification}
                    </Badge>
                    <span className="text-[9px] text-muted-foreground font-mono">{resp.confidence}% confidence</span>
                  </div>
                </button>
              ))}
            </div>
          </div>
        </motion.div>
      )}

      {/* AI Classification Result */}
      {sim.stage === 'response_received' && (
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="glass-card p-4">
          <h4 className="text-[10px] text-muted-foreground uppercase tracking-wider mb-3 flex items-center gap-2">
            <Brain className="w-3.5 h-3.5 text-primary" />AI Response Classification
          </h4>
          <div className={cn('p-3 rounded-lg border',
            sim.aiClassification === 'AUTHORIZED' ? 'bg-success/5 border-success/20' : 'bg-destructive/5 border-destructive/20'
          )}>
            {sim.textResponse && (
              <p className="text-xs text-foreground mb-2">Customer said: <span className="font-medium">"{sim.textResponse}"</span></p>
            )}
            <div className="flex items-center gap-2">
              <Badge className={cn('text-[10px]',
                sim.aiClassification === 'AUTHORIZED' ? 'bg-success/10 text-success border-success/30' : 'bg-destructive/10 text-destructive border-destructive/30'
              )}>
                {sim.aiClassification}
              </Badge>
              {sim.aiClassification === 'AUTHORIZED' && <span className="text-xs text-success">→ Transaction marked safe</span>}
              {sim.aiClassification === 'UNAUTHORIZED' && <span className="text-xs text-destructive">→ Triggering escalation...</span>}
              {sim.aiClassification === 'FRAUD_SUSPECTED' && <span className="text-xs text-destructive">→ Device compromise detected</span>}
              {sim.aiClassification === 'NEEDS_VERIFICATION' && <span className="text-xs text-warning">→ Additional verification needed</span>}
              {sim.aiClassification === 'NO_RESPONSE_ESCALATION' && <span className="text-xs text-destructive">→ No response after 4 attempts</span>}
            </div>
          </div>
        </motion.div>
      )}

      {/* Step 4 — Escalation Actions */}
      {(sim.stage === 'escalation' || sim.stage === 'legal' || sim.stage === 'evidence_locker') && (
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="glass-card p-4 border-destructive/20">
          <h4 className="text-[10px] text-muted-foreground uppercase tracking-wider mb-3 flex items-center gap-2">
            <ShieldAlert className="w-3.5 h-3.5 text-destructive" />Step 4 — Automatic Escalation Actions
          </h4>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            {['Temporary account freeze', 'Device blacklist initiated', 'Merchant alert sent', 'Fraud escalation flag set'].map((action, i) => {
              const triggered = sim.actionsTriggered.includes(action);
              return (
                <motion.div key={action}
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: triggered ? 1 : 0.4, x: 0 }}
                  transition={{ delay: i * 0.3 }}
                  className={cn('flex items-center gap-2 p-2 rounded-lg',
                    triggered ? 'bg-destructive/5 border border-destructive/20' : 'bg-secondary/30'
                  )}>
                  {triggered ? <CheckCircle className="w-3.5 h-3.5 text-destructive" /> : <Clock className="w-3.5 h-3.5 text-muted-foreground" />}
                  <span className={cn('text-xs', triggered ? 'text-destructive font-medium' : 'text-muted-foreground')}>{action}</span>
                </motion.div>
              );
            })}
          </div>
        </motion.div>
      )}

      {/* Step 5 — Legal Procedure */}
      {(sim.stage === 'legal' || sim.stage === 'evidence_locker') && (
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="glass-card p-4 border-warning/20">
          <h4 className="text-[10px] text-muted-foreground uppercase tracking-wider mb-3 flex items-center gap-2">
            <Scale className="w-3.5 h-3.5 text-warning" />Step 5 — Legal Procedure Initiation
          </h4>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 mb-3">
            {[
              { label: 'Fraud Case File', status: 'GENERATED', icon: FileText },
              { label: 'Investigation Evidence Pack', status: 'COMPILED', icon: Lock },
              { label: 'Timeline Report', status: 'PREPARED', icon: Clock },
            ].map((doc) => (
              <div key={doc.label} className="p-2.5 rounded-lg bg-secondary/50 border border-border/50">
                <div className="flex items-center gap-2 mb-1">
                  <doc.icon className="w-3.5 h-3.5 text-warning" />
                  <span className="text-[10px] text-muted-foreground">{doc.label}</span>
                </div>
                <Badge variant="outline" className="text-[9px] border-success/30 text-success">✅ {doc.status}</Badge>
              </div>
            ))}
          </div>
          <div className="p-3 rounded-lg bg-destructive/5 border border-destructive/20 font-mono text-xs space-y-1">
            <div className="flex justify-between"><span className="text-muted-foreground">Legal Escalation Status:</span><span className="text-destructive font-bold">INITIATED</span></div>
            <div className="flex justify-between"><span className="text-muted-foreground">Reason:</span><span className="text-foreground">{sim.customerResponse === 'no_response' ? 'Customer Non-Response' : 'Customer Denied Transaction'}</span></div>
            <div className="flex justify-between"><span className="text-muted-foreground">Risk Level:</span><span className="text-destructive font-bold">CRITICAL</span></div>
            <div className="flex justify-between"><span className="text-muted-foreground">Auto-forwarded to:</span><span className="text-foreground">Bank Fraud Team, Cyber Crime Cell, Legal Dept</span></div>
          </div>
        </motion.div>
      )}

      {/* Step 6 — Evidence Locker */}
      {sim.stage === 'evidence_locker' && (
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="glass-card p-4 border-primary/20">
          <h4 className="text-[10px] text-muted-foreground uppercase tracking-wider mb-3 flex items-center gap-2">
            <Lock className="w-3.5 h-3.5 text-primary" />Step 6 — Digital Evidence Locker (Court-Ready)
          </h4>
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
            {[
              { label: 'Transaction Logs', icon: Activity, count: '12 records' },
              { label: 'Device Fingerprints', icon: Smartphone, count: '3 devices' },
              { label: 'Location Trail', icon: MapPin, count: '5 locations' },
              { label: 'AI Reasoning Report', icon: Brain, count: '1 report' },
              { label: 'Customer Responses', icon: MessageSquare, count: '4 attempts' },
              { label: 'Risk Assessment', icon: ShieldAlert, count: 'Score: 91' },
            ].map((item) => (
              <div key={item.label} className="p-2.5 rounded-lg bg-secondary/50 border border-border/50 flex items-center gap-2">
                <item.icon className="w-4 h-4 text-primary flex-shrink-0" />
                <div>
                  <p className="text-[10px] text-foreground font-medium">{item.label}</p>
                  <p className="text-[9px] text-muted-foreground font-mono">{item.count}</p>
                </div>
              </div>
            ))}
          </div>
          <div className="mt-3 p-2 rounded-lg bg-success/5 border border-success/20 text-center">
            <p className="text-xs text-success font-medium">🔒 Evidence package sealed & timestamped — Ready for compliance review</p>
          </div>
        </motion.div>
      )}

      {/* Reset */}
      {sim.stage === 'evidence_locker' && (
        <div className="flex justify-center">
          <Button variant="outline" onClick={() => { setIsRunning(false); setSim({ stage: 'idle', attempt: 0, customerResponse: null, textResponse: '', aiClassification: '', countdown: 1800, actionsTriggered: [], legalStatus: '' }); }}
            className="gap-2 text-muted-foreground">
            Reset Simulation
          </Button>
        </div>
      )}
    </div>
  );
}
