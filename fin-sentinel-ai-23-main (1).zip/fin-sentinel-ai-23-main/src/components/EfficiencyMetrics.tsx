import { motion } from 'framer-motion';
import { Timer, Zap, TrendingUp } from 'lucide-react';
import { cn } from '@/lib/utils';

export default function EfficiencyMetrics() {
  const metrics = [
    { label: 'Manual Investigation Time', value: '25 min', sub: 'Average per case' },
    { label: 'RakshakAI Time', value: '40 sec', sub: 'Automated analysis', highlight: true },
    { label: 'Efficiency Gain', value: '97.3%', sub: 'Time reduction' },
    { label: 'Cases/Hour (Manual)', value: '2.4', sub: 'Officer capacity' },
    { label: 'Cases/Hour (AI)', value: '90', sub: 'AI capacity', highlight: true },
    { label: 'False Positive Rate', value: '8.2%', sub: 'AI precision' },
  ];

  return (
    <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="glass-card p-5">
      <div className="flex items-center gap-2 mb-4">
        <Timer className="w-4 h-4 text-primary" />
        <h3 className="text-xs font-medium text-muted-foreground uppercase tracking-wider">Investigation Efficiency</h3>
      </div>
      <div className="grid grid-cols-3 gap-3">
        {metrics.map((m, i) => (
          <div key={i} className={cn('p-3 rounded-lg text-center', m.highlight ? 'bg-primary/5 border border-primary/20' : 'bg-secondary/50')}>
            <p className="text-[10px] text-muted-foreground uppercase">{m.label}</p>
            <p className={cn('text-lg font-mono font-bold mt-1', m.highlight ? 'text-primary' : 'text-foreground')}>{m.value}</p>
            <p className="text-[10px] text-muted-foreground mt-0.5">{m.sub}</p>
          </div>
        ))}
      </div>
      <div className="mt-4 p-3 rounded-lg bg-success/5 border border-success/20 flex items-center gap-2">
        <Zap className="w-4 h-4 text-success" />
        <p className="text-xs text-success">FinSentinel AI reduces investigation time by <strong>97.3%</strong>, processing 37.5x more cases per hour</p>
      </div>
    </motion.div>
  );
}
