import { motion } from 'framer-motion';
import { cn } from '@/lib/utils';

interface ConfidenceMeterProps {
  riskScore: number;
  anomalyCount: number;
}

export default function ConfidenceMeter({ riskScore, anomalyCount }: ConfidenceMeterProps) {
  // Higher anomaly count + clearer risk signal = higher confidence
  const confidence = Math.min(98, Math.round(50 + (anomalyCount * 8) + Math.abs(riskScore - 50) * 0.5));
  const urgency = riskScore >= 80 ? 'Immediate Action' : riskScore >= 60 ? 'Priority Review' : riskScore >= 40 ? 'Standard Review' : 'Low Priority';
  const urgencyColor = riskScore >= 80 ? 'text-destructive' : riskScore >= 60 ? 'text-warning' : riskScore >= 40 ? 'text-info' : 'text-success';

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <span className="text-xs text-muted-foreground">AI Confidence</span>
        <span className={cn('text-lg font-mono font-bold', confidence >= 80 ? 'text-primary' : confidence >= 60 ? 'text-warning' : 'text-muted-foreground')}>
          {confidence}%
        </span>
      </div>
      <div className="h-2 rounded-full bg-secondary overflow-hidden">
        <motion.div
          className="h-full rounded-full bg-primary"
          initial={{ width: 0 }}
          animate={{ width: `${confidence}%` }}
          transition={{ duration: 1, ease: 'easeOut' }}
        />
      </div>
      <div className="flex items-center justify-between text-xs">
        <span className="text-muted-foreground">Urgency</span>
        <span className={cn('font-mono font-bold', urgencyColor)}>{urgency}</span>
      </div>
      <div className="flex items-center justify-between text-xs">
        <span className="text-muted-foreground">Risk Level</span>
        <span className={cn('font-mono font-bold',
          riskScore >= 70 ? 'text-destructive' : riskScore >= 40 ? 'text-warning' : 'text-success'
        )}>
          {riskScore >= 70 ? 'HIGH' : riskScore >= 40 ? 'MEDIUM' : 'LOW'}
        </span>
      </div>
      <div className="flex items-center justify-between text-xs">
        <span className="text-muted-foreground">Data Points Analyzed</span>
        <span className="font-mono text-foreground">{12 + anomalyCount * 3}</span>
      </div>
    </div>
  );
}
