import { motion } from 'framer-motion';
import { TrendingUp, Shield, AlertTriangle } from 'lucide-react';
import { cn } from '@/lib/utils';

interface FuturePredictionProps {
  riskScore: number;
  anomalyCount: number;
  repeatFlagging: boolean;
}

export default function FuturePrediction({ riskScore, anomalyCount, repeatFlagging }: FuturePredictionProps) {
  const baseFraudProb = Math.min(99, riskScore + (anomalyCount * 3) + (repeatFlagging ? 10 : 0));
  const next24h = Math.min(99, Math.round(baseFraudProb * 0.85));
  const next7d = Math.min(99, Math.round(baseFraudProb * 0.6));
  const accountTakeover = riskScore >= 80 ? 'HIGH' : riskScore >= 50 ? 'MODERATE' : 'LOW';
  const moneyLaundering = anomalyCount >= 4 ? 'ELEVATED' : 'STANDARD';

  const predictions = [
    {
      label: 'Next 24h Fraud Risk',
      value: `${next24h}%`,
      color: next24h >= 70 ? 'text-destructive' : next24h >= 40 ? 'text-warning' : 'text-success',
      bar: next24h,
      barColor: next24h >= 70 ? 'bg-destructive' : next24h >= 40 ? 'bg-warning' : 'bg-success',
    },
    {
      label: 'Next 7-Day Risk',
      value: `${next7d}%`,
      color: next7d >= 70 ? 'text-destructive' : next7d >= 40 ? 'text-warning' : 'text-success',
      bar: next7d,
      barColor: next7d >= 70 ? 'bg-destructive' : next7d >= 40 ? 'bg-warning' : 'bg-success',
    },
  ];

  return (
    <div className="space-y-3">
      {predictions.map((p, i) => (
        <div key={i} className="space-y-1">
          <div className="flex justify-between text-xs">
            <span className="text-muted-foreground">{p.label}</span>
            <span className={cn('font-mono font-bold', p.color)}>{p.value}</span>
          </div>
          <div className="h-1.5 rounded-full bg-secondary overflow-hidden">
            <motion.div
              className={cn('h-full rounded-full', p.barColor)}
              initial={{ width: 0 }}
              animate={{ width: `${p.bar}%` }}
              transition={{ duration: 0.8, delay: i * 0.2 }}
            />
          </div>
        </div>
      ))}

      <div className="grid grid-cols-2 gap-2 mt-3">
        <div className={cn('p-2 rounded-lg text-center', accountTakeover === 'HIGH' ? 'bg-destructive/10' : accountTakeover === 'MODERATE' ? 'bg-warning/10' : 'bg-success/10')}>
          <p className="text-[10px] text-muted-foreground">Account Takeover</p>
          <p className={cn('text-xs font-mono font-bold', accountTakeover === 'HIGH' ? 'text-destructive' : accountTakeover === 'MODERATE' ? 'text-warning' : 'text-success')}>
            {accountTakeover}
          </p>
        </div>
        <div className={cn('p-2 rounded-lg text-center', moneyLaundering === 'ELEVATED' ? 'bg-warning/10' : 'bg-success/10')}>
          <p className="text-[10px] text-muted-foreground">Money Laundering</p>
          <p className={cn('text-xs font-mono font-bold', moneyLaundering === 'ELEVATED' ? 'text-warning' : 'text-success')}>
            {moneyLaundering}
          </p>
        </div>
      </div>
    </div>
  );
}
