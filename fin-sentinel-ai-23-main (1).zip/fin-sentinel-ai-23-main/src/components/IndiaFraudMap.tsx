import { memo } from 'react';
import { ComposableMap, Geographies, Geography, Marker, ZoomableGroup } from 'react-simple-maps';
import { motion } from 'framer-motion';
import { cn } from '@/lib/utils';

const INDIA_TOPO_URL = 'https://cdn.jsdelivr.net/npm/world-atlas@2/countries-110m.json';

// Approximate coordinates for major Indian cities
const CITY_COORDS: Record<string, [number, number]> = {
  Mumbai: [72.8777, 19.076],
  Delhi: [77.1025, 28.7041],
  Bangalore: [77.5946, 12.9716],
  Chennai: [80.2707, 13.0827],
  Hyderabad: [78.4867, 17.385],
  Pune: [73.8567, 18.5204],
  Jaipur: [75.7873, 26.9124],
  Kolkata: [88.3639, 22.5726],
  Ahmedabad: [72.5714, 23.0225],
  Lucknow: [80.9462, 26.8467],
  Chandigarh: [76.7794, 30.7333],
  Kochi: [76.2673, 9.9312],
  Indore: [75.8577, 22.7196],
  Nagpur: [79.0882, 21.1458],
  Bhopal: [77.4126, 23.2599],
  Surat: [72.8311, 21.1702],
  Visakhapatnam: [83.2185, 17.6868],
  Coimbatore: [76.9558, 11.0168],
  Unknown: [78.9629, 22.5937],
};

interface CityRisk {
  city: string;
  total: number;
  highRisk: number;
  avgRisk: number;
  totalAmount: number;
}

interface IndiaFraudMapProps {
  data: CityRisk[];
}

function IndiaFraudMap({ data }: IndiaFraudMapProps) {
  const maxCases = Math.max(...data.map(d => d.total), 1);

  return (
    <div className="relative w-full" style={{ aspectRatio: '4/3' }}>
      <ComposableMap
        projection="geoMercator"
        projectionConfig={{ center: [78.9629, 22.5], scale: 800 }}
        style={{ width: '100%', height: '100%' }}
      >
        <ZoomableGroup>
          <Geographies geography={INDIA_TOPO_URL}>
            {({ geographies }) =>
              geographies
                .filter(geo => geo.properties.name === 'India')
                .map(geo => (
                  <Geography
                    key={geo.rsmKey}
                    geography={geo}
                    fill="hsl(220, 14%, 14%)"
                    stroke="hsl(220, 14%, 22%)"
                    strokeWidth={0.5}
                    style={{
                      default: { outline: 'none' },
                      hover: { outline: 'none', fill: 'hsl(220, 14%, 18%)' },
                      pressed: { outline: 'none' },
                    }}
                  />
                ))
            }
          </Geographies>

          {data.map((loc, i) => {
            const coords = CITY_COORDS[loc.city] || CITY_COORDS['Unknown'];
            const radius = 6 + (loc.total / maxCases) * 18;
            const color =
              loc.avgRisk >= 75
                ? 'hsl(0, 72%, 55%)'
                : loc.avgRisk >= 50
                ? 'hsl(38, 92%, 55%)'
                : 'hsl(175, 80%, 50%)';

            return (
              <Marker key={loc.city} coordinates={coords}>
                <motion.circle
                  r={0}
                  animate={{ r: radius }}
                  transition={{ duration: 0.6, delay: i * 0.1 }}
                  fill={color}
                  fillOpacity={0.35}
                  stroke={color}
                  strokeWidth={1.5}
                />
                <motion.circle
                  r={0}
                  animate={{ r: 3 }}
                  transition={{ duration: 0.4, delay: i * 0.1 + 0.2 }}
                  fill={color}
                />
                <text
                  textAnchor="middle"
                  y={-radius - 6}
                  style={{
                    fontFamily: 'ui-monospace, monospace',
                    fontSize: 8,
                    fill: 'hsl(215, 14%, 70%)',
                    fontWeight: 500,
                  }}
                >
                  {loc.city}
                </text>
                <text
                  textAnchor="middle"
                  y={-radius + 4}
                  style={{
                    fontFamily: 'ui-monospace, monospace',
                    fontSize: 7,
                    fill: color,
                    fontWeight: 700,
                  }}
                >
                  {loc.total} cases
                </text>
              </Marker>
            );
          })}
        </ZoomableGroup>
      </ComposableMap>

      {/* Legend */}
      <div className="absolute bottom-3 left-3 glass-card p-2 space-y-1">
        <p className="text-[9px] text-muted-foreground uppercase tracking-wider font-medium">Risk Level</p>
        {[
          { label: 'High (75+)', color: 'hsl(0, 72%, 55%)' },
          { label: 'Medium (50-74)', color: 'hsl(38, 92%, 55%)' },
          { label: 'Low (<50)', color: 'hsl(175, 80%, 50%)' },
        ].map(item => (
          <div key={item.label} className="flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full" style={{ backgroundColor: item.color }} />
            <span className="text-[9px] text-muted-foreground">{item.label}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

export default memo(IndiaFraudMap);
