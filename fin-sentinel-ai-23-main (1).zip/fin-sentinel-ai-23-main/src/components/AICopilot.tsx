import { useState } from 'react';
import { motion } from 'framer-motion';
import { MessageCircle, Send, Loader2, Bot, User } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';
import ReactMarkdown from 'react-markdown';

interface Message {
  role: 'user' | 'assistant';
  content: string;
}

interface AICopilotProps {
  caseData: any;
}

const COPILOT_URL = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/ai-copilot`;

const suggestedQuestions = [
  "Why was this marked high risk?",
  "What's the most suspicious anomaly?",
  "Is this likely fraud or legitimate?",
  "What should I check first?",
];

export default function AICopilot({ caseData }: AICopilotProps) {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const ask = async (question: string) => {
    if (!question.trim() || isLoading) return;
    const userMsg: Message = { role: 'user', content: question };
    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setIsLoading(true);

    try {
      const resp = await fetch(COPILOT_URL, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY}`,
        },
        body: JSON.stringify({ question, caseData }),
      });

      if (!resp.ok) {
        const err = await resp.json().catch(() => ({ error: 'Failed' }));
        throw new Error(err.error || 'Failed');
      }

      const data = await resp.json();
      setMessages(prev => [...prev, { role: 'assistant', content: data.answer }]);
    } catch (e) {
      setMessages(prev => [...prev, { role: 'assistant', content: `Error: ${e instanceof Error ? e.message : 'Unknown error'}` }]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="space-y-3">
      {messages.length === 0 && (
        <div className="space-y-2">
          <p className="text-[10px] text-muted-foreground uppercase tracking-wider">Ask the AI about this case</p>
          <div className="flex flex-wrap gap-1.5">
            {suggestedQuestions.map(q => (
              <button
                key={q}
                onClick={() => ask(q)}
                className="text-[10px] px-2 py-1 rounded-lg bg-primary/5 border border-primary/20 text-primary hover:bg-primary/10 transition-colors"
              >
                {q}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Chat Messages */}
      <div className="space-y-2 max-h-[300px] overflow-y-auto">
        {messages.map((msg, i) => (
          <motion.div
            key={i}
            initial={{ opacity: 0, y: 5 }}
            animate={{ opacity: 1, y: 0 }}
            className={cn('flex items-start gap-2', msg.role === 'user' ? 'justify-end' : '')}
          >
            {msg.role === 'assistant' && (
              <div className="w-5 h-5 rounded bg-primary/10 flex items-center justify-center flex-shrink-0 mt-0.5">
                <Bot className="w-3 h-3 text-primary" />
              </div>
            )}
            <div className={cn(
              'p-2 rounded-lg text-xs max-w-[85%]',
              msg.role === 'user' ? 'bg-primary/10 text-foreground' : 'bg-secondary text-foreground/80'
            )}>
              {msg.role === 'assistant' ? (
                <div className="prose prose-sm prose-invert max-w-none text-xs [&_p]:my-0.5 [&_li]:my-0 [&_ul]:my-1 [&_strong]:text-foreground">
                  <ReactMarkdown>{msg.content}</ReactMarkdown>
                </div>
              ) : msg.content}
            </div>
            {msg.role === 'user' && (
              <div className="w-5 h-5 rounded bg-info/10 flex items-center justify-center flex-shrink-0 mt-0.5">
                <User className="w-3 h-3 text-info" />
              </div>
            )}
          </motion.div>
        ))}
        {isLoading && (
          <div className="flex items-center gap-2 text-xs text-muted-foreground">
            <Loader2 className="w-3 h-3 animate-spin text-primary" />
            <span>Thinking...</span>
          </div>
        )}
      </div>

      {/* Input */}
      <div className="flex gap-2">
        <Input
          placeholder="Ask about this case..."
          value={input}
          onChange={e => setInput(e.target.value)}
          onKeyDown={e => e.key === 'Enter' && ask(input)}
          className="text-xs bg-secondary border-border"
          disabled={isLoading}
        />
        <Button size="sm" onClick={() => ask(input)} disabled={isLoading || !input.trim()} className="bg-primary text-primary-foreground">
          <Send className="w-3.5 h-3.5" />
        </Button>
      </div>
    </div>
  );
}
