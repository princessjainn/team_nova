import { motion } from 'framer-motion';
import { ClipboardList, Clock } from 'lucide-react';
import { cn } from '@/lib/utils';

interface AuditTrailProps {
  caseId: string;
  flaggedAt: string;
  riskScore: number;
  anomalies: any[];
  status: string;
}

export default function AuditTrail({ caseId, flaggedAt, riskScore, anomalies, status }: AuditTrailProps) {
  const now = new Date();
  const flagTime = new Date(flaggedAt);

  const events = [
    { time: flagTime, action: 'Transaction flagged by anomaly detection engine', type: 'system' },
    { time: new Date(flagTime.getTime() + 200), action: `Risk score calculated: ${riskScore}/100`, type: 'system' },
    { time: new Date(flagTime.getTime() + 500), action: `${anomalies.length} anomalies detected: ${anomalies.map((a: any) => a.type).join(', ')}`, type: 'system' },
    { time: new Date(flagTime.getTime() + 1000), action: `Case ${caseId} created with status: OPEN`, type: 'system' },
    { time: new Date(flagTime.getTime() + 2000), action: 'Behavioral DNA profile cross-referenced', type: 'ai' },
    { time: new Date(flagTime.getTime() + 3000), action: 'Fraud network scan initiated', type: 'ai' },
    ...(status !== 'open' ? [{ time: new Date(flagTime.getTime() + 60000), action: `Status updated to: ${status.toUpperCase()}`, type: 'officer' as const }] : []),
  ];

  const typeColors: Record<string, string> = {
    system: 'bg-info/20 text-info',
    ai: 'bg-primary/20 text-primary',
    officer: 'bg-warning/20 text-warning',
  };

  return (
    <div className="space-y-2">
      {events.map((event, i) => (
        <motion.div
          key={i}
          initial={{ opacity: 0, x: -5 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: i * 0.05 }}
          className="flex items-start gap-2"
        >
          <div className="flex flex-col items-center">
            <div className={cn('w-2 h-2 rounded-full mt-1.5', typeColors[event.type].split(' ')[0])} />
            {i < events.length - 1 && <div className="w-px h-6 bg-border/50" />}
          </div>
          <div className="flex-1 pb-1">
            <p className="text-xs text-foreground/80">{event.action}</p>
            <p className="text-[10px] text-muted-foreground font-mono">
              {event.time.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
            </p>
          </div>
          <span className={cn('text-[10px] px-1.5 py-0.5 rounded font-mono', typeColors[event.type])}>
            {event.type}
          </span>
        </motion.div>
      ))}
    </div>
  );
}
