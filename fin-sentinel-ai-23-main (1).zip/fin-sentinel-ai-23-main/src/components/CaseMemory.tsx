import { motion } from 'framer-motion';
import { Brain, Link2 } from 'lucide-react';
import { cn } from '@/lib/utils';

interface CaseMemoryProps {
  caseId: string;
  customerUuid: string;
  anomalies: any[];
}

// Simulate similar past cases
function findSimilarCases(caseId: string, customerUuid: string, anomalies: any[]): Array<{
  caseId: string;
  similarity: number;
  outcome: string;
  matchReasons: string[];
}> {
  const results = [];
  const types = anomalies.map((a: any) => a.type);

  if (types.includes('Device Mismatch')) {
    results.push({
      caseId: 'CASE-UPI-1042',
      similarity: 87,
      outcome: 'Account Takeover - Confirmed',
      matchReasons: ['Same device mismatch pattern', 'Similar geo-velocity anomaly'],
    });
  }
  if (types.includes('Amount Spike')) {
    results.push({
      caseId: 'CASE-UPI-0891',
      similarity: 72,
      outcome: 'Legitimate - Bulk Purchase',
      matchReasons: ['Similar amount spike ratio', 'Same merchant category'],
    });
  }
  if (types.includes('Rapid Burst')) {
    results.push({
      caseId: 'CASE-UPI-1156',
      similarity: 91,
      outcome: 'Fraud Ring - 6 accounts blocked',
      matchReasons: ['Rapid burst pattern match', 'Shared device fingerprint', 'Same IP cluster'],
    });
  }
  if (results.length === 0) {
    results.push({
      caseId: 'CASE-UPI-0734',
      similarity: 55,
      outcome: 'Under Monitoring',
      matchReasons: ['General behavioral deviation'],
    });
  }

  return results.slice(0, 3);
}

export default function CaseMemory({ caseId, customerUuid, anomalies }: CaseMemoryProps) {
  const similarCases = findSimilarCases(caseId, customerUuid, anomalies);

  return (
    <div className="space-y-3">
      <div className="p-3 rounded-lg bg-primary/5 border border-primary/20">
        <p className="text-xs text-primary font-medium flex items-center gap-1.5">
          <Brain className="w-3.5 h-3.5" />
          AI Case Memory — Learning from past investigations
        </p>
      </div>
      {similarCases.map((sc, i) => (
        <motion.div
          key={sc.caseId}
          initial={{ opacity: 0, y: 5 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: i * 0.1 }}
          className="p-3 rounded-lg bg-secondary/50 space-y-2"
        >
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Link2 className="w-3 h-3 text-primary" />
              <span className="text-xs font-mono text-foreground">{sc.caseId}</span>
            </div>
            <span className={cn(
              'text-[10px] font-mono font-bold px-1.5 py-0.5 rounded',
              sc.similarity >= 80 ? 'bg-destructive/10 text-destructive' : sc.similarity >= 60 ? 'bg-warning/10 text-warning' : 'bg-info/10 text-info'
            )}>
              {sc.similarity}% match
            </span>
          </div>
          <p className="text-xs text-foreground/80">Outcome: <span className="font-medium">{sc.outcome}</span></p>
          <div className="flex flex-wrap gap-1">
            {sc.matchReasons.map((r, j) => (
              <span key={j} className="text-[10px] px-1.5 py-0.5 rounded bg-muted text-muted-foreground">{r}</span>
            ))}
          </div>
        </motion.div>
      ))}
    </div>
  );
}
