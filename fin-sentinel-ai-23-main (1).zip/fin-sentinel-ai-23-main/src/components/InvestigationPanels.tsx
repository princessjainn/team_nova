import { motion } from 'framer-motion';
import { AnomalyFlag } from '@/data/types';
import { cn } from '@/lib/utils';

interface Props {
  title: string;
  icon: React.ReactNode;
  children: React.ReactNode;
  delay?: number;
}

export function InvestigationSection({ title, icon, children, delay = 0 }: Props) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 15 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, delay }}
      className="glass-card p-5"
    >
      <div className="flex items-center gap-2 mb-4">
        {icon}
        <h3 className="text-xs font-medium text-muted-foreground uppercase tracking-wider">{title}</h3>
      </div>
      {children}
    </motion.div>
  );
}

export function AnomalyList({ anomalies }: { anomalies: AnomalyFlag[] }) {
  return (
    <div className="space-y-2">
      {anomalies.map((a, i) => (
        <motion.div
          key={i}
          initial={{ opacity: 0, x: -10 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.1 * i }}
          className={cn(
            "flex items-start gap-3 p-3 rounded-lg border",
            a.severity === 'high' ? 'bg-destructive/5 border-destructive/20' :
            a.severity === 'medium' ? 'bg-warning/5 border-warning/20' :
            'bg-success/5 border-success/20'
          )}
        >
          <div className={cn(
            "w-2 h-2 rounded-full mt-1.5 flex-shrink-0",
            a.severity === 'high' ? 'bg-destructive' : a.severity === 'medium' ? 'bg-warning' : 'bg-success'
          )} />
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2">
              <span className="text-sm font-medium text-foreground">{a.type}</span>
              <span className={cn(
                "text-[10px] font-mono px-1.5 py-0.5 rounded",
                a.severity === 'high' ? 'bg-destructive/10 text-destructive' :
                a.severity === 'medium' ? 'bg-warning/10 text-warning' :
                'bg-success/10 text-success'
              )}>{a.severity.toUpperCase()}</span>
            </div>
            <p className="text-xs text-muted-foreground mt-0.5">{a.description}</p>
            <p className="text-xs font-mono text-foreground/70 mt-1">{a.value}</p>
          </div>
        </motion.div>
      ))}
    </div>
  );
}

export function RiskBreakdownBar({ label, value, color }: { label: string; value: number; color: string }) {
  return (
    <div className="space-y-1">
      <div className="flex justify-between text-xs">
        <span className="text-muted-foreground">{label}</span>
        <span className="font-mono text-foreground">{value}</span>
      </div>
      <div className="h-1.5 rounded-full bg-secondary overflow-hidden">
        <motion.div
          className="h-full rounded-full"
          style={{ backgroundColor: color }}
          initial={{ width: 0 }}
          animate={{ width: `${value}%` }}
          transition={{ duration: 0.8, ease: 'easeOut' }}
        />
      </div>
    </div>
  );
}
