export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.4"
  }
  public: {
    Tables: {
      cheque_investigations: {
        Row: {
          ai_analysis: string | null
          created_at: string
          extracted_data: Json
          id: string
          image_path: string
          investigated_by: string | null
          investigation_id: string
          matched_customer_uuid: string | null
          risk_score: number
          status: string
          updated_at: string
          validation_results: Json
        }
        Insert: {
          ai_analysis?: string | null
          created_at?: string
          extracted_data?: Json
          id?: string
          image_path: string
          investigated_by?: string | null
          investigation_id: string
          matched_customer_uuid?: string | null
          risk_score?: number
          status?: string
          updated_at?: string
          validation_results?: Json
        }
        Update: {
          ai_analysis?: string | null
          created_at?: string
          extracted_data?: Json
          id?: string
          image_path?: string
          investigated_by?: string | null
          investigation_id?: string
          matched_customer_uuid?: string | null
          risk_score?: number
          status?: string
          updated_at?: string
          validation_results?: Json
        }
        Relationships: []
      }
      flagged_cases: {
        Row: {
          ai_reasoning: string | null
          amount_risk: number
          anomalies: Json
          behavioral_deviation: number
          behavioral_dna: Json
          case_id: string
          created_at: string
          customer_uuid: string
          device_risk: number
          flagged_at: string
          id: string
          investigated_by: string | null
          investigation_outcome: string | null
          location_risk: number
          merchant_risk: number
          merchant_uuid: string
          risk_score: number
          status: string
          transaction_uuid: string
          updated_at: string
        }
        Insert: {
          ai_reasoning?: string | null
          amount_risk?: number
          anomalies?: Json
          behavioral_deviation?: number
          behavioral_dna?: Json
          case_id: string
          created_at?: string
          customer_uuid: string
          device_risk?: number
          flagged_at?: string
          id?: string
          investigated_by?: string | null
          investigation_outcome?: string | null
          location_risk?: number
          merchant_risk?: number
          merchant_uuid: string
          risk_score?: number
          status?: string
          transaction_uuid: string
          updated_at?: string
        }
        Update: {
          ai_reasoning?: string | null
          amount_risk?: number
          anomalies?: Json
          behavioral_deviation?: number
          behavioral_dna?: Json
          case_id?: string
          created_at?: string
          customer_uuid?: string
          device_risk?: number
          flagged_at?: string
          id?: string
          investigated_by?: string | null
          investigation_outcome?: string | null
          location_risk?: number
          merchant_risk?: number
          merchant_uuid?: string
          risk_score?: number
          status?: string
          transaction_uuid?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "flagged_cases_customer_uuid_fkey"
            columns: ["customer_uuid"]
            isOneToOne: false
            referencedRelation: "upi_customers"
            referencedColumns: ["customer_uuid"]
          },
          {
            foreignKeyName: "flagged_cases_merchant_uuid_fkey"
            columns: ["merchant_uuid"]
            isOneToOne: false
            referencedRelation: "upi_merchants"
            referencedColumns: ["merchant_uuid"]
          },
          {
            foreignKeyName: "flagged_cases_transaction_uuid_fkey"
            columns: ["transaction_uuid"]
            isOneToOne: false
            referencedRelation: "upi_transactions"
            referencedColumns: ["transaction_uuid"]
          },
        ]
      }
      upi_customers: {
        Row: {
          account_balance: number
          account_number: string
          account_open_date: string
          age: number
          bank_name: string
          created_at: string
          customer_uuid: string
          full_name: string
          home_branch: string
          id: string
          ifsc_code: string
          last_transaction_amount: number
          registered_device_id: string
          registered_ip_address: string
          registered_phone_number: string
          total_transactions_amount: number
          total_transactions_count: number
          upi_id: string
        }
        Insert: {
          account_balance?: number
          account_number: string
          account_open_date: string
          age: number
          bank_name: string
          created_at?: string
          customer_uuid: string
          full_name: string
          home_branch: string
          id?: string
          ifsc_code: string
          last_transaction_amount?: number
          registered_device_id: string
          registered_ip_address: string
          registered_phone_number: string
          total_transactions_amount?: number
          total_transactions_count?: number
          upi_id: string
        }
        Update: {
          account_balance?: number
          account_number?: string
          account_open_date?: string
          age?: number
          bank_name?: string
          created_at?: string
          customer_uuid?: string
          full_name?: string
          home_branch?: string
          id?: string
          ifsc_code?: string
          last_transaction_amount?: number
          registered_device_id?: string
          registered_ip_address?: string
          registered_phone_number?: string
          total_transactions_amount?: number
          total_transactions_count?: number
          upi_id?: string
        }
        Relationships: []
      }
      upi_merchants: {
        Row: {
          created_at: string
          id: string
          merchant_account_number: string
          merchant_account_open_date: string
          merchant_bank_address: string
          merchant_bank_branch: string
          merchant_bank_name: string
          merchant_ifsc_code: string
          merchant_name: string
          merchant_upi_id: string
          merchant_uuid: string
        }
        Insert: {
          created_at?: string
          id?: string
          merchant_account_number: string
          merchant_account_open_date: string
          merchant_bank_address: string
          merchant_bank_branch: string
          merchant_bank_name: string
          merchant_ifsc_code: string
          merchant_name: string
          merchant_upi_id: string
          merchant_uuid: string
        }
        Update: {
          created_at?: string
          id?: string
          merchant_account_number?: string
          merchant_account_open_date?: string
          merchant_bank_address?: string
          merchant_bank_branch?: string
          merchant_bank_name?: string
          merchant_ifsc_code?: string
          merchant_name?: string
          merchant_upi_id?: string
          merchant_uuid?: string
        }
        Relationships: []
      }
      upi_transactions: {
        Row: {
          created_at: string
          customer_device_id: string
          customer_ip_address: string
          customer_uuid: string
          id: string
          merchant_uuid: string
          transaction_amount: number
          transaction_location: string
          transaction_timestamp: string
          transaction_uuid: string
        }
        Insert: {
          created_at?: string
          customer_device_id: string
          customer_ip_address: string
          customer_uuid: string
          id?: string
          merchant_uuid: string
          transaction_amount: number
          transaction_location: string
          transaction_timestamp: string
          transaction_uuid: string
        }
        Update: {
          created_at?: string
          customer_device_id?: string
          customer_ip_address?: string
          customer_uuid?: string
          id?: string
          merchant_uuid?: string
          transaction_amount?: number
          transaction_location?: string
          transaction_timestamp?: string
          transaction_uuid?: string
        }
        Relationships: [
          {
            foreignKeyName: "upi_transactions_customer_uuid_fkey"
            columns: ["customer_uuid"]
            isOneToOne: false
            referencedRelation: "upi_customers"
            referencedColumns: ["customer_uuid"]
          },
          {
            foreignKeyName: "upi_transactions_merchant_uuid_fkey"
            columns: ["merchant_uuid"]
            isOneToOne: false
            referencedRelation: "upi_merchants"
            referencedColumns: ["merchant_uuid"]
          },
        ]
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      [_ in never]: never
    }
    Enums: {
      [_ in never]: never
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {},
  },
} as const
