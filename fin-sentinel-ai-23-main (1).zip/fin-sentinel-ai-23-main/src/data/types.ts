export interface Customer {
  customer_uuid: string;
  full_name: string;
  age: number;
  upi_id: string;
  bank_name: string;
  account_number: string;
  ifsc_code: string;
  home_branch: string;
  registered_phone_number: string;
  registered_device_id: string;
  registered_ip_address: string;
  account_balance: number;
  last_transaction_amount: number;
  total_transactions_count: number;
  total_transactions_amount: number;
  account_open_date: string;
}

export interface Merchant {
  merchant_uuid: string;
  merchant_name: string;
  merchant_upi_id: string;
  merchant_bank_name: string;
  merchant_account_number: string;
  merchant_ifsc_code: string;
  merchant_bank_branch: string;
  merchant_bank_address: string;
  merchant_account_open_date: string;
}

export interface Transaction {
  transaction_uuid: string;
  customer_uuid: string;
  merchant_uuid: string;
  transaction_amount: number;
  transaction_timestamp: string;
  transaction_location: string;
  customer_device_id: string;
  customer_ip_address: string;
}

export interface BehavioralDNA {
  amount_range_score: number;
  time_window_pattern: string;
  device_stability_score: number;
  location_variance: number;
  merchant_distribution_entropy: number;
}

export interface AnomalyFlag {
  type: string;
  severity: 'high' | 'medium' | 'low';
  description: string;
  value: string;
}

export interface FlaggedCase {
  case_id: string;
  transaction_uuid: string;
  customer_uuid: string;
  merchant_uuid: string;
  risk_score: number;
  status: 'open' | 'investigating' | 'resolved' | 'escalated';
  flagged_at: string;
  anomalies: AnomalyFlag[];
  behavioral_dna: BehavioralDNA;
  investigation_outcome?: string;
  ai_reasoning?: string;
  amount_risk: number;
  device_risk: number;
  location_risk: number;
  merchant_risk: number;
  behavioral_deviation: number;
}

export type RiskLevel = 'high' | 'medium' | 'low';

export function getRiskLevel(score: number): RiskLevel {
  if (score >= 70) return 'high';
  if (score >= 40) return 'medium';
  return 'low';
}

export function getRiskColor(level: RiskLevel): string {
  switch (level) {
    case 'high': return 'text-destructive';
    case 'medium': return 'text-warning';
    case 'low': return 'text-success';
  }
}
