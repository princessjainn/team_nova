import { Customer, Merchant, Transaction, FlaggedCase } from './types';

export const customers: Customer[] = [
  { customer_uuid: 'CUST001', full_name: 'Rahul Sharma', age: 32, upi_id: 'rahul@okaxis', bank_name: 'Axis Bank', account_number: '91827364501', ifsc_code: 'UTIB0000123', home_branch: 'Mumbai Main Branch', registered_phone_number: '9876543210', registered_device_id: 'DEV12345', registered_ip_address: '192.168.1.10', account_balance: 85000, last_transaction_amount: 5000, total_transactions_count: 120, total_transactions_amount: 350000, account_open_date: '2019-06-15' },
  { customer_uuid: 'CUST002', full_name: 'Priya Patel', age: 28, upi_id: 'priya@oksbi', bank_name: 'SBI', account_number: '30291847562', ifsc_code: 'SBIN0001234', home_branch: 'Delhi CP Branch', registered_phone_number: '9123456780', registered_device_id: 'DEV67890', registered_ip_address: '10.0.0.25', account_balance: 142000, last_transaction_amount: 12000, total_transactions_count: 89, total_transactions_amount: 520000, account_open_date: '2020-03-20' },
  { customer_uuid: 'CUST003', full_name: 'Arjun Reddy', age: 45, upi_id: 'arjun@okicici', bank_name: 'ICICI Bank', account_number: '50184726391', ifsc_code: 'ICIC0000567', home_branch: 'Hyderabad Jubilee Hills', registered_phone_number: '9988776655', registered_device_id: 'DEV11111', registered_ip_address: '172.16.0.5', account_balance: 320000, last_transaction_amount: 75000, total_transactions_count: 256, total_transactions_amount: 1850000, account_open_date: '2017-11-01' },
  { customer_uuid: 'CUST004', full_name: 'Sneha Gupta', age: 26, upi_id: 'sneha@okhdfc', bank_name: 'HDFC Bank', account_number: '70918273645', ifsc_code: 'HDFC0000890', home_branch: 'Bangalore Koramangala', registered_phone_number: '9876501234', registered_device_id: 'DEV22222', registered_ip_address: '192.168.5.100', account_balance: 55000, last_transaction_amount: 2500, total_transactions_count: 67, total_transactions_amount: 180000, account_open_date: '2021-08-10' },
  { customer_uuid: 'CUST005', full_name: 'Vikram Singh', age: 38, upi_id: 'vikram@okpnb', bank_name: 'PNB', account_number: '40182736450', ifsc_code: 'PUNB0001111', home_branch: 'Jaipur Station Road', registered_phone_number: '9011223344', registered_device_id: 'DEV33333', registered_ip_address: '10.10.10.50', account_balance: 210000, last_transaction_amount: 45000, total_transactions_count: 198, total_transactions_amount: 980000, account_open_date: '2018-01-22' },
  { customer_uuid: 'CUST006', full_name: 'Ananya Iyer', age: 31, upi_id: 'ananya@okkotak', bank_name: 'Kotak Mahindra', account_number: '60172839401', ifsc_code: 'KKBK0002222', home_branch: 'Chennai Anna Nagar', registered_phone_number: '9555667788', registered_device_id: 'DEV44444', registered_ip_address: '192.168.10.20', account_balance: 175000, last_transaction_amount: 8900, total_transactions_count: 145, total_transactions_amount: 720000, account_open_date: '2019-12-05' },
  { customer_uuid: 'CUST007', full_name: 'Mohammed Rizwan', age: 42, upi_id: 'rizwan@okaxis', bank_name: 'Axis Bank', account_number: '81726354091', ifsc_code: 'UTIB0003333', home_branch: 'Lucknow Hazratganj', registered_phone_number: '9334455667', registered_device_id: 'DEV55555', registered_ip_address: '172.20.0.15', account_balance: 95000, last_transaction_amount: 15000, total_transactions_count: 88, total_transactions_amount: 430000, account_open_date: '2020-07-14' },
  { customer_uuid: 'CUST008', full_name: 'Kavita Deshmukh', age: 29, upi_id: 'kavita@oksbi', bank_name: 'SBI', account_number: '20918374650', ifsc_code: 'SBIN0004444', home_branch: 'Pune Shivaji Nagar', registered_phone_number: '9778899001', registered_device_id: 'DEV66666', registered_ip_address: '10.5.5.30', account_balance: 68000, last_transaction_amount: 3200, total_transactions_count: 54, total_transactions_amount: 155000, account_open_date: '2022-02-28' },
];

export const merchants: Merchant[] = [
  { merchant_uuid: 'MER001', merchant_name: 'Amazon Seller Services', merchant_upi_id: 'amazon@okhdfcbank', merchant_bank_name: 'HDFC Bank', merchant_account_number: '87364521098', merchant_ifsc_code: 'HDFC0000456', merchant_bank_branch: 'Bangalore Branch', merchant_bank_address: 'Bangalore Karnataka', merchant_account_open_date: '2018-03-10' },
  { merchant_uuid: 'MER002', merchant_name: 'Flipkart India Pvt Ltd', merchant_upi_id: 'flipkart@okaxis', merchant_bank_name: 'Axis Bank', merchant_account_number: '76253419087', merchant_ifsc_code: 'UTIB0005678', merchant_bank_branch: 'Bangalore Whitefield', merchant_bank_address: 'Bangalore Karnataka', merchant_account_open_date: '2017-09-15' },
  { merchant_uuid: 'MER003', merchant_name: 'Quick Mart General Store', merchant_upi_id: 'quickmart@oksbi', merchant_bank_name: 'SBI', merchant_account_number: '65142387096', merchant_ifsc_code: 'SBIN0006789', merchant_bank_branch: 'Mumbai Andheri', merchant_bank_address: 'Mumbai Maharashtra', merchant_account_open_date: '2021-06-20' },
  { merchant_uuid: 'MER004', merchant_name: 'Zomato Payments', merchant_upi_id: 'zomato@okicici', merchant_bank_name: 'ICICI Bank', merchant_account_number: '54031298765', merchant_ifsc_code: 'ICIC0007890', merchant_bank_branch: 'Gurgaon Cyber City', merchant_bank_address: 'Gurgaon Haryana', merchant_account_open_date: '2019-01-05' },
  { merchant_uuid: 'MER005', merchant_name: 'Sharma Electronics', merchant_upi_id: 'sharmaelec@okpnb', merchant_bank_name: 'PNB', merchant_account_number: '43920187654', merchant_ifsc_code: 'PUNB0008901', merchant_bank_branch: 'Delhi Chandni Chowk', merchant_bank_address: 'Delhi', merchant_account_open_date: '2020-11-30' },
  { merchant_uuid: 'MER006', merchant_name: 'FreshBasket Online', merchant_upi_id: 'freshbasket@okhdfc', merchant_bank_name: 'HDFC Bank', merchant_account_number: '32810976543', merchant_ifsc_code: 'HDFC0009012', merchant_bank_branch: 'Chennai T Nagar', merchant_bank_address: 'Chennai Tamil Nadu', merchant_account_open_date: '2022-04-12' },
];

export const transactions: Transaction[] = [
  { transaction_uuid: 'TXN001', customer_uuid: 'CUST001', merchant_uuid: 'MER001', transaction_amount: 45000, transaction_timestamp: '2026-02-10 14:32:10', transaction_location: 'Mumbai', customer_device_id: 'DEV12345', customer_ip_address: '192.168.1.10' },
  { transaction_uuid: 'TXN002', customer_uuid: 'CUST001', merchant_uuid: 'MER003', transaction_amount: 1200, transaction_timestamp: '2026-02-10 14:35:42', transaction_location: 'Mumbai', customer_device_id: 'DEV12345', customer_ip_address: '192.168.1.10' },
  { transaction_uuid: 'TXN003', customer_uuid: 'CUST002', merchant_uuid: 'MER004', transaction_amount: 850, transaction_timestamp: '2026-02-11 09:15:30', transaction_location: 'Delhi', customer_device_id: 'DEV67890', customer_ip_address: '10.0.0.25' },
  { transaction_uuid: 'TXN004', customer_uuid: 'CUST003', merchant_uuid: 'MER005', transaction_amount: 125000, transaction_timestamp: '2026-02-12 22:45:00', transaction_location: 'Chennai', customer_device_id: 'DEV99999', customer_ip_address: '203.45.67.89' },
  { transaction_uuid: 'TXN005', customer_uuid: 'CUST002', merchant_uuid: 'MER002', transaction_amount: 78000, transaction_timestamp: '2026-02-12 03:22:15', transaction_location: 'Mumbai', customer_device_id: 'DEV67890', customer_ip_address: '45.67.89.123' },
  { transaction_uuid: 'TXN006', customer_uuid: 'CUST004', merchant_uuid: 'MER003', transaction_amount: 3200, transaction_timestamp: '2026-02-13 11:10:05', transaction_location: 'Bangalore', customer_device_id: 'DEV22222', customer_ip_address: '192.168.5.100' },
  { transaction_uuid: 'TXN007', customer_uuid: 'CUST005', merchant_uuid: 'MER001', transaction_amount: 92000, transaction_timestamp: '2026-02-13 16:48:30', transaction_location: 'Jaipur', customer_device_id: 'DEV33333', customer_ip_address: '10.10.10.50' },
  { transaction_uuid: 'TXN008', customer_uuid: 'CUST005', merchant_uuid: 'MER005', transaction_amount: 88000, transaction_timestamp: '2026-02-13 16:52:10', transaction_location: 'Delhi', customer_device_id: 'DEV77777', customer_ip_address: '156.78.90.12' },
  { transaction_uuid: 'TXN009', customer_uuid: 'CUST006', merchant_uuid: 'MER006', transaction_amount: 4500, transaction_timestamp: '2026-02-14 08:30:00', transaction_location: 'Chennai', customer_device_id: 'DEV44444', customer_ip_address: '192.168.10.20' },
  { transaction_uuid: 'TXN010', customer_uuid: 'CUST007', merchant_uuid: 'MER004', transaction_amount: 67000, transaction_timestamp: '2026-02-14 01:15:45', transaction_location: 'Bangalore', customer_device_id: 'DEV88888', customer_ip_address: '78.90.12.34' },
  { transaction_uuid: 'TXN011', customer_uuid: 'CUST003', merchant_uuid: 'MER002', transaction_amount: 156000, transaction_timestamp: '2026-02-15 04:20:30', transaction_location: 'Hyderabad', customer_device_id: 'DEV11111', customer_ip_address: '172.16.0.5' },
  { transaction_uuid: 'TXN012', customer_uuid: 'CUST008', merchant_uuid: 'MER003', transaction_amount: 28000, transaction_timestamp: '2026-02-15 19:45:00', transaction_location: 'Pune', customer_device_id: 'DEV66666', customer_ip_address: '10.5.5.30' },
];

export const flaggedCases: FlaggedCase[] = [
  {
    case_id: 'CASE001',
    transaction_uuid: 'TXN004',
    customer_uuid: 'CUST003',
    merchant_uuid: 'MER005',
    risk_score: 87,
    status: 'investigating',
    flagged_at: '2026-02-12 22:46:00',
    amount_risk: 92, device_risk: 95, location_risk: 88, merchant_risk: 70, behavioral_deviation: 85,
    anomalies: [
      { type: 'Device Mismatch', severity: 'high', description: 'Transaction from unregistered device DEV99999', value: 'DEV99999 ≠ DEV11111' },
      { type: 'Location Anomaly', severity: 'high', description: 'Transaction in Chennai, registered in Hyderabad. 630km shift.', value: '630km geo-shift' },
      { type: 'Amount Spike', severity: 'high', description: 'Amount ₹1,25,000 is 4.8x median transaction value', value: '4.8x median' },
      { type: 'Late Night', severity: 'medium', description: 'Transaction at 22:45, outside typical 09:00-18:00 window', value: '22:45 IST' },
    ],
    behavioral_dna: { amount_range_score: 0.15, time_window_pattern: '09:00-18:00', device_stability_score: 0.92, location_variance: 0.12, merchant_distribution_entropy: 0.67 },
    ai_reasoning: 'This transaction exhibits multiple high-severity anomalies. The customer Arjun Reddy typically transacts from Hyderabad using device DEV11111 during business hours (09:00-18:00). This transaction originated from Chennai at 22:45 IST using an unregistered device DEV99999. The amount of ₹1,25,000 is 4.8x the median transaction value. Cross-referencing device DEV99999 reveals links to 2 other flagged accounts (CUST012, CUST019), suggesting potential fraud ring activity. The IP address 203.45.67.89 is associated with a known VPN service. Recommendation: ESCALATE for immediate investigation. Freeze transaction pending verification.',
  },
  {
    case_id: 'CASE002',
    transaction_uuid: 'TXN005',
    customer_uuid: 'CUST002',
    merchant_uuid: 'MER002',
    risk_score: 72,
    status: 'open',
    flagged_at: '2026-02-12 03:23:00',
    amount_risk: 80, device_risk: 45, location_risk: 75, merchant_risk: 55, behavioral_deviation: 78,
    anomalies: [
      { type: 'Amount Spike', severity: 'high', description: 'Amount ₹78,000 is 6.5x median. Account balance insufficient.', value: '6.5x median' },
      { type: 'Geo Velocity', severity: 'high', description: 'Delhi→Mumbai in 18 hours, last txn from Delhi at 09:15', value: 'Possible but suspicious' },
      { type: 'Unusual Hour', severity: 'medium', description: 'Transaction at 03:22 AM, highly unusual for this customer', value: '03:22 IST' },
    ],
    behavioral_dna: { amount_range_score: 0.35, time_window_pattern: '08:00-21:00', device_stability_score: 0.88, location_variance: 0.25, merchant_distribution_entropy: 0.54 },
    ai_reasoning: 'Priya Patel\'s transaction of ₹78,000 at Flipkart at 03:22 AM from Mumbai deviates significantly from her behavioral profile. She typically transacts during 08:00-21:00 from Delhi with amounts averaging ₹12,000. The geo-shift from Delhi to Mumbai within 18 hours is plausible via flight but combined with the unusual hour and high amount, it warrants investigation. No device mismatch detected. Recommendation: INVESTIGATE with customer verification call.',
  },
  {
    case_id: 'CASE003',
    transaction_uuid: 'TXN008',
    customer_uuid: 'CUST005',
    merchant_uuid: 'MER005',
    risk_score: 91,
    status: 'escalated',
    flagged_at: '2026-02-13 16:53:00',
    amount_risk: 88, device_risk: 98, location_risk: 95, merchant_risk: 82, behavioral_deviation: 90,
    anomalies: [
      { type: 'Rapid Burst', severity: 'high', description: 'Two transactions of ₹92K and ₹88K within 4 minutes', value: '₹1.8L in 4 min' },
      { type: 'Device Mismatch', severity: 'high', description: 'Second txn from DEV77777, not registered', value: 'DEV77777 ≠ DEV33333' },
      { type: 'Geo Velocity', severity: 'high', description: 'Jaipur→Delhi in 4 minutes. Physically impossible.', value: '270km in 4 min' },
      { type: 'IP Anomaly', severity: 'high', description: 'IP 156.78.90.12 is foreign-origin, customer is domestic', value: 'Foreign IP' },
      { type: 'Merchant Risk', severity: 'medium', description: 'Sharma Electronics flagged in 3 prior cases', value: '3 prior flags' },
    ],
    behavioral_dna: { amount_range_score: 0.28, time_window_pattern: '10:00-20:00', device_stability_score: 0.95, location_variance: 0.08, merchant_distribution_entropy: 0.72 },
    ai_reasoning: 'CRITICAL: Vikram Singh\'s account shows hallmarks of account takeover. Two rapid transactions totaling ₹1,80,000 within 4 minutes from two different cities (Jaipur and Delhi, 270km apart) is physically impossible. The second transaction uses an unregistered device (DEV77777) and a foreign IP address (156.78.90.12 traces to Eastern Europe). The merchant Sharma Electronics has been flagged in 3 prior fraud cases. Cross-case analysis: DEV77777 appears in CASE007 and CASE015 linked to a suspected mule network. Immediate action: BLOCK ACCOUNT, reverse transactions, notify customer.',
  },
  {
    case_id: 'CASE004',
    transaction_uuid: 'TXN010',
    customer_uuid: 'CUST007',
    merchant_uuid: 'MER004',
    risk_score: 65,
    status: 'investigating',
    flagged_at: '2026-02-14 01:16:00',
    amount_risk: 72, device_risk: 85, location_risk: 60, merchant_risk: 35, behavioral_deviation: 62,
    anomalies: [
      { type: 'Device Mismatch', severity: 'high', description: 'Transaction from DEV88888, registered is DEV55555', value: 'DEV88888 ≠ DEV55555' },
      { type: 'Amount Spike', severity: 'medium', description: 'Amount ₹67,000 is 4.5x median', value: '4.5x median' },
      { type: 'Unusual Hour', severity: 'medium', description: 'Transaction at 01:15 AM', value: '01:15 IST' },
    ],
    behavioral_dna: { amount_range_score: 0.42, time_window_pattern: '09:00-22:00', device_stability_score: 0.85, location_variance: 0.18, merchant_distribution_entropy: 0.61 },
    ai_reasoning: 'Mohammed Rizwan\'s ₹67,000 transaction at Zomato Payments at 01:15 AM from Bangalore shows moderate risk. The unregistered device DEV88888 is a primary concern. However, Zomato is a legitimate merchant with low fraud history. The customer has previously made large food orders during late hours (3 instances in last 6 months). The amount is elevated but within the upper range of his transaction history. Recommendation: FLAG for verification, request customer confirmation before clearing.',
  },
  {
    case_id: 'CASE005',
    transaction_uuid: 'TXN012',
    customer_uuid: 'CUST008',
    merchant_uuid: 'MER003',
    risk_score: 42,
    status: 'resolved',
    flagged_at: '2026-02-15 19:46:00',
    amount_risk: 55, device_risk: 20, location_risk: 25, merchant_risk: 40, behavioral_deviation: 48,
    anomalies: [
      { type: 'Amount Spike', severity: 'medium', description: 'Amount ₹28,000 is 8.75x median of ₹3,200', value: '8.75x median' },
    ],
    behavioral_dna: { amount_range_score: 0.65, time_window_pattern: '07:00-23:00', device_stability_score: 0.98, location_variance: 0.05, merchant_distribution_entropy: 0.45 },
    investigation_outcome: 'LEGITIMATE - Customer confirmed bulk grocery purchase for family event.',
    ai_reasoning: 'Kavita Deshmukh\'s ₹28,000 transaction at Quick Mart is flagged solely due to amount spike (8.75x median). All other indicators are normal: registered device, home location, familiar merchant, regular business hours. The merchant Quick Mart is a general store with low risk profile. Customer has a pattern of occasional large purchases (₹15,000 in Dec, ₹22,000 in Jan). Recommendation: LOW RISK, approve with standard monitoring.',
  },
  {
    case_id: 'CASE006',
    transaction_uuid: 'TXN011',
    customer_uuid: 'CUST003',
    merchant_uuid: 'MER002',
    risk_score: 78,
    status: 'open',
    flagged_at: '2026-02-15 04:21:00',
    amount_risk: 85, device_risk: 30, location_risk: 40, merchant_risk: 60, behavioral_deviation: 82,
    anomalies: [
      { type: 'Amount Spike', severity: 'high', description: 'Amount ₹1,56,000 exceeds 50% of account balance', value: '49% of balance' },
      { type: 'Unusual Hour', severity: 'medium', description: 'Transaction at 04:20 AM', value: '04:20 IST' },
      { type: 'Repeat Flagging', severity: 'medium', description: 'Customer flagged in CASE001 (3 days prior)', value: '2nd flag in 72h' },
    ],
    behavioral_dna: { amount_range_score: 0.15, time_window_pattern: '09:00-18:00', device_stability_score: 0.92, location_variance: 0.12, merchant_distribution_entropy: 0.67 },
    ai_reasoning: 'Arjun Reddy has been flagged for the second time in 72 hours. This ₹1,56,000 transaction at Flipkart at 04:20 AM from his registered device in Hyderabad follows CASE001 where a suspicious transaction from Chennai was detected. While this transaction uses the registered device and home location, the amount is extremely high (49% of balance) and the hour is highly unusual. The repeat flagging pattern combined with CASE001 suggests either continued unauthorized access or the customer is liquidating the account. Recommendation: HOLD transaction, mandatory customer verification required.',
  },
];

// Dashboard stats
export const dashboardStats = {
  totalCases: flaggedCases.length,
  openCases: flaggedCases.filter(c => c.status === 'open').length,
  investigating: flaggedCases.filter(c => c.status === 'investigating').length,
  escalated: flaggedCases.filter(c => c.status === 'escalated').length,
  resolved: flaggedCases.filter(c => c.status === 'resolved').length,
  avgRiskScore: Math.round(flaggedCases.reduce((a, c) => a + c.risk_score, 0) / flaggedCases.length),
  totalFlaggedAmount: transactions.filter(t => flaggedCases.some(c => c.transaction_uuid === t.transaction_uuid)).reduce((a, t) => a + t.transaction_amount, 0),
  highRiskCount: flaggedCases.filter(c => c.risk_score >= 70).length,
};

export function getCustomer(id: string) { return customers.find(c => c.customer_uuid === id); }
export function getMerchant(id: string) { return merchants.find(m => m.merchant_uuid === id); }
export function getTransaction(id: string) { return transactions.find(t => t.transaction_uuid === id); }
