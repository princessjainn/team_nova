import { supabase } from '@/integrations/supabase/client';
import { AnomalyFlag, BehavioralDNA, FlaggedCase } from './types';

export async function fetchCustomers() {
  const { data, error } = await supabase
    .from('upi_customers')
    .select('*')
    .order('customer_uuid');
  if (error) throw error;
  return data;
}

export async function fetchMerchants() {
  const { data, error } = await supabase
    .from('upi_merchants')
    .select('*')
    .order('merchant_uuid');
  if (error) throw error;
  return data;
}

export async function fetchTransactions() {
  const { data, error } = await supabase
    .from('upi_transactions')
    .select('*')
    .order('transaction_timestamp', { ascending: false });
  if (error) throw error;
  return data;
}

export async function fetchFlaggedCases() {
  const { data, error } = await supabase
    .from('flagged_cases')
    .select('*')
    .order('risk_score', { ascending: false });
  if (error) throw error;
  return (data || []).map(row => ({
    ...row,
    anomalies: (row.anomalies || []) as unknown as AnomalyFlag[],
    behavioral_dna: (row.behavioral_dna || {}) as unknown as BehavioralDNA,
  }));
}

export async function fetchCaseById(caseId: string) {
  const { data, error } = await supabase
    .from('flagged_cases')
    .select('*')
    .eq('case_id', caseId)
    .single();
  if (error) throw error;
  return {
    ...data,
    anomalies: (data.anomalies || []) as unknown as AnomalyFlag[],
    behavioral_dna: (data.behavioral_dna || {}) as unknown as BehavioralDNA,
  };
}

export async function fetchCustomerByUuid(uuid: string) {
  const { data, error } = await supabase
    .from('upi_customers')
    .select('*')
    .eq('customer_uuid', uuid)
    .single();
  if (error) throw error;
  return data;
}

export async function fetchMerchantByUuid(uuid: string) {
  const { data, error } = await supabase
    .from('upi_merchants')
    .select('*')
    .eq('merchant_uuid', uuid)
    .single();
  if (error) throw error;
  return data;
}

export async function fetchTransactionByUuid(uuid: string) {
  const { data, error } = await supabase
    .from('upi_transactions')
    .select('*')
    .eq('transaction_uuid', uuid)
    .single();
  if (error) throw error;
  return data;
}

export async function updateCaseAIReasoning(caseId: string, aiReasoning: string) {
  const { error } = await supabase
    .from('flagged_cases')
    .update({ ai_reasoning: aiReasoning })
    .eq('case_id', caseId);
  if (error) throw error;
}
