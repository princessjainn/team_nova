import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { AuthProvider } from "@/hooks/useAuth";
import ProtectedRoute from "@/components/ProtectedRoute";
import AppLayout from "@/components/AppLayout";
import Dashboard from "@/pages/Dashboard";
import CasesPage from "@/pages/CasesPage";
import CaseDetail from "@/pages/CaseDetail";
import CustomersPage from "@/pages/CustomersPage";
import MerchantsPage from "@/pages/MerchantsPage";
import TransactionsPage from "@/pages/TransactionsPage";
import ChequeInvestigationPage from "@/pages/ChequeInvestigationPage";
import UPIRiskCheckPage from "@/pages/UPIRiskCheckPage";
import IntelligenceDashboard from "@/pages/IntelligenceDashboard";
import AuthPage from "@/pages/AuthPage";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <AuthProvider>
      <TooltipProvider>
        <Toaster />
        <Sonner />
        <BrowserRouter>
          <Routes>
            <Route path="/auth" element={<AuthPage />} />
            <Route element={<ProtectedRoute><AppLayout /></ProtectedRoute>}>
              <Route path="/" element={<Dashboard />} />
              <Route path="/cases" element={<CasesPage />} />
              <Route path="/cases/:id" element={<CaseDetail />} />
              <Route path="/customers" element={<CustomersPage />} />
              <Route path="/merchants" element={<MerchantsPage />} />
              <Route path="/transactions" element={<TransactionsPage />} />
              <Route path="/cheque" element={<ChequeInvestigationPage />} />
              <Route path="/upi-check" element={<UPIRiskCheckPage />} />
              <Route path="/intelligence" element={<IntelligenceDashboard />} />
            </Route>
            <Route path="*" element={<NotFound />} />
          </Routes>
        </BrowserRouter>
      </TooltipProvider>
    </AuthProvider>
  </QueryClientProvider>
);

export default App;
