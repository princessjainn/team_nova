import jsPDF from 'jspdf';

interface PdfCaseData {
  case_id: string;
  status: string;
  risk_score: number;
  flagged_at: string;
  anomalies: { type: string; severity: string; description: string; value: string }[];
  behavioral_dna: Record<string, any>;
  amount_risk: number;
  device_risk: number;
  location_risk: number;
  merchant_risk: number;
  behavioral_deviation: number;
  ai_reasoning?: string;
}

interface PdfExportOptions {
  caseData: PdfCaseData;
  customer?: Record<string, any>;
  merchant?: Record<string, any>;
  transaction?: Record<string, any>;
  aiReport?: string;
}

export function exportCasePdf({ caseData, customer, merchant, transaction, aiReport }: PdfExportOptions) {
  const doc = new jsPDF({ orientation: 'portrait', unit: 'mm', format: 'a4' });
  const pageW = doc.internal.pageSize.getWidth();
  const margin = 18;
  const contentW = pageW - margin * 2;
  let y = 20;

  const addPage = () => { doc.addPage(); y = 20; };
  const checkPage = (need: number) => { if (y + need > 275) addPage(); };

  // ── Header ──
  doc.setFillColor(15, 23, 42);
  doc.rect(0, 0, pageW, 42, 'F');
  doc.setFillColor(20, 184, 166);
  doc.rect(0, 42, pageW, 1.2, 'F');

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(18);
  doc.setTextColor(20, 184, 166);
  doc.text('FinSentinel AI', margin, 16);

  doc.setFontSize(8);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(148, 163, 184);
  doc.text('FRAUD INVESTIGATION REPORT', margin, 22);

  doc.setFontSize(11);
  doc.setTextColor(255, 255, 255);
  doc.text(caseData.case_id, margin, 32);

  doc.setFontSize(8);
  doc.setTextColor(148, 163, 184);
  doc.text(`Status: ${caseData.status.toUpperCase()}  •  Risk: ${caseData.risk_score}/100  •  Generated: ${new Date().toLocaleString('en-IN')}`, margin, 38);

  const riskColor = caseData.risk_score >= 70 ? [239, 68, 68] : caseData.risk_score >= 40 ? [245, 158, 11] : [34, 197, 94];
  doc.setFillColor(riskColor[0], riskColor[1], riskColor[2]);
  doc.roundedRect(pageW - margin - 22, 12, 22, 22, 3, 3, 'F');
  doc.setFontSize(14);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(255, 255, 255);
  doc.text(String(caseData.risk_score), pageW - margin - 11, 25, { align: 'center' });
  doc.setFontSize(6);
  doc.text('RISK', pageW - margin - 11, 30, { align: 'center' });

  y = 50;

  // ── Helper: Section Title ──
  const sectionTitle = (title: string) => {
    checkPage(12);
    doc.setFillColor(30, 41, 59);
    doc.roundedRect(margin, y, contentW, 8, 1.5, 1.5, 'F');
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(8);
    doc.setTextColor(20, 184, 166);
    doc.text(title.toUpperCase(), margin + 4, y + 5.5);
    y += 12;
  };

  // ── Helper: Key-Value Row ──
  const kvRow = (key: string, value: string) => {
    checkPage(6);
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(8);
    doc.setTextColor(148, 163, 184);
    doc.text(key, margin + 4, y);
    doc.setTextColor(226, 232, 240);
    doc.text(String(value || '—'), margin + 55, y);
    y += 5;
  };

  // ── Case Overview ──
  sectionTitle('Case Overview');
  kvRow('Case ID', caseData.case_id);
  kvRow('Flagged At', new Date(caseData.flagged_at).toLocaleString('en-IN'));
  kvRow('Status', caseData.status.toUpperCase());
  kvRow('Risk Score', `${caseData.risk_score}/100`);
  y += 3;

  // ── Transaction Summary ──
  if (transaction) {
    sectionTitle('Transaction Summary');
    kvRow('Transaction ID', transaction.transaction_uuid);
    kvRow('Amount', `₹${Number(transaction.transaction_amount).toLocaleString('en-IN')}`);
    kvRow('Timestamp', new Date(transaction.transaction_timestamp).toLocaleString('en-IN'));
    kvRow('Location', transaction.transaction_location);
    kvRow('Device', transaction.customer_device_id);
    kvRow('IP Address', transaction.customer_ip_address);
    y += 3;
  }

  // ── Customer Profile ──
  if (customer) {
    sectionTitle('Customer Profile');
    kvRow('Name', customer.full_name);
    kvRow('UPI ID', customer.upi_id);
    kvRow('Bank', customer.bank_name);
    kvRow('Branch', customer.home_branch);
    kvRow('Account Balance', `₹${Number(customer.account_balance).toLocaleString('en-IN')}`);
    kvRow('Registered Device', customer.registered_device_id);
    kvRow('Registered IP', customer.registered_ip_address);
    kvRow('Total Transactions', String(customer.total_transactions_count));
    y += 3;
  }

  // ── Merchant Info ──
  if (merchant) {
    sectionTitle('Merchant Information');
    kvRow('Name', merchant.merchant_name);
    kvRow('UPI ID', merchant.merchant_upi_id);
    kvRow('Bank', merchant.merchant_bank_name);
    kvRow('Branch', merchant.merchant_bank_branch);
    kvRow('Address', merchant.merchant_bank_address);
    y += 3;
  }

  // ── Risk Breakdown ──
  sectionTitle('Risk Score Breakdown');
  const risks = [
    { label: 'Amount Risk (25%)', value: caseData.amount_risk },
    { label: 'Device Risk (20%)', value: caseData.device_risk },
    { label: 'Location Risk (20%)', value: caseData.location_risk },
    { label: 'Merchant Risk (15%)', value: caseData.merchant_risk },
    { label: 'Behavioral Deviation (20%)', value: caseData.behavioral_deviation },
  ];
  risks.forEach(r => {
    checkPage(8);
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(7);
    doc.setTextColor(148, 163, 184);
    doc.text(r.label, margin + 4, y);
    doc.text(`${r.value}/100`, margin + contentW - 4, y, { align: 'right' });

    // Bar background
    const barX = margin + 55;
    const barW = contentW - 65;
    doc.setFillColor(30, 41, 59);
    doc.roundedRect(barX, y - 3, barW, 3.5, 1, 1, 'F');

    // Bar fill
    const fillColor = r.value >= 70 ? [239, 68, 68] : r.value >= 40 ? [245, 158, 11] : [34, 197, 94];
    doc.setFillColor(fillColor[0], fillColor[1], fillColor[2]);
    doc.roundedRect(barX, y - 3, barW * (r.value / 100), 3.5, 1, 1, 'F');
    y += 7;
  });
  y += 3;

  // ── Anomalies ──
  if (caseData.anomalies?.length) {
    sectionTitle('Detected Anomalies');
    caseData.anomalies.forEach((a) => {
      checkPage(14);
      const sevColor = a.severity === 'high' ? [239, 68, 68] : a.severity === 'medium' ? [245, 158, 11] : [34, 197, 94];
      doc.setFillColor(sevColor[0], sevColor[1], sevColor[2]);
      doc.circle(margin + 6, y - 1, 1.5, 'F');

      doc.setFont('helvetica', 'bold');
      doc.setFontSize(8);
      doc.setTextColor(226, 232, 240);
      doc.text(a.type, margin + 11, y);

      doc.setFont('helvetica', 'normal');
      doc.setFontSize(6);
      doc.setTextColor(sevColor[0], sevColor[1], sevColor[2]);
      doc.text(`[${a.severity.toUpperCase()}]`, margin + 11 + doc.getTextWidth(a.type) + 3, y);

      y += 4;
      doc.setFontSize(7);
      doc.setTextColor(148, 163, 184);
      const descLines = doc.splitTextToSize(a.description, contentW - 15);
      doc.text(descLines, margin + 11, y);
      y += descLines.length * 3.5 + 2;

      doc.setFont('courier', 'normal');
      doc.setFontSize(6.5);
      doc.setTextColor(100, 116, 139);
      doc.text(a.value, margin + 11, y);
      y += 5;
    });
    y += 2;
  }

  // ── Behavioral DNA ──
  if (caseData.behavioral_dna) {
    sectionTitle('Behavioral DNA Profile');
    const dna = caseData.behavioral_dna;
    kvRow('Amount Range Score', String(dna.amount_range_score));
    kvRow('Time Window Pattern', String(dna.time_window_pattern));
    kvRow('Device Stability', String(dna.device_stability_score));
    kvRow('Location Variance', String(dna.location_variance));
    kvRow('Merchant Entropy', String(dna.merchant_distribution_entropy));
    y += 3;
  }

  // ── AI Report ──
  const reportText = aiReport || caseData.ai_reasoning;
  if (reportText) {
    sectionTitle('AI Investigation Report');
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(7.5);
    doc.setTextColor(203, 213, 225);

    // Clean markdown for PDF
    const cleaned = reportText
      .replace(/#{1,3}\s*/g, '')
      .replace(/\*\*/g, '')
      .replace(/\*/g, '')
      .replace(/\|[^\n]+\|/g, (match) => match.replace(/\|/g, '  ').replace(/-+/g, ''))
      .trim();

    const lines = doc.splitTextToSize(cleaned, contentW - 8);
    for (const line of lines) {
      checkPage(4);
      doc.text(line, margin + 4, y);
      y += 3.5;
    }
    y += 3;
  }

  // ── Footer on each page ──
  const totalPages = doc.getNumberOfPages();
  for (let i = 1; i <= totalPages; i++) {
    doc.setPage(i);
    doc.setFillColor(30, 41, 59);
    doc.rect(0, 287, pageW, 10, 'F');
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(6);
    doc.setTextColor(100, 116, 139);
    doc.text('CONFIDENTIAL — For Internal Investigation Use Only', margin, 293);
    doc.text(`Page ${i} of ${totalPages}`, pageW - margin, 293, { align: 'right' });
    doc.text(`FinSentinel AI — ${caseData.case_id}`, pageW / 2, 293, { align: 'center' });
  }

  doc.save(`${caseData.case_id}_Investigation_Report.pdf`);
}
